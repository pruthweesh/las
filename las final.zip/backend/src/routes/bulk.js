// src/routes/bulk.js
import { Router } from 'express';
import { bulkStudents, bulkStaff } from '../controllers/bulkController.js';
import { auth, requireRole } from '../middleware/auth.js';

const router = Router();

// ONLY HOD CAN UPLOAD
router.post(
  '/bulk-students',
  auth(true),
  requireRole('HOD'),
  bulkStudents        // ✅ NO SPREAD
);

router.post(
  '/bulk-staff',
  auth(true),
  requireRole('HOD'),
  bulkStaff           // ✅ NO SPREAD
);

export default router;
