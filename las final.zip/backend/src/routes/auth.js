import { Router } from 'express';
import { auth } from '../middleware/auth.js';
import { signupHod, login, changeOwnPassword, resetPassword } from '../controllers/authController.js';

const router = Router();

// First HOD signup is open if no HOD exists; else requires HOD token (handled in controller)
router.post('/signup-hod', auth(false), signupHod);
router.post('/login', login);
router.post('/change-password', auth(true), changeOwnPassword);
router.post('/reset-password', auth(true), resetPassword);

export default router;
