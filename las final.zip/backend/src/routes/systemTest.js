import { Router } from "express";
import multer from "multer";
import jwt from "jsonwebtoken";
import { PrismaClient } from "@prisma/client";

const router = Router();
const prisma = new PrismaClient();
const upload = multer({ storage: multer.memoryStorage() });

/**
 * FULL SYSTEM DIAGNOSTIC ROUTE
 * This route NEVER writes to DB permanently
 * It ONLY tests each layer and reports results
 */
router.post(
  "/full-diagnostic",
  upload.single("file"),
  async (req, res) => {
    const report = {
      step1_token: null,
      step2_jwt_decode: null,
      step3_file_received: null,
      step4_csv_parse: null,
      step5_prisma_connection: null,
      step6_db_write_test: null,
      errors: []
    };

    try {
      /* ---------------- STEP 1: TOKEN CHECK ---------------- */
      const authHeader = req.headers.authorization;
      if (!authHeader || !authHeader.startsWith("Bearer ")) {
        report.step1_token = "❌ Authorization header missing";
        return res.status(401).json(report);
      }

      const token = authHeader.split(" ")[1];
      report.step1_token = "✅ Token received";

      /* ---------------- STEP 2: JWT VERIFY ---------------- */
      try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        report.step2_jwt_decode = {
          status: "✅ JWT valid",
          payload: decoded
        };
      } catch (err) {
        report.step2_jwt_decode = "❌ JWT INVALID";
        report.errors.push(err.message);
        return res.status(401).json(report);
      }

      /* ---------------- STEP 3: FILE CHECK ---------------- */
      if (!req.file) {
        report.step3_file_received = "❌ No CSV file uploaded";
        return res.status(400).json(report);
      }

      report.step3_file_received = {
        status: "✅ File received",
        filename: req.file.originalname,
        size: req.file.size
      };

      /* ---------------- STEP 4: CSV PARSE ---------------- */
      const csvText = req.file.buffer.toString("utf-8").trim();
      const lines = csvText.split("\n");

      if (lines.length < 2) {
        report.step4_csv_parse = "❌ CSV has no data rows";
        return res.status(400).json(report);
      }

      const headers = lines[0].split(",").map(h => h.trim());
      const firstRow = lines[1].split(",").map(v => v.trim());

      report.step4_csv_parse = {
        status: "✅ CSV parsed",
        headers,
        sampleRow: firstRow
      };

      /* ---------------- STEP 5: PRISMA CONNECTION ---------------- */
      try {
        await prisma.$queryRaw`SELECT 1`;
        report.step5_prisma_connection = "✅ Prisma connected to DB";
      } catch (err) {
        report.step5_prisma_connection = "❌ Prisma DB connection failed";
        report.errors.push(err.message);
        return res.status(500).json(report);
      }

      /* ---------------- STEP 6: DB WRITE TEST (ROLLBACK SAFE) ---------------- */
      try {
        await prisma.$transaction(async (tx) => {
          // 🔴 CHANGE TABLE NAME ONLY IF NEEDED
          await tx.user.create({
            data: {
              name: "__DIAGNOSTIC_TEST__",
              email: `test_${Date.now()}@test.com`,
              role: "TEST"
            }
          });

          // Rollback intentionally
          throw new Error("ROLLBACK_TEST");
        });
      } catch (err) {
        if (err.message === "ROLLBACK_TEST") {
          report.step6_db_write_test = "✅ DB write permission confirmed (rollback successful)";
        } else {
          report.step6_db_write_test = "❌ DB write failed";
          report.errors.push(err.message);
        }
      }

      /* ---------------- FINAL RESULT ---------------- */
      return res.json({
        status: "✅ SYSTEM DIAGNOSTIC COMPLETED",
        report
      });

    } catch (fatal) {
      report.errors.push(fatal.message);
      return res.status(500).json(report);
    }
  }
);

export default router;
