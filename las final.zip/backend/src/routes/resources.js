// routes/resources.js
import express from 'express';
import multer from 'multer';
import path from 'path';
import { uploadResource, listResourcesByLab, downloadResource } from '../controllers/resourceController.js';
import { authMiddleware } from '../middleware/auth.js';

const router = express.Router();

// Configure multer storage for resources
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(process.cwd(), 'uploads', 'resources'));
  },
  filename: (req, file, cb) => {
    const safeName = file.originalname.replace(/[^a-zA-Z0-9.\-_]/g, '_');
    const unique = `${Date.now()}-${Math.round(Math.random()*1E9)}-${safeName}`;
    cb(null, unique);
  }
});

// Limits & file filter - adjust as necessary
const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10 MB
  fileFilter: (req, file, cb) => {
    // Accept pdf/doc/docx/pptx/images/plain text
    const allowed = [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.ms-powerpoint',
      'application/vnd.openxmlformats-officedocument.presentationml.presentation',
      'text/plain',
      'image/png',
      'image/jpeg',
      'image/jpg'
    ];
    if (allowed.includes(file.mimetype)) return cb(null, true);
    return cb(new Error('Unsupported file type'), false);
  }
});

// POST: upload resource (staff only) - expects form-data with file
router.post('/upload', authMiddleware, upload.single('file'), uploadResource);

// GET: list resources for a lab (requires user assigned to that lab)
router.get('/lab/:labId', authMiddleware, listResourcesByLab);

// GET: download resource by id (permission-checked)
router.get('/download/:id', authMiddleware, downloadResource);

export default router;
