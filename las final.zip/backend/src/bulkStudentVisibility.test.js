import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function runBulkStudentVisibilityTest() {
  console.log('\n========== BULK STUDENT VISIBILITY TEST ==========\n');

  // 1️⃣ Fetch all bulk-created students (recent)
  const students = await prisma.user.findMany({
    where: {
      role: 'STUDENT'
    },
    include: {
      labs: true
    }
  });

  console.log(`Total students found: ${students.length}\n`);

  for (const student of students) {
    console.log('----------------------------------------');
    console.log(`Student: ${student.name}`);
    console.log(`Email: ${student.email}`);
    console.log(`Student ID: ${student.studentId}`);

    // ❌ Department issue
    if (student.department === null || student.department === '' || student.department === undefined) {
      console.log('❌ ISSUE: Department missing');
    } else {
      console.log('✅ Department:', student.department);
    }

    // ❌ Year issue
    if (!student.year) {
      console.log('❌ ISSUE: Year missing');
    } else {
      console.log('✅ Year:', student.year);
    }

    // ❌ Role issue
    if (student.role !== 'STUDENT') {
      console.log('❌ ISSUE: Role mismatch:', student.role);
    } else {
      console.log('✅ Role OK');
    }

    // ❌ Lab assignment issue
    if (student.labs.length === 0) {
      console.log('❌ ISSUE: No lab assigned');
    } else {
      console.log(`✅ Lab Assignments: ${student.labs.length}`);
    }

    // ❌ Frontend filter simulation
    const frontendVisible =
      student.role === 'STUDENT' &&
      (student.department !== undefined &&
        (student.department !== null && student.department !== ''));

    if (!frontendVisible) {
      console.log('❌ ISSUE: This student WILL NOT appear in frontend');
    } else {
      console.log('✅ Student SHOULD appear in frontend');
    }
  }

  // 2️⃣ Detect lab name formatting issues
  const labs = await prisma.lab.findMany();

  console.log('\n========== LAB NAME SANITY CHECK ==========\n');
  for (const lab of labs) {
    if (lab.name !== lab.name.trim()) {
      console.log(`❌ ISSUE: Lab name contains spaces/tabs -> "${lab.name}"`);
    } else {
      console.log(`✅ Lab OK: "${lab.name}"`);
    }
  }

  console.log('\n========== TEST COMPLETED ==========\n');
}

runBulkStudentVisibilityTest()
  .catch(e => console.error(e))
  .finally(async () => {
    await prisma.$disconnect();
  });

