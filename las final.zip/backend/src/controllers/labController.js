// ENHANCED Lab Controller with Improved Database Management and Error Handling
// FIXED: Removed 'mode: insensitive' for MySQL compatibility
import { prisma } from '../config/prisma.js';

// Get all labs with student counts
export async function listLabs(req, res) {
  try {
    console.log('📚 Loading all labs with student counts...');
    
    const labs = await prisma.lab.findMany({
      include: {
        students: {
          include: {
            student: {
              select: { id: true, name: true, year: true }
            }
          }
        },
        staff: {
          include: {
            staff: {
              select: { id: true, name: true }
            }
          }
        }
      },
      orderBy: [
        { year: 'asc' },
        { name: 'asc' }
      ]
    });

    const formattedLabs = labs.map(lab => ({
      id: lab.id,
      name: lab.name,
      year: lab.year,
      student_count: lab.students.length,
      staff_count: lab.staff.length,
      students: lab.students.map(s => ({
        id: s.student.id,
        name: s.student.name,
        year: s.student.year
      })),
      staff: lab.staff.map(s => ({
        id: s.staff.id,
        name: s.staff.name
      })),
      created_at: lab.createdAt
    }));

    console.log(`✅ Found ${formattedLabs.length} labs`);
    res.json(formattedLabs);
    
  } catch (error) {
    console.error('❌ List labs error:', error);
    res.status(500).json({ error: error.message });
  }
}

// Enhanced Create new lab with better validation and error handling
// FIXED: Removed mode: 'insensitive' - MySQL uses case-insensitive collation by default
export async function createLab(req, res) {
  try {
    const { name, year } = req.body;
    
    console.log(`📚 Creating new lab: ${name} (Year ${year})`);
    
    // Enhanced validation
    if (!name || !year) {
      return res.status(400).json({ 
        error: 'Lab name and year are required',
        details: 'Please provide both a lab name and year'
      });
    }

    // Trim and validate inputs
    const trimmedName = name.toString().trim();
    const normalizedYear = year.toString().trim();

    if (!trimmedName || !normalizedYear) {
      return res.status(400).json({
        error: 'Invalid input data',
        details: 'Lab name and year cannot be empty after trimming'
      });
    }

    // Validate year format
    const validYears = ['2nd Year', '3rd Year', '4th Year'];
    if (!validYears.includes(normalizedYear)) {
      return res.status(400).json({
        error: 'Invalid year format',
        details: `Year must be one of: ${validYears.join(', ')}`
      });
    }

    // FIXED: Check if lab already exists - removed mode: 'insensitive'
    // MySQL uses case-insensitive comparison by default with utf8mb4_general_ci collation
    const existingLab = await prisma.lab.findFirst({
      where: { 
        name: trimmedName,  // MySQL handles case-insensitive comparison automatically
        year: normalizedYear
      }
    });

    if (existingLab) {
      return res.status(409).json({ 
        error: 'Lab already exists',
        details: `A lab named "${trimmedName}" already exists for ${normalizedYear}`,
        existingLab: {
          id: existingLab.id,
          name: existingLab.name,
          year: existingLab.year
        }
      });
    }

    // Create lab with proper error handling
    const lab = await prisma.lab.create({
      data: {
        name: trimmedName,
        year: normalizedYear
      }
    });

    console.log(`✅ Created lab: ${lab.name} (ID: ${lab.id})`);
    
    res.status(201).json({
      id: lab.id,
      name: lab.name,
      year: lab.year,
      student_count: 0,
      staff_count: 0,
      created_at: lab.createdAt,
      message: `Lab "${lab.name}" created successfully for ${lab.year}`
    });
    
  } catch (error) {
    console.error('❌ Create lab error:', error);
    
    // Enhanced error handling for different Prisma error codes
    if (error.code === 'P2002') {
      return res.status(409).json({ 
        error: 'Lab already exists',
        details: 'A lab with this name and year combination already exists',
        constraint: error.meta?.target || 'name_year_unique'
      });
    }
    
    if (error.code === 'P2025') {
      return res.status(404).json({
        error: 'Related record not found',
        details: 'One or more related records could not be found'
      });
    }
    
    res.status(500).json({ 
      error: error.message,
      details: 'Failed to create lab. Please try again.',
      errorCode: error.code || 'UNKNOWN_ERROR'
    });
  }
}

// Enhanced Delete lab with comprehensive cascade delete and better validation
export async function deleteLab(req, res) {
  try {
    const { id } = req.params;
    
    console.log(`🗑️ Deleting lab ${id} with all related data`);
    
    const labId = parseInt(id);
    if (isNaN(labId) || labId <= 0) {
      return res.status(400).json({ 
        error: 'Invalid lab ID',
        details: 'Lab ID must be a valid positive number'
      });
    }
    
    // Check if lab exists and get comprehensive data
    const lab = await prisma.lab.findUnique({
      where: { id: labId },
      include: {
        students: {
          include: {
            student: {
              select: { id: true, name: true, year: true }
            }
          }
        },
        staff: {
          include: {
            staff: {
              select: { id: true, name: true }
            }
          }
        },
        attendance: true
      }
    });

    if (!lab) {
      return res.status(404).json({ 
        error: 'Lab not found',
        details: `No lab found with ID ${labId}`
      });
    }

    console.log(`📊 Lab "${lab.name}" (${lab.year}) has:`);
    console.log(`  - ${lab.students.length} student assignments`);
    console.log(`  - ${lab.staff.length} staff assignments`);
    console.log(`  - ${lab.attendance.length} attendance records`);

    // Use comprehensive transaction for cascade delete with timeout
    const deletionResults = await prisma.$transaction(async (tx) => {
      console.log('🔄 Starting comprehensive cascade delete transaction...');
      
      let deletedRecords = {
        attendance: 0,
        studentAssignments: 0,
        staffAssignments: 0,
        lab: 0
      };

      // Step 1: Delete all attendance records
      if (lab.attendance.length > 0) {
        console.log(`  🗑️ Deleting ${lab.attendance.length} attendance records...`);
        const attendanceResult = await tx.attendance.deleteMany({
          where: { labId: labId }
        });
        deletedRecords.attendance = attendanceResult.count;
        console.log(`    ✅ Deleted ${attendanceResult.count} attendance records`);
      }

      // Step 2: Delete all student lab assignments
      if (lab.students.length > 0) {
        console.log(`  🗑️ Deleting ${lab.students.length} student assignments...`);
        const studentResult = await tx.studentLabAssignment.deleteMany({
          where: { labId: labId }
        });
        deletedRecords.studentAssignments = studentResult.count;
        console.log(`    ✅ Deleted ${studentResult.count} student assignments`);
      }

      // Step 3: Delete all staff lab assignments
      if (lab.staff.length > 0) {
        console.log(`  🗑️ Deleting ${lab.staff.length} staff assignments...`);
        const staffResult = await tx.staffLabAssignment.deleteMany({
          where: { labId: labId }
        });
        deletedRecords.staffAssignments = staffResult.count;
        console.log(`    ✅ Deleted ${staffResult.count} staff assignments`);
      }

      // Step 4: Delete the lab itself
      console.log('  🗑️ Deleting lab record...');
      await tx.lab.delete({
        where: { id: labId }
      });
      deletedRecords.lab = 1;
      console.log('    ✅ Lab record deleted');

      console.log('✅ Comprehensive cascade delete completed successfully');
      return deletedRecords;
    }, {
      maxWait: 10000,  // 10 seconds max wait
      timeout: 30000   // 30 seconds timeout
    });

    const totalDeleted = Object.values(deletionResults).reduce((sum, count) => sum + count, 0);

    console.log(`✅ Successfully deleted lab "${lab.name}" and all related data`);
    console.log(`📊 Deletion summary: ${totalDeleted} total records removed`);
    
    res.json({ 
      success: true,
      message: `Lab "${lab.name}" deleted successfully`,
      labDetails: {
        id: lab.id,
        name: lab.name,
        year: lab.year
      },
      deletedRecords: {
        ...deletionResults,
        total: totalDeleted
      },
      affectedEntities: {
        students: lab.students.length > 0 ? `${lab.students.length} student assignments removed` : 'No students were assigned',
        staff: lab.staff.length > 0 ? `${lab.staff.length} staff assignments removed` : 'No staff were assigned',
        attendance: lab.attendance.length > 0 ? `${lab.attendance.length} attendance records removed` : 'No attendance records'
      }
    });
    
  } catch (error) {
    console.error('❌ Delete lab error:', error);
    
    if (error.code === 'P2003') {
      return res.status(409).json({
        error: 'Cannot delete lab with dependencies',
        details: 'Please remove all student and staff assignments first',
        suggestion: 'Use the cascade delete feature or manually remove assignments'
      });
    }
    
    if (error.code === 'P2025') {
      return res.status(404).json({
        error: 'Lab not found',
        details: 'The lab you are trying to delete does not exist'
      });
    }
    
    res.status(500).json({ 
      error: error.message,
      details: 'Failed to delete lab and related data',
      errorCode: error.code || 'DELETE_ERROR'
    });
  }
}

// Enhanced Delete lab by name and year with comprehensive cascade delete
export async function deleteLabByNameAndYear(req, res) {
  try {
    const { name, year } = req.body;
    
    console.log(`🗑️ Deleting lab by name: "${name}" (${year})`);
    
    if (!name || !year) {
      return res.status(400).json({ 
        error: 'Lab name and year are required',
        details: 'Please provide both lab name and year'
      });
    }

    const trimmedName = name.toString().trim();
    const normalizedYear = year.toString().trim();

    // Find the lab first
    const lab = await prisma.lab.findFirst({
      where: { 
        name: trimmedName,
        year: normalizedYear
      },
      include: {
        students: true,
        staff: true,
        attendance: true
      }
    });

    if (!lab) {
      return res.status(404).json({ 
        error: 'Lab not found',
        details: `No lab found with name "${trimmedName}" for ${normalizedYear}`
      });
    }

    console.log(`📊 Found lab ID ${lab.id}: "${lab.name}" (${lab.year})`);
    console.log(`  - ${lab.students.length} student assignments`);
    console.log(`  - ${lab.staff.length} staff assignments`);
    console.log(`  - ${lab.attendance.length} attendance records`);

    // Use comprehensive transaction for cascade delete
    const deletionResults = await prisma.$transaction(async (tx) => {
      console.log('🔄 Starting cascade delete transaction...');
      
      let deletedRecords = {
        attendance: 0,
        studentAssignments: 0,
        staffAssignments: 0,
        lab: 0
      };

      // Delete attendance records
      if (lab.attendance.length > 0) {
        const attendanceResult = await tx.attendance.deleteMany({
          where: { labId: lab.id }
        });
        deletedRecords.attendance = attendanceResult.count;
        console.log(`  ✅ Deleted ${attendanceResult.count} attendance records`);
      }

      // Delete student assignments
      if (lab.students.length > 0) {
        const studentResult = await tx.studentLabAssignment.deleteMany({
          where: { labId: lab.id }
        });
        deletedRecords.studentAssignments = studentResult.count;
        console.log(`  ✅ Deleted ${studentResult.count} student assignments`);
      }

      // Delete staff assignments
      if (lab.staff.length > 0) {
        const staffResult = await tx.staffLabAssignment.deleteMany({
          where: { labId: lab.id }
        });
        deletedRecords.staffAssignments = staffResult.count;
        console.log(`  ✅ Deleted ${staffResult.count} staff assignments`);
      }

      // Delete the lab
      await tx.lab.delete({
        where: { id: lab.id }
      });
      deletedRecords.lab = 1;
      console.log('  ✅ Lab record deleted');

      return deletedRecords;
    }, {
      maxWait: 10000,
      timeout: 30000
    });

    const totalDeleted = Object.values(deletionResults).reduce((sum, count) => sum + count, 0);

    console.log(`✅ Successfully deleted lab "${lab.name}" and all related data`);
    
    res.json({ 
      success: true,
      message: `Lab "${lab.name}" deleted successfully`,
      labDetails: {
        id: lab.id,
        name: lab.name,
        year: lab.year
      },
      deletedRecords: {
        ...deletionResults,
        total: totalDeleted
      }
    });
    
  } catch (error) {
    console.error('❌ Delete lab by name/year error:', error);
    res.status(500).json({ 
      error: error.message,
      details: 'Failed to delete lab',
      errorCode: error.code || 'DELETE_ERROR'
    });
  }
}

export async function bulkAssignStudentsByYear(req, res) {
  try {
    const { year, labNames } = req.body;  // Changed to accept labNames array
    
    console.log(`👨‍🎓 Bulk assigning students...`);
    console.log(`  Year: ${year}`);
    console.log(`  Lab Names: ${labNames ? labNames.join(', ') : 'ALL LABS'}`);
    
    if (!year) {
      return res.status(400).json({ 
        error: 'Year is required',
        details: 'Please provide the year for bulk assignment'
      });
    }

    const normalizedYear = year.toString().trim();

    // Validate year format
    const validYears = ['2nd Year', '3rd Year', '4th Year'];
    if (!validYears.includes(normalizedYear)) {
      return res.status(400).json({
        error: 'Invalid year format',
        details: `Year must be one of: ${validYears.join(', ')}`
      });
    }

    // Get labs - either specific labs by name or all labs for the year
    let labs;
    if (labNames && Array.isArray(labNames) && labNames.length > 0) {
      // Get specific labs by name
      labs = await prisma.lab.findMany({
        where: { 
          year: normalizedYear,
          name: { in: labNames }
        },
        select: { id: true, name: true, year: true }
      });

      // Check if all requested labs were found
      if (labs.length !== labNames.length) {
        const foundLabNames = labs.map(l => l.name);
        const missingLabs = labNames.filter(name => !foundLabNames.includes(name));
        console.log(`⚠️ Warning: Some labs not found: ${missingLabs.join(', ')}`);
      }
    } else {
      // Get all labs for the year
      labs = await prisma.lab.findMany({
        where: { year: normalizedYear },
        select: { id: true, name: true, year: true }
      });
    }

    if (labs.length === 0) {
      return res.status(404).json({ 
        error: 'No labs found',
        details: labNames 
          ? `No labs found with the specified names for ${normalizedYear}. Please create labs first.`
          : `No labs found for ${normalizedYear}. Please create labs first.`
      });
    }

    // Get all students for the year
    const students = await prisma.user.findMany({
      where: { 
        role: 'STUDENT',
        year: normalizedYear
      },
      select: { id: true, name: true, year: true, studentId: true }
    });

    if (students.length === 0) {
      return res.status(404).json({ 
        error: 'No students found',
        details: `No students found for ${normalizedYear}`
      });
    }

    console.log(`📊 Found ${labs.length} labs and ${students.length} students for ${normalizedYear}`);

    // Create all possible assignments
    const assignments = [];
    for (const lab of labs) {
      for (const student of students) {
        assignments.push({
          studentId: student.id,
          labId: lab.id
        });
      }
    }

    console.log(`🔄 Creating ${assignments.length} student-lab assignments...`);

    // Use transaction for bulk insert
    const result = await prisma.$transaction(async (tx) => {
      // First, remove existing assignments for these students in these labs
      const deletedCount = await tx.studentLabAssignment.deleteMany({
        where: {
          studentId: { in: students.map(s => s.id) },
          labId: { in: labs.map(l => l.id) }
        }
      });
      
      console.log(`  🗑️ Removed ${deletedCount.count} existing assignments`);

      // Then create new assignments
      const created = await tx.studentLabAssignment.createMany({
        data: assignments,
        skipDuplicates: true
      });

      console.log(`  ✅ Created ${created.count} new assignments`);
      
      return {
        deleted: deletedCount.count,
        created: created.count
      };
    }, {
      maxWait: 10000,  // 10 seconds max wait
      timeout: 30000   // 30 seconds timeout
    });

    console.log(`✅ Successfully processed student-lab assignments for ${normalizedYear}`);
    
    // CRITICAL FIX: Use 'assignment_summary' instead of 'summary' to match frontend expectations
    res.json({
      success: true,
      message: `Successfully assigned ${students.length} ${normalizedYear} students to ${labs.length} lab(s)`,
      assignment_summary: {  // Changed from 'summary' to 'assignment_summary'
        year: normalizedYear,
        students_count: students.length,
        labs_count: labs.length,
        new_assignments: result.created,
        removed_assignments: result.deleted,
        total_assignments: result.created
      },
      details: {
        labs: labs.map(lab => ({
          id: lab.id,
          name: lab.name,
          year: lab.year
        })),
        students: students.map(student => ({
          id: student.id,
          name: student.name,
          year: student.year,
          studentId: student.studentId
        }))
      }
    });
    
  } catch (error) {
    console.error('❌ Bulk assign error:', error);
    
    // Enhanced error handling
    if (error.code === 'P2002') {
      return res.status(409).json({
        error: 'Assignment conflict',
        details: 'Some assignments already exist. This should not happen with skipDuplicates.'
      });
    }
    
    if (error.code === 'P2025') {
      return res.status(404).json({
        error: 'Record not found',
        details: 'One or more students or labs were not found'
      });
    }
    
    res.status(500).json({ 
      error: error.message,
      details: 'Failed to bulk assign students to labs',
      errorCode: error.code || 'UNKNOWN_ERROR'
    });
  }
}

// Enhanced Update lab with validation and conflict checking
// FIXED: Removed mode: 'insensitive' - MySQL uses case-insensitive collation by default
export async function updateLab(req, res) {
  try {
    const { id } = req.params;
    const { name, year } = req.body;
    
    console.log(`📝 Updating lab ${id}: ${name} (${year})`);
    
    const labId = parseInt(id);
    if (isNaN(labId) || labId <= 0) {
      return res.status(400).json({ 
        error: 'Invalid lab ID',
        details: 'Lab ID must be a valid positive number'
      });
    }
    
    if (!name || !year) {
      return res.status(400).json({ 
        error: 'Lab name and year are required',
        details: 'Please provide both a lab name and year'
      });
    }

    const trimmedName = name.toString().trim();
    const normalizedYear = year.toString().trim();

    // Validate year format
    const validYears = ['2nd Year', '3rd Year', '4th Year'];
    if (!validYears.includes(normalizedYear)) {
      return res.status(400).json({
        error: 'Invalid year format',
        details: `Year must be one of: ${validYears.join(', ')}`
      });
    }

    // Check if lab exists
    const existingLab = await prisma.lab.findUnique({
      where: { id: labId },
      include: {
        students: true,
        staff: true
      }
    });

    if (!existingLab) {
      return res.status(404).json({ 
        error: 'Lab not found',
        details: `No lab found with ID ${labId}`
      });
    }

    // FIXED: Check if name/year combination already exists (excluding current lab)
    // Removed mode: 'insensitive' - MySQL handles case-insensitive comparison automatically
    const duplicateLab = await prisma.lab.findFirst({
      where: { 
        name: trimmedName,  // MySQL handles case-insensitive comparison automatically
        year: normalizedYear,
        NOT: { id: labId }
      }
    });

    if (duplicateLab) {
      return res.status(409).json({ 
        error: 'Lab already exists',
        details: `A lab named "${trimmedName}" already exists for ${normalizedYear}`,
        conflictingLab: {
          id: duplicateLab.id,
          name: duplicateLab.name,
          year: duplicateLab.year
        }
      });
    }

    // Update the lab
    const updatedLab = await prisma.lab.update({
      where: { id: labId },
      data: {
        name: trimmedName,
        year: normalizedYear
      },
      include: {
        students: true,
        staff: true
      }
    });

    console.log(`✅ Updated lab: ${updatedLab.name} (ID: ${updatedLab.id})`);
    
    res.json({
      id: updatedLab.id,
      name: updatedLab.name,
      year: updatedLab.year,
      student_count: updatedLab.students.length,
      staff_count: updatedLab.staff.length,
      updated_at: updatedLab.updatedAt,
      message: `Lab successfully updated to "${updatedLab.name}" for ${updatedLab.year}`
    });
    
  } catch (error) {
    console.error('❌ Update lab error:', error);
    
    if (error.code === 'P2025') {
      return res.status(404).json({
        error: 'Lab not found',
        details: 'The lab you are trying to update does not exist'
      });
    }
    
    res.status(500).json({ 
      error: error.message,
      details: 'Failed to update lab',
      errorCode: error.code || 'UPDATE_ERROR'
    });
  }
}

// [Rest of the functions remain the same as they were working correctly]
export async function assignStaffToLab(req, res) {
  try {
    const { staffId, labIds } = req.body;
    
    console.log(`👨‍🏫 Assigning staff ${staffId} to labs: ${labIds.join(', ')}`);
    
    if (!staffId || !Array.isArray(labIds) || labIds.length === 0) {
      return res.status(400).json({ error: 'Staff ID and lab IDs array are required' });
    }

    // Verify staff exists
    const staff = await prisma.user.findUnique({
      where: { id: parseInt(staffId) },
      select: { id: true, name: true, role: true }
    });

    if (!staff || staff.role !== 'STAFF') {
      return res.status(404).json({ error: 'Staff member not found' });
    }

    // Verify labs exist
    const labs = await prisma.lab.findMany({
      where: { id: { in: labIds.map(id => parseInt(id)) } },
      select: { id: true, name: true, year: true }
    });

    if (labs.length !== labIds.length) {
      return res.status(404).json({ error: 'One or more labs not found' });
    }

    // Remove existing assignments for this staff member
    await prisma.staffLabAssignment.deleteMany({
      where: { staffId: parseInt(staffId) }
    });

    // Create new assignments
    const assignments = labIds.map(labId => ({
      staffId: parseInt(staffId),
      labId: parseInt(labId)
    }));

    await prisma.staffLabAssignment.createMany({
      data: assignments,
      skipDuplicates: true
    });

    console.log(`✅ Assigned staff ${staff.name} to ${labs.length} labs`);
    
    res.json({
      message: `Successfully assigned ${staff.name} to ${labs.length} labs`,
      staff: staff,
      labs: labs,
      assignmentCount: labs.length
    });
    
  } catch (error) {
    console.error('❌ Assign staff error:', error);
    res.status(500).json({ error: error.message });
  }
}

export async function assignStudentsToLab(req, res) {
  try {
    const { labId, studentIds } = req.body;
    
    console.log(`👨‍🎓 Assigning ${studentIds.length} students to lab ${labId}`);
    
    if (!labId || !Array.isArray(studentIds) || studentIds.length === 0) {
      return res.status(400).json({ error: 'Lab ID and student IDs array are required' });
    }

    // Verify lab exists
    const lab = await prisma.lab.findUnique({
      where: { id: parseInt(labId) },
      select: { id: true, name: true, year: true }
    });

    if (!lab) {
      return res.status(404).json({ error: 'Lab not found' });
    }

    // Verify students exist
    const students = await prisma.user.findMany({
      where: { 
        id: { in: studentIds.map(id => parseInt(id)) },
        role: 'STUDENT'
      },
      select: { id: true, name: true, year: true }
    });

    if (students.length !== studentIds.length) {
      return res.status(404).json({ error: 'One or more students not found' });
    }

    // Create assignments
    const assignments = studentIds.map(studentId => ({
      studentId: parseInt(studentId),
      labId: parseInt(labId)
    }));

    await prisma.studentLabAssignment.createMany({
      data: assignments,
      skipDuplicates: true
    });

    console.log(`✅ Assigned ${students.length} students to lab ${lab.name}`);
    
    res.json({
      message: `Successfully assigned ${students.length} students to ${lab.name}`,
      lab: lab,
      students: students,
      assignmentCount: students.length
    });
    
  } catch (error) {
    console.error('❌ Assign students error:', error);
    res.status(500).json({ error: error.message });
  }
}

export async function getYearSubjects(req, res) {
  try {
    const { year } = req.params;
    
    const labs = await prisma.lab.findMany({
      where: { year: year.toString() },
      select: { name: true },
      orderBy: { name: 'asc' }
    });

    const subjects = labs.map(lab => lab.name);
    
    res.json({ year, subjects });
    
  } catch (error) {
    console.error('❌ Get year subjects error:', error);
    res.status(500).json({ error: error.message });
  }
}

export async function setYearSubjects(req, res) {
  try {
    const { year } = req.params;
    const { subjects } = req.body;
    
    if (!Array.isArray(subjects)) {
      return res.status(400).json({ error: 'Subjects must be an array' });
    }

    res.json({ 
      year, 
      subjects,
      message: 'Year subjects updated successfully' 
    });
    
  } catch (error) {
    console.error('❌ Set year subjects error:', error);
    res.status(500).json({ error: error.message });
  }
}

export async function getLabAssignmentReport(req, res) {
  try {
    console.log('📊 Generating lab assignment report...');
    
    const labs = await prisma.lab.findMany({
      include: {
        students: {
          include: {
            student: {
              select: { id: true, name: true, year: true }
            }
          }
        },
        staff: {
          include: {
            staff: {
              select: { id: true, name: true }
            }
          }
        }
      },
      orderBy: [
        { year: 'asc' },
        { name: 'asc' }
      ]
    });

    const yearSummary = {};
    const yearOrder = ['2nd Year', '3rd Year', '4th Year'];
    
    yearOrder.forEach(year => {
      const yearLabs = labs.filter(lab => lab.year === year);
      const totalStudents = new Set();
      
      yearLabs.forEach(lab => {
        lab.students.forEach(s => {
          totalStudents.add(s.student.id);
        });
      });
      
      yearSummary[year] = {
        totalLabs: yearLabs.length,
        totalUniqueStudents: totalStudents.size,
        totalAssignments: yearLabs.reduce((sum, lab) => sum + lab.students.length, 0),
        labs: yearLabs.map(lab => ({
          id: lab.id,
          name: lab.name,
          studentCount: lab.students.length,
          staffCount: lab.staff.length
        }))
      };
    });

    const report = {
      generated_at: new Date().toISOString(),
      total_labs: labs.length,
      total_assignments: labs.reduce((sum, lab) => sum + lab.students.length, 0),
      year_summary: yearSummary,
      detailed_labs: labs.map(lab => ({
        id: lab.id,
        name: lab.name,
        year: lab.year,
        student_count: lab.students.length,
        staff_count: lab.staff.length,
        students: lab.students.map(s => ({
          id: s.student.id,
          name: s.student.name,
          year: s.student.year
        })),
        staff: lab.staff.map(s => ({
          id: s.staff.id,
          name: s.staff.name
        }))
      }))
    };

    console.log(`✅ Generated report with ${labs.length} labs`);
    res.json(report);
    
  } catch (error) {
    console.error('❌ Get lab assignment report error:', error);
    res.status(500).json({ error: error.message });
  }
}

export default {
  listLabs,
  createLab,
  updateLab,
  deleteLab,
  deleteLabByNameAndYear,
  bulkAssignStudentsByYear,
  assignStaffToLab,
  assignStudentsToLab,
  getYearSubjects,
  setYearSubjects,
  getLabAssignmentReport
};