// controllers/attendanceController.js - FIXED VERSION
import { prisma } from '../config/prisma.js';
import { createAttendanceSchema } from '../utils/validators.js';

export async function createAttendance(req, res) {
  try {
    console.log("📝 CREATE ATTENDANCE - Request:", JSON.stringify(req.body, null, 2));
    
    // ✅ FIX #3: Convert labId to lab name if provided
    // This allows the API to accept both labId (numeric) and lab (string name)
    if (req.body.labId && !req.body.lab) {
      const labId = parseInt(req.body.labId);
      console.log(`🔍 Looking up lab by ID: ${labId}`);
      
      const labRecord = await prisma.lab.findUnique({ 
        where: { id: labId } 
      });
      
      if (!labRecord) {
        console.error(`❌ Lab not found with ID: ${labId}`);
        return res.status(404).json({ 
          error: 'Lab not found',
          details: `No lab exists with ID ${labId}`
        });
      }
      
      console.log(`✅ Found lab: ${labRecord.name} (ID: ${labId})`);
      req.body.lab = labRecord.name;
      // Preserve the year from the lab record
      if (!req.body.year) {
        req.body.year = labRecord.year || '';
      }
    }
    
    const parsed = createAttendanceSchema.safeParse(req.body);
    if (!parsed.success) {
      console.error('❌ Validation failed:', parsed.error);
      return res.status(400).json({ 
        error: 'Invalid payload',
        details: parsed.error.errors 
      });
    }
    const data = parsed.data;

    // Use the year from request body, default to empty string
    const labYear = req.body.year || '';
    console.log(`🔍 Finding/creating lab: "${data.lab}" with year: "${labYear}"`);

    const lab = await prisma.lab.upsert({
      where: { name_year: { name: data.lab, year: labYear } },
      update: {},
      create: { name: data.lab, year: labYear }
    });
    
    console.log(`✅ Lab ready: ${lab.name} (ID: ${lab.id}, Year: ${lab.year || 'N/A'})`);

    const date = data.date ? new Date(data.date) : new Date();
    
    // ✅ FIXED: Handle both internal IDs and studentIds (registration numbers)
    const studentIdentifiers = data.records.map(r => r.studentId);
    
    // Check if the identifiers are numeric (internal DB IDs) or strings (student registration IDs)
    const isNumericId = studentIdentifiers.every(id => !isNaN(parseInt(id)));
    
    let students;
    if (isNumericId) {
      // If numeric, treat as internal database IDs
      students = await prisma.user.findMany({
        where: { 
          id: { in: studentIdentifiers.map(id => parseInt(id)) },
          role: 'STUDENT' 
        },
        select: { id: true, studentId: true }
      });
    } else {
      // If string, treat as student registration IDs
      students = await prisma.user.findMany({
        where: { 
          studentId: { in: studentIdentifiers },
          role: 'STUDENT' 
        },
        select: { id: true, studentId: true }
      });
    }
    
    // Create a lookup map for O(1) access
    // Map both by internal ID and by studentId (registration number)
    const studentMapByDbId = new Map(students.map(s => [s.id, s]));
    const studentMapByStudentId = new Map(students.map(s => [s.studentId, s]));
    
    // ✅ FIXED: Build attendance data with proper ID lookup
    const attendanceData = data.records
      .map(r => {
        // Try to find student by internal ID first, then by studentId
        const student = studentMapByDbId.get(parseInt(r.studentId)) || 
                       studentMapByStudentId.get(r.studentId);
        
        if (!student) {
          console.warn(`⚠️ Student not found: ${r.studentId}`);
          return null;
        }
        
        return {
          studentId: student.id, // Always use internal database ID
          labId: lab.id,
          date,
          status: r.status
        };
      })
      .filter(r => r !== null); // Remove invalid records
    
    if (attendanceData.length === 0) {
      return res.status(400).json({ error: 'No valid students found' });
    }
    
    // ✅ FIXED: Single database operation instead of loop
    const created = await prisma.attendance.createMany({
      data: attendanceData,
      skipDuplicates: true // Prevents duplicate entries
    });
    
    res.status(201).json({ 
      created: created.count,
      processed: data.records.length,
      valid: attendanceData.length,
      message: `Successfully created ${created.count} attendance records`
    });
    
  } catch (e) {
    console.error('❌ Attendance creation error:', e);
    return res.status(500).json({ error: e.message });
  }
}

export async function getStudentAttendance(req, res) {
  try {
    const { studentId } = req.params;
    
    // ✅ OPTIMIZED: Single query with joins instead of separate queries
    const student = await prisma.user.findFirst({ 
      where: { studentId, role: 'STUDENT' },
      include: {
        attendance: {
          include: { lab: true },
          orderBy: { date: 'desc' }
        }
      }
    });
    
    if (!student) return res.status(404).json({ error: 'Student not found' });
    
    const mapped = student.attendance.map(r => ({
      id: r.id,
      date: r.date,
      lab: r.lab.name,
      status: r.status
    }));
    
    res.json({ attendance: mapped });
  } catch (e) {
    console.error('❌ Get student attendance error:', e);
    return res.status(500).json({ error: e.message });
  }
}

export async function getSummary(req, res) {
  try {
    const { labId, fromDate, toDate } = req.query;

    const whereClause = {};

    // 📅 Date filter
    if (fromDate && toDate) {
      whereClause.date = {
        gte: new Date(fromDate),
        lte: new Date(toDate)
      };
    }

    // 🧪 Lab filter
    if (labId) {
      whereClause.labId = parseInt(labId);
    }

    // 👤 ROLE BASED FILTERING
    if (req.user.role === 'STAFF') {
      const staffLabs = await prisma.staffLabAssignment.findMany({
        where: { staffId: req.user.id },
        select: { labId: true }
      });

      whereClause.labId = {
        in: staffLabs.map(l => l.labId)
      };
    }

    if (req.user.role === 'HOD') {
      const hod = await prisma.user.findUnique({
        where: { id: req.user.id },
        select: { department: true }
      });

      if (!hod?.department) {
        return res.status(400).json({ error: 'HOD department missing' });
      }

      whereClause.student = {
        department: hod.department
      };
    }

    const attendance = await prisma.attendance.findMany({
      where: whereClause,
      include: {
        lab: true,
        student: {
          select: {
            id: true,
            name: true,
            studentId: true,
            year: true,
            department: true
          }
        }
      },
      orderBy: { date: 'desc' }
    });

    const report = {};

    for (const rec of attendance) {
      const labName = rec.lab.name;

      if (!report[labName]) {
        report[labName] = {
          totalClasses: 0,
          present: 0,
          absent: 0,
          students: {}
        };
      }

      report[labName].totalClasses++;

      if (rec.status === 'PRESENT') {
        report[labName].present++;
      } else {
        report[labName].absent++;
      }

      const sid = rec.student.studentId;

      if (!report[labName].students[sid]) {
        report[labName].students[sid] = {
          name: rec.student.name,
          present: 0,
          absent: 0
        };
      }

      if (rec.status === 'PRESENT') {
        report[labName].students[sid].present++;
      } else {
        report[labName].students[sid].absent++;
      }
    }

    res.json({
      filters: { labId, fromDate, toDate },
      report
    });

  } catch (e) {
    console.error('❌ Report session error:', e);
    res.status(500).json({ error: e.message });
  }
}
