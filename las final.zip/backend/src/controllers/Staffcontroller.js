// controllers/staffController.js - FIXED VERSION
import { prisma } from '../config/prisma.js';

// Helper to format year for frontend compatibility  
function formatYear(y) {
  if (!y) return 'Unknown';
  const yearStr = String(y).trim().toLowerCase();
  
  // Handle numeric formats: 1, 2, 3, 4
  if (yearStr === '1' || yearStr === '1st' || yearStr === 'first') return '1st';
  if (yearStr === '2' || yearStr === '2nd' || yearStr === 'second') return '2nd'; 
  if (yearStr === '3' || yearStr === '3rd' || yearStr === 'third') return '3rd';
  if (yearStr === '4' || yearStr === '4th' || yearStr === 'fourth') return '4th';
  
  // Handle "2nd Year", "3rd Year" formats
  if (yearStr.includes('2')) return '2nd';
  if (yearStr.includes('3')) return '3rd';
  if (yearStr.includes('4')) return '4th';
  if (yearStr.includes('1')) return '1st';
  
  // Default to original value if no match
  return String(y);
}

// Get staff dashboard data
export async function getStaffDashboard(req, res) {
  try {
    const staffId = req.user.id;
    
    console.log(`🔍 Loading dashboard for staff ID: ${staffId}`);
    
    const staff = await prisma.user.findUnique({
      where: { id: staffId },
      select: { 
        id: true, 
        name: true, 
        email: true, 
        username: true, 
        department: true,
        role: true
      }
    });

    if (!staff) {
      console.log('❌ Staff not found');
      return res.status(404).json({ error: 'Staff not found' });
    }

    if (staff.role !== 'STAFF') {
      console.log('❌ User is not a staff member');
      return res.status(403).json({ error: 'Access denied: User is not a staff member' });
    }

    const staffLabAssignments = await prisma.staffLabAssignment.findMany({
      where: { staffId },
      include: { 
        lab: {
          select: { 
            id: true, 
            name: true, 
            year: true 
          }
        }
      }
    });

    const assignedLabIds = staffLabAssignments.map(assignment => assignment.lab.id);
    const assignedLabs = staffLabAssignments.map(assignment => ({
      id: assignment.lab.id,
      name: assignment.lab.name,
      year: formatYear(assignment.lab.year)
    }));
    
    console.log(`📚 Staff assigned to ${assignedLabIds.length} labs:`, assignedLabs);

    if (assignedLabIds.length === 0) {
      console.log('📚 No labs assigned to this staff');
      return res.json({
        user_id: staff.id,
        user_name: staff.name,
        user_email: staff.email,
        user_department: staff.department,
        assigned_labs: [],
        total_students: 0,
        todays_attendance: 0,
        weekly_attendance: 0,
        pending_assignments: 0
      });
    }

    const studentAssignments = await prisma.studentLabAssignment.findMany({
      where: { 
        labId: { in: assignedLabIds }
      },
      include: {
        student: {
          select: {
            id: true,
            name: true,
            studentId: true,
            year: true,
            email: true
          }
        },
        lab: {
          select: {
            id: true,
            name: true,
            year: true
          }
        }
      }
    });

    const totalStudents = studentAssignments.length;
    console.log(`👥 Found ${totalStudents} student assignments in staff's labs`);

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    const todayAttendance = await prisma.attendance.count({
      where: {
        labId: { in: assignedLabIds },
        date: { gte: today, lt: tomorrow }
      }
    });

    const weekStart = new Date(today);
    weekStart.setDate(today.getDate() - today.getDay());
    
    const weeklyAttendance = await prisma.attendance.count({
      where: {
        labId: { in: assignedLabIds },
        date: { gte: weekStart }
      }
    });

    console.log(`📊 Dashboard stats: ${totalStudents} students, ${todayAttendance} today's attendance`);

    const dashboardData = {
      user_id: staff.id,
      user_name: staff.name,
      user_email: staff.email,
      user_department: staff.department,
      assigned_labs: assignedLabs,
      total_students: totalStudents,
      todays_attendance: todayAttendance,
      weekly_attendance: weeklyAttendance,
      pending_assignments: 0
    };

    console.log('✅ Dashboard data prepared successfully:', dashboardData);
    res.json(dashboardData);
    
  } catch (e) {
    console.error('❌ Staff dashboard error:', e);
    return res.status(500).json({ error: e.message });
  }
}

// Get staff's assigned labs with complete details
export async function getStaffLabs(req, res) {
  try {
    const staffId = req.user.id;
    console.log(`🔍 Getting labs for staff ID: ${staffId}`);
    
    const staffLabAssignments = await prisma.staffLabAssignment.findMany({
      where: { staffId },
      include: { 
        lab: {
          include: {
            students: {
              include: {
                student: {
                  select: { 
                    id: true,
                    name: true, 
                    studentId: true,
                    year: true
                  }
                }
              }
            }
          }
        }
      }
    });

    const labs = staffLabAssignments.map(assignment => {
      const lab = assignment.lab;
      return {
        id: lab.id,
        name: lab.name,
        year: formatYear(lab.year),
        student_count: lab.students.length,
        students: lab.students.map(s => ({
          id: s.student.id,
          student_id: s.student.studentId,
          name: s.student.name,
          year: formatYear(s.student.year)
        })),
        assigned_date: assignment.createdAt || new Date().toISOString()
      };
    });

    console.log(`📚 Retrieved ${labs.length} labs for staff with students:`, 
      labs.map(l => `${l.name}: ${l.student_count} students`));
    
    res.json(labs);
    
  } catch (e) {
    console.error('❌ Get staff labs error:', e);
    return res.status(500).json({ error: e.message });
  }
}

// Get students by lab ID
export async function getStaffStudentsByLab(req, res) {
  try {
    const staffId = req.user.id;
    const { labId } = req.params;
    
    console.log(`🔍 Getting students for staff ${staffId}, lab ${labId}`);

    // Verify staff has access to this lab
    const staffLabAssignment = await prisma.staffLabAssignment.findFirst({
      where: { 
        staffId,
        labId: parseInt(labId)
      },
      include: {
        lab: {
          select: {
            id: true,
            name: true,
            year: true
          }
        }
      }
    });

    if (!staffLabAssignment) {
      console.log(`❌ Staff ${staffId} not assigned to lab ${labId}`);
      return res.status(403).json({ error: 'Access denied to this lab' });
    }

    // Get all students in this lab
    const studentAssignments = await prisma.studentLabAssignment.findMany({
      where: { 
        labId: parseInt(labId)
      },
      include: {
        student: {
          select: {
            id: true,
            name: true,
            studentId: true,
            year: true,
            email: true
          }
        }
      }
    });

    const students = studentAssignments.map(assignment => ({
      id: assignment.student.id,
      student_id: assignment.student.studentId,
      name: assignment.student.name,
      email: assignment.student.email,
      year: formatYear(assignment.student.year),
      lab_id: parseInt(labId),
      lab_name: staffLabAssignment.lab.name
    }));

    console.log(`👥 Found ${students.length} students in lab ${staffLabAssignment.lab.name}`);
    
    res.json({
      lab: {
        id: staffLabAssignment.lab.id,
        name: staffLabAssignment.lab.name,
        year: formatYear(staffLabAssignment.lab.year)
      },
      students
    });

  } catch (e) {
    console.error('❌ Get staff students by lab error:', e);
    return res.status(500).json({ error: e.message });
  }
}

// Get all students in staff's assigned labs
export async function getStaffStudents(req, res) {
  try {
    const staffId = req.user.id;
    const { labId } = req.query;
    
    console.log(`🔍 Getting students for staff ${staffId}${labId ? `, filtered by lab ${labId}` : ''}`);

    const staffLabAssignments = await prisma.staffLabAssignment.findMany({
      where: { staffId },
      select: { labId: true }
    });

    const assignedLabIds = staffLabAssignments.map(assignment => assignment.labId);
    
    if (assignedLabIds.length === 0) {
      console.log('📚 No labs assigned to this staff');
      return res.json([]);
    }

    // Build where clause - if labId specified, filter by it AND verify staff has access
    let whereClause;
    if (labId) {
      const requestedLabId = parseInt(labId);
      // Verify staff has access to requested lab
      if (!assignedLabIds.includes(requestedLabId)) {
        console.log(`❌ Staff ${staffId} not assigned to lab ${requestedLabId}`);
        return res.status(403).json({ error: 'Access denied to this lab' });
      }
      whereClause = { labId: requestedLabId };
    } else {
      whereClause = { labId: { in: assignedLabIds } };
    }

    const studentAssignments = await prisma.studentLabAssignment.findMany({
      where: whereClause,
      include: {
        student: {
          select: {
            id: true,
            name: true,
            studentId: true,
            year: true,
            email: true
          }
        },
        lab: {
          select: {
            id: true,
            name: true,
            year: true
          }
        }
      }
    });

    const students = studentAssignments.map(assignment => ({
      id: assignment.student.id,
      student_id: assignment.student.studentId,
      name: assignment.student.name,
      email: assignment.student.email,
      year: formatYear(assignment.student.year),
      lab_id: assignment.lab.id,
      lab_name: assignment.lab.name,
      lab_year: formatYear(assignment.lab.year)
    }));

    console.log(`👥 Found ${students.length} students in staff's labs`);
    
    res.json(students);

  } catch (e) {
    console.error('❌ Get staff students error:', e);
    return res.status(500).json({ error: e.message });
  }
}

// Get attendance records for staff's labs
export async function getStaffAttendance(req, res) {
  try {
    const staffId = req.user.id;
    const { labId, startDate, endDate } = req.query;
    
    console.log(`🔍 Getting attendance for staff ${staffId}`);

    const staffLabAssignments = await prisma.staffLabAssignment.findMany({
      where: { staffId },
      select: { labId: true }
    });

    const assignedLabIds = staffLabAssignments.map(assignment => assignment.labId);
    
    if (assignedLabIds.length === 0) {
      console.log('📚 No labs assigned to this staff');
      return res.json([]);
    }

    const whereClause = {
      labId: { in: assignedLabIds }
    };

    if (labId) {
      whereClause.labId = parseInt(labId);
      if (!assignedLabIds.includes(parseInt(labId))) {
        return res.status(403).json({ error: 'Access denied to this lab' });
      }
    }

    if (startDate) {
      whereClause.date = { gte: new Date(startDate) };
    }
    if (endDate) {
      whereClause.date = { ...whereClause.date, lte: new Date(endDate) };
    }

    const attendanceRecords = await prisma.attendance.findMany({
      where: whereClause,
      include: {
        student: {
          select: {
            id: true,
            name: true,
            studentId: true,
            year: true
          }
        },
        lab: {
          select: {
            id: true,
            name: true,
            year: true
          }
        }
      },
      orderBy: {
        date: 'desc'
      }
    });

    const formattedRecords = attendanceRecords.map(record => ({
      id: record.id,
      student_id: record.student.studentId,
      student_name: record.student.name,
      student_year: formatYear(record.student.year),
      lab_id: record.lab.id,
      lab_name: record.lab.name,
      date: record.date.toISOString(),
      status: record.status.toLowerCase(),
      marked_by: staffId
    }));

    console.log(`📋 Found ${formattedRecords.length} attendance records`);
    
    res.json(formattedRecords);

  } catch (e) {
    console.error('❌ Get staff attendance error:', e);
    return res.status(500).json({ error: e.message });
  }
}

// Mark single attendance
export async function markAttendance(req, res) {
  try {
    const staffId = req.user.id;
    const { student_id, lab_id, status } = req.body;

    console.log(`✅ Marking attendance: Student ${student_id}, Lab ${lab_id}, Status ${status}`);

    if (!student_id || !lab_id || !status) {
      return res.status(400).json({ error: 'Student ID, Lab ID, and status are required' });
    }

    const staffLab = await prisma.staffLabAssignment.findFirst({
      where: { 
        staffId,
        labId: parseInt(lab_id)
      },
      include: {
        lab: {
          select: { name: true }
        }
      }
    });

    if (!staffLab) {
      return res.status(403).json({ error: 'Access denied to this lab' });
    }

    const student = await prisma.user.findFirst({
      where: { 
        studentId: student_id,
        role: 'STUDENT'
      }
    });

    if (!student) {
      return res.status(404).json({ error: 'Student not found' });
    }

    const studentLabAssignment = await prisma.studentLabAssignment.findFirst({
      where: {
        studentId: student.id,
        labId: parseInt(lab_id)
      }
    });

    if (!studentLabAssignment) {
      return res.status(404).json({ error: 'Student not enrolled in this lab' });
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const existingAttendance = await prisma.attendance.findFirst({
      where: {
        studentId: student.id,
        labId: parseInt(lab_id),
        date: {
          gte: today,
          lt: tomorrow
        }
      }
    });

    let attendanceRecord;
    if (existingAttendance) {
      attendanceRecord = await prisma.attendance.update({
        where: { id: existingAttendance.id },
        data: { status: status.toUpperCase() }
      });
      console.log(`✅ Updated existing attendance record ${attendanceRecord.id}`);
    } else {
      attendanceRecord = await prisma.attendance.create({
        data: {
          studentId: student.id,
          labId: parseInt(lab_id),
          date: new Date(),
          status: status.toUpperCase()
        }
      });
      console.log(`✅ Created new attendance record ${attendanceRecord.id}`);
    }

    res.json({ 
      message: `Attendance marked successfully for ${student.name} in ${staffLab.lab.name}`,
      attendance: {
        id: attendanceRecord.id,
        student_id: student.studentId,
        student_name: student.name,
        lab_name: staffLab.lab.name,
        status: attendanceRecord.status.toLowerCase(),
        date: attendanceRecord.date.toISOString()
      }
    });

  } catch (e) {
    console.error('❌ Mark attendance error:', e);
    return res.status(500).json({ error: e.message });
  }
}

// Mark bulk attendance for multiple students
export async function bulkMarkAttendance(req, res) {
  try {
    const staffId = req.user.id;
    const { students, lab_id } = req.body;

    console.log(`✅ Bulk marking attendance for ${students.length} students in lab ${lab_id}`);

    if (!students || !Array.isArray(students) || students.length === 0) {
      return res.status(400).json({ error: 'Students array is required' });
    }

    if (!lab_id) {
      return res.status(400).json({ error: 'Lab ID is required' });
    }

    const staffLab = await prisma.staffLabAssignment.findFirst({
      where: { 
        staffId,
        labId: parseInt(lab_id)
      },
      include: {
        lab: {
          select: { name: true }
        }
      }
    });

    if (!staffLab) {
      return res.status(403).json({ error: 'Access denied to this lab' });
    }

    const results = [];
    const errors = [];

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    for (const studentRecord of students) {
      try {
        const { student_id, status } = studentRecord;

        if (!student_id || !status) {
          errors.push(`Missing student_id or status for record: ${JSON.stringify(studentRecord)}`);
          continue;
        }

        const student = await prisma.user.findFirst({
          where: { 
            studentId: student_id,
            role: 'STUDENT'
          }
        });

        if (!student) {
          errors.push(`Student not found: ${student_id}`);
          continue;
        }

        const studentLabAssignment = await prisma.studentLabAssignment.findFirst({
          where: {
            studentId: student.id,
            labId: parseInt(lab_id)
          }
        });

        if (!studentLabAssignment) {
          errors.push(`Student ${student_id} not enrolled in lab ${lab_id}`);
          continue;
        }

        const existingAttendance = await prisma.attendance.findFirst({
          where: {
            studentId: student.id,
            labId: parseInt(lab_id),
            date: {
              gte: today,
              lt: tomorrow
            }
          }
        });

        let attendanceRecord;
        if (existingAttendance) {
          attendanceRecord = await prisma.attendance.update({
            where: { id: existingAttendance.id },
            data: { status: status.toUpperCase() }
          });
        } else {
          attendanceRecord = await prisma.attendance.create({
            data: {
              studentId: student.id,
              labId: parseInt(lab_id),
              date: new Date(),
              status: status.toUpperCase()
            }
          });
        }

        results.push({ 
          student_id, 
          student_name: student.name,
          status: 'success', 
          attendance_id: attendanceRecord.id 
        });

      } catch (error) {
        errors.push(`Error for student ${studentRecord.student_id || 'unknown'}: ${error.message}`);
      }
    }

    console.log(`✅ Bulk attendance: ${results.length} success, ${errors.length} errors`);

    res.json({ 
      message: `Attendance marked for ${results.length} students in ${staffLab.lab.name}`,
      lab_name: staffLab.lab.name,
      results, 
      errors,
      summary: {
        total_attempted: students.length,
        successful: results.length,
        failed: errors.length
      }
    });
    
  } catch (e) {
    console.error('❌ Bulk attendance error:', e);
    return res.status(500).json({ error: e.message });
  }
}

// ✅ FIXED: Update attendance record
export async function updateAttendance(req, res) {
  try {
    const staffId = req.user.id;
    const attendanceId = parseInt(req.params.id);
    const { status } = req.body;

    console.log(`📝 Updating attendance record ${attendanceId} to ${status}`);

    if (!status) {
      return res.status(400).json({ error: 'Status is required' });
    }

    // Validate status value - must match database enum
    const validStatuses = ['PRESENT', 'ABSENT', 'LATE', 'EXCUSED', 'NOT_ENROLLED_BUT_MARKED', 'DUPLICATE'];
    const upperStatus = status.toUpperCase();
    if (!validStatuses.includes(upperStatus)) {
      return res.status(400).json({ error: `Invalid status. Must be one of: ${validStatuses.join(', ')}` });
    }

    // First, fetch the attendance record with lab and student info
    const attendance = await prisma.attendance.findUnique({
      where: { id: attendanceId },
      include: { 
        lab: {
          select: {
            id: true,
            name: true
          }
        },
        student: {
          select: { 
            id: true,
            name: true, 
            studentId: true 
          }
        }
      }
    });

    if (!attendance) {
      console.log(`❌ Attendance record ${attendanceId} not found`);
      return res.status(404).json({ error: 'Attendance record not found' });
    }

    // Check if staff has access to this lab
    const staffLabAssignment = await prisma.staffLabAssignment.findFirst({
      where: { 
        staffId,
        labId: attendance.labId
      }
    });

    if (!staffLabAssignment) {
      console.log(`❌ Staff ${staffId} not assigned to lab ${attendance.labId}`);
      return res.status(403).json({ error: 'Access denied to this attendance record' });
    }

    // Update the attendance record
    try {
      const updatedAttendance = await prisma.attendance.update({
        where: { id: attendanceId },
        data: { status: upperStatus }
      });

      console.log(`✅ Attendance record ${attendanceId} updated successfully`);

      res.json({ 
        message: 'Attendance updated successfully',
        attendance: {
          id: updatedAttendance.id,
          student_id: attendance.student.studentId,
          student_name: attendance.student.name,
          lab_name: attendance.lab.name,
          status: updatedAttendance.status.toLowerCase(),
          date: updatedAttendance.date.toISOString()
        }
      });
    } catch (prismaError) {
      // Handle Prisma enum validation errors
      if (prismaError.code === 'P2006' || prismaError.message.includes('enum')) {
        console.error(`❌ Invalid enum value: ${upperStatus}`);
        return res.status(400).json({ 
          error: `Invalid status value. Database only accepts: ${validStatuses.join(', ')}`
        });
      }
      throw prismaError; // Re-throw if it's a different error
    }
    
  } catch (e) {
    console.error('❌ Update attendance error:', e);
    console.error('❌ Error details:', {
      name: e.name,
      message: e.message,
      stack: e.stack
    });
    return res.status(500).json({ 
      error: e.message || 'Internal server error',
      details: process.env.NODE_ENV === 'development' ? e.stack : undefined
    });
  }
}

// Delete attendance record
export async function deleteAttendance(req, res) {
  try {
    const staffId = req.user.id;
    const attendanceId = parseInt(req.params.id);

    console.log(`🗑️  Deleting attendance record ${attendanceId}`);

    const attendance = await prisma.attendance.findUnique({
      where: { id: attendanceId },
      include: { 
        lab: {
          select: {
            id: true
          }
        }
      }
    });

    if (!attendance) {
      return res.status(404).json({ error: 'Attendance record not found' });
    }

    // Check if staff has access to this lab
    const staffLabAssignment = await prisma.staffLabAssignment.findFirst({
      where: { 
        staffId,
        labId: attendance.labId
      }
    });

    if (!staffLabAssignment) {
      return res.status(403).json({ error: 'Access denied to this attendance record' });
    }

    await prisma.attendance.delete({ where: { id: attendanceId } });

    console.log('✅ Attendance record deleted successfully');
    res.json({ message: 'Attendance record deleted successfully' });
    
  } catch (e) {
    console.error('❌ Delete attendance error:', e);
    return res.status(500).json({ error: e.message });
  }
}

// Get comprehensive staff statistics
export async function getStaffStats(req, res) {
  try {
    const staffId = req.user.id;
    
    console.log(`📊 Generating stats for staff ${staffId}`);
    
    const staffLabs = await prisma.staffLabAssignment.findMany({
      where: { staffId },
      include: { lab: { select: { name: true } } }
    });

    const assignedLabIds = staffLabs.map(sl => sl.labId);
    
    if (assignedLabIds.length === 0) {
      return res.json({
        total_labs: 0,
        total_students: 0,
        todays_attendance: 0,
        this_week_attendance: 0,
        attendance_percentage: 0,
        recent_activity: []
      });
    }

    const totalStudents = await prisma.studentLabAssignment.count({
      where: { labId: { in: assignedLabIds } }
    });

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    const todaysAttendance = await prisma.attendance.count({
      where: {
        labId: { in: assignedLabIds },
        date: { gte: today, lt: tomorrow }
      }
    });

    const weekStart = new Date(today);
    weekStart.setDate(today.getDate() - today.getDay());
    
    const thisWeekAttendance = await prisma.attendance.count({
      where: {
        labId: { in: assignedLabIds },
        date: { gte: weekStart }
      }
    });

    const daysInWeek = Math.ceil((today - weekStart) / (1000 * 60 * 60 * 24)) + 1;
    const expectedAttendance = totalStudents * daysInWeek;
    const attendancePercentage = expectedAttendance > 0 ? 
      Math.round((thisWeekAttendance / expectedAttendance) * 100) : 0;

    const recentActivity = await prisma.attendance.findMany({
      where: { labId: { in: assignedLabIds } },
      include: {
        student: { select: { name: true, studentId: true } },
        lab: { select: { name: true } }
      },
      orderBy: { date: 'desc' },
      take: 15
    });

    const formattedActivity = recentActivity.map(a => ({
      student_name: a.student.name,
      student_id: a.student.studentId,
      lab_name: a.lab.name,
      status: a.status.toLowerCase(),
      date: a.date.toISOString(),
      time_ago: getTimeAgo(a.date)
    }));

    const stats = {
      total_labs: assignedLabIds.length,
      total_students: totalStudents,
      todays_attendance: todaysAttendance,
      this_week_attendance: thisWeekAttendance,
      attendance_percentage: attendancePercentage,
      recent_activity: formattedActivity,
      summary: {
        labs_assigned: staffLabs.map(sl => sl.lab.name),
        daily_average: Math.round(thisWeekAttendance / Math.max(daysInWeek, 1)),
        completion_rate: totalStudents > 0 ? Math.round((todaysAttendance / totalStudents) * 100) : 0
      }
    };

    console.log(`📊 Generated stats: ${totalStudents} students, ${todaysAttendance} today, ${attendancePercentage}% weekly`);
    res.json(stats);

  } catch (e) {
    console.error('❌ Get staff stats error:', e);
    return res.status(500).json({ error: e.message });
  }
}

// Helper function to calculate time ago
function getTimeAgo(date) {
  const now = new Date();
  const diffMs = now - new Date(date);
  const diffMins = Math.floor(diffMs / (1000 * 60));
  const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

  if (diffMins < 60) return `${diffMins} minutes ago`;
  if (diffHours < 24) return `${diffHours} hours ago`;
  if (diffDays < 7) return `${diffDays} days ago`;
  return new Date(date).toLocaleDateString();
}