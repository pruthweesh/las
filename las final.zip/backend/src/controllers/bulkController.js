import multer from 'multer';
import csv from 'csv-parser';
import fs from 'fs';
import bcrypt from 'bcryptjs';
import { prisma } from '../config/prisma.js';

const upload = multer({ dest: 'uploads/' });

function parseCsvFile(path) {
  return new Promise((resolve, reject) => {
    const rows = [];
    fs.createReadStream(path)
      .pipe(csv({ mapHeaders: ({ header }) => header.trim().toLowerCase() }))
      .on('data', (data) => rows.push(data))
      .on('end', () => resolve(rows))
      .on('error', reject);
  });
}

/* ================= BULK STUDENTS ================= */
export const bulkStudents = [
  upload.single('file'),
  async (req, res) => {
    if (!req.file) return res.status(400).json({ error: 'CSV file missing' });

    const results = { created: 0, skipped: 0, errors: [] };
    const createdStudents = [];

    try {
      console.log('🟢 BULK STUDENT UPLOAD - Request received');

      // 🔹 Get HOD department
      const hod = await prisma.user.findUnique({
        where: { id: req.user.id },
        select: { department: true }
      });

      console.log('🟢 HOD department:', hod?.department);

      if (!hod?.department) throw new Error('HOD department not found');

      const rows = await parseCsvFile(req.file.path);
      console.log(`🟢 CSV parsed. Total rows: ${rows.length}`);

      for (const row of rows) {
        try {
          console.log('STUDENT ROW:', row);

          const name = row['full name'] || row.fullname || row.name;
          const email = row.email;
          const studentId = row['student id'] || row.studentid;
          const year = row.year;
          const labName = row.lab?.trim().replace(/\s+/g, ' ');
          const rawPass = row.password || row['temporary password'] || studentId;

          if (!name || !email || !labName || !studentId) throw new Error('Missing required fields');

          const lab = await prisma.lab.findFirst({ where: { name: labName } });
          if (!lab) throw new Error(`Lab not found: ${labName}`);

          const exists = await prisma.user.findUnique({ where: { email } });
          if (exists) throw new Error(`User exists: ${email}`);

          const password = await bcrypt.hash(rawPass.toString(), 10);

          const user = await prisma.user.create({
            data: {
              name,
              email,
              username: email,
              password,
              role: 'STUDENT',
              studentId,
              year,
              department: hod.department,
              temporaryPassword: true
            }
          });

          await prisma.studentLabAssignment.create({
            data: { studentId: user.id, labId: lab.id }
          });

          results.created++;
          createdStudents.push(user);
          console.log(`🟢 Student created: ${name} (${email})`);
        } catch (err) {
          results.skipped++;
          results.errors.push({ row, error: err.message });
          console.warn('⚠️ Student row skipped:', err.message);
        }
      }

      console.log(`🟢 BULK STUDENT UPLOAD COMPLETE - Created: ${results.created}, Skipped: ${results.skipped}`);

      res.json({ success: true, results, createdStudents });
    } catch (err) {
      console.error('❌ BULK STUDENT UPLOAD ERROR:', err.message);
      res.status(500).json({ error: err.message });
    } finally {
      fs.unlinkSync(req.file.path);
      console.log('🟢 Uploaded CSV file removed from server');
    }
  }
];

export const bulkStaff = [
  upload.single('file'),
  async (req, res) => {
    if (!req.file) {
      return res.status(400).json({ error: 'CSV file missing' });
    }

    const results = { created: 0, skipped: 0, errors: [] };
    const createdStaffList = [];

    try {
      console.log('🟢 BULK STAFF UPLOAD - Request received');

      const hod = await prisma.user.findUnique({
        where: { id: req.user.id },
        select: { department: true }
      });

      console.log('🟢 HOD department:', hod?.department);

      if (!hod?.department) {
        throw new Error('HOD department not found');
      }

      const rows = await parseCsvFile(req.file.path);
      console.log(`🟢 CSV parsed. Total rows: ${rows.length}`);

      for (const row of rows) {
        try {
          console.log('STAFF ROW:', row);

          const name = row.fullname || row['full name'] || row.name;
          const email = row.email;
          const subjects = row.subject;
          const rawPass = row.password || 'Temp123';

          if (!name || !email || !subjects) {
            throw new Error('Missing required fields');
          }

          const exists = await prisma.user.findUnique({
            where: { email }
          });

          if (exists) {
            throw new Error('User already exists');
          }

          const password = await bcrypt.hash(rawPass, 10);

          const staff = await prisma.user.create({
            data: {
              name,
              email,
              username: email,
              password,
              role: 'STAFF',
              department: hod.department,
              temporaryPassword: true
            }
          });

          const labs = subjects
            .split(',')
            .map(l => l.trim())
            .filter(Boolean);

          for (const labName of labs) {
            const lab = await prisma.lab.findFirst({
              where: { name: labName }
            });

            if (!lab) continue;

            await prisma.staffLabAssignment.upsert({
              where: {
                staffId_labId: {
                  staffId: staff.id,
                  labId: lab.id
                }
              },
              update: {},
              create: {
                staffId: staff.id,
                labId: lab.id
              }
            });
          }

          // ✅ FIX: send assignedLabs to frontend immediately
          createdStaffList.push({
            id: staff.id,
            name: staff.name,
            email: staff.email,
            role: staff.role,
            department: staff.department,
            assignedLabs: labs
          });

          results.created++;
          console.log(`🟢 Staff created: ${name} (${email})`);

        } catch (err) {
          results.skipped++;
          results.errors.push({ row, error: err.message });
          console.warn('⚠️ Staff row skipped:', err.message);
        }
      }

      console.log(
        `🟢 BULK STAFF UPLOAD COMPLETE - Created: ${results.created}, Skipped: ${results.skipped}`
      );

      res.json({
        success: true,
        results,
        createdStaff: createdStaffList
      });

    } catch (err) {
      console.error('❌ BULK STAFF UPLOAD ERROR:', err.message);
      res.status(500).json({ error: err.message });

    } finally {
      fs.unlinkSync(req.file.path);
      console.log('🟢 Uploaded CSV file removed from server');
    }
  }
];
