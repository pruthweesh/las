import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { prisma } from '../config/prisma.js';
import { signupHodSchema, loginSchema, changePasswordSchema } from '../utils/validators.js';

// ✅ FIXED: Include department and temporaryPassword in JWT token
function sign(user) {
  return jwt.sign(
    { 
      id: user.id, 
      role: user.role, 
      username: user.username, 
      name: user.name,
      department: user.department,
      temporaryPassword: user.temporaryPassword || false
    },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );
}

// ✅ Allow multiple HODs, each with a department
export async function signupHod(req, res) {
  try {
    const data = signupHodSchema.parse(req.body);

    const passwordHash = await bcrypt.hash(data.password, 10);
    const user = await prisma.user.create({
      data: {
        name: data.name,
        email: data.email,
        username: data.username,
        password: passwordHash,
        role: 'HOD',
        department: data.department
      }
    });

    res.status(201).json({
      user: { ...user, password: undefined },
      token: sign(user)
    });
  } catch (e) {
    if (e.code === 'P2002') {
      return res.status(400).json({ error: 'Username or email already exists' });
    }
    if (e.errors) {
      return res.status(400).json({ error: e.errors.map(x => x.message).join(', ') });
    }
    return res.status(500).json({ error: e.message });
  }
}

// ✅ ENHANCED LOGIN WITH DETAILED LOGGING
export async function login(req, res) {
  try {
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('📥 LOGIN REQUEST RECEIVED');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('Request Body:', JSON.stringify(req.body, null, 2));
    console.log('Client IP:', req.ip);
    console.log('Timestamp:', new Date().toISOString());
    
    // Validate request data
    const data = loginSchema.parse(req.body);
    console.log('✅ Request validation passed');
    console.log('   Username:', data.username);
    console.log('   Role:', data.role);
    
    // Find user in database
    const user = await prisma.user.findUnique({ 
      where: { username: data.username },
      select: {
        id: true,
        username: true,
        email: true,
        password: true,
        name: true,
        role: true,
        department: true,
        temporaryPassword: true,
        studentId: true,
        year: true
      }
    });
    
    if (!user) {
      console.log('❌ LOGIN FAILED: User not found');
      console.log('   Attempted username:', data.username);
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    console.log('✅ User found in database');
    console.log('   User ID:', user.id);
    console.log('   Username:', user.username);
    console.log('   Role in DB:', user.role);
    console.log('   Role requested:', data.role);
    
    // Check role match
    if (user.role !== data.role) {
      console.log('❌ LOGIN FAILED: Role mismatch');
      console.log('   Database role:', user.role);
      console.log('   Requested role:', data.role);
      console.log('   💡 TIP: Make sure you select the correct role from dropdown');
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    console.log('✅ Role verification passed');
    
    // Verify password
    console.log('🔐 Verifying password...');
    const passwordMatch = await bcrypt.compare(data.password, user.password);
    
    if (!passwordMatch) {
      console.log('❌ LOGIN FAILED: Password incorrect');
      console.log('   Username:', user.username);
      console.log('   💡 TIP: Check if password is correct');
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    console.log('✅ Password verification passed');
    
    // Generate JWT token
    const token = sign(user);
    console.log('✅ JWT token generated');
    console.log('   Token length:', token.length);
    
    // Prepare response
    const userResponse = { 
      ...user, 
      password: undefined,  // Never send password to client
      temporaryPassword: user.temporaryPassword || false
    };
    
    console.log('✅ LOGIN SUCCESSFUL');
    console.log('   User:', user.name);
    console.log('   Role:', user.role);
    console.log('   Department:', user.department || 'N/A');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
    
    res.json({ 
      token, 
      user: userResponse
    });
    
  } catch (e) {
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('❌ LOGIN ERROR');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.error('Error details:', e);
    console.log('Error name:', e.name);
    console.log('Error message:', e.message);
    
    if (e.errors) {
      console.log('Validation errors:', e.errors);
      return res.status(400).json({ 
        error: e.errors.map(x => x.message).join(', ') 
      });
    }
    
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
    return res.status(500).json({ 
      error: e.message || 'Internal server error during login'
    });
  }
}

export async function changeOwnPassword(req, res) {
  try {
    const data = changePasswordSchema.parse(req.body);
    const user = await prisma.user.findUnique({ where: { id: req.user.id } });

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const ok = await bcrypt.compare(data.currentPassword, user.password);
    if (!ok) return res.status(400).json({ error: 'Current password incorrect' });

    if (data.newPassword.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }

    const newHash = await bcrypt.hash(data.newPassword, 10);
    await prisma.user.update({
      where: { id: user.id },
      data: { 
        password: newHash,
        temporaryPassword: false
      }
    });

    console.log('✅ Password changed successfully for user:', user.username);
    res.json({ message: 'Password updated' });
  } catch (e) {
    console.error('❌ Change password error:', e);
    if (e.errors) {
      return res.status(400).json({ error: e.errors.map(x => x.message).join(', ') });
    }
    return res.status(500).json({ error: e.message });
  }
}

// ✅ FIXED: Reset password endpoint with proper validation
export async function resetPassword(req, res) {
  try {
    const { newPassword } = req.body;
    
    if (!newPassword || typeof newPassword !== 'string') {
      return res.status(400).json({ error: 'Password is required' });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }

    if (newPassword.length > 100) {
      return res.status(400).json({ error: 'Password is too long (maximum 100 characters)' });
    }

    const userId = req.user.id;
    const newHash = await bcrypt.hash(newPassword, 10);
    
    await prisma.user.update({
      where: { id: userId },
      data: { 
        password: newHash, 
        temporaryPassword: false 
      }
    });
    
    console.log('✅ Password reset successfully for user ID:', userId);
    res.json({ message: 'Password reset successfully' });
  } catch (e) {
    console.error('❌ Reset password error:', e);
    return res.status(500).json({ error: e.message || 'Failed to reset password' });
  }
}