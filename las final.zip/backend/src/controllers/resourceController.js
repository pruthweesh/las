// controllers/resourceController.js
import fs from 'fs';
import path from 'path';
import { prisma } from '../config/prisma.js';

// helper: get uploads dir (relative to project root)
const UPLOAD_DIR = path.join(process.cwd(), 'uploads', 'resources');

// Ensure upload dir exists
if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}

/**
 * Staff uploads a file for a particular lab (subject).
 * Expects multipart/form-data with fields:
 * - labId (number), title (string, optional), description (optional)
 * - file -> the uploaded file
 */
export async function uploadResource(req, res) {
  try {
    const staffId = req.user?.id;
    const { labId } = req.body;
    const title = req.body.title || req.file?.originalname || 'Resource';
    const description = req.body.description || null;

    if (!labId) {
      return res.status(400).json({ error: 'labId is required' });
    }

    // Validate that the staff is assigned to this lab
    const assigned = await prisma.staffLabAssignment.findUnique({
      where: { staffId_labId: { staffId: staffId, labId: parseInt(labId) } }
    }).catch(() => null);

    if (!assigned) {
      return res.status(403).json({ error: 'You are not assigned to this subject (lab)' });
    }

    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    // Save metadata to DB
    const resource = await prisma.resource.create({
      data: {
        title,
        description,
        filename: req.file.filename,
        originalName: req.file.originalname,
        mimeType: req.file.mimetype,
        size: req.file.size,
        lab: { connect: { id: parseInt(labId) } },
        uploadedBy: { connect: { id: staffId } },
      }
    });

    return res.json({ message: 'Uploaded', resource });
  } catch (err) {
    console.error('uploadResource error:', err);
    return res.status(500).json({ error: 'Upload failed', details: err.message });
  }
}

/**
 * List resources for a labId.
 * Authorization: student or staff. We'll verify the user belongs to the lab.
 */
export async function listResourcesByLab(req, res) {
  try {
    const userId = req.user?.id;
    const labId = parseInt(req.params.labId);

    // Check user (student or staff) is assigned to the lab
    // If student, check StudentLabAssignment
    // If staff, check StaffLabAssignment
    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user) return res.status(401).json({ error: 'Unauthorized' });

    let assignment;
    if (user.role === 'STUDENT') {
      assignment = await prisma.studentLabAssignment.findUnique({
        where: { studentId_labId: { studentId: userId, labId } }
      }).catch(() => null);
    } else {
      // staff or others
      assignment = await prisma.staffLabAssignment.findUnique({
        where: { staffId_labId: { staffId: userId, labId } }
      }).catch(() => null);
    }

    if (!assignment) {
      return res.status(403).json({ error: 'Access denied to this subject resources' });
    }

    const resources = await prisma.resource.findMany({
      where: { labId },
      include: {
        uploadedBy: {
          select: { id: true, name: true, email: true }
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    // Create an accessible URL for each resource (served via static /uploads/resources)
    const host = req.get('host');
    const protocol = req.protocol;
    const resourcesWithUrl = resources.map(r => ({
      id: r.id,
      title: r.title,
      description: r.description,
      originalName: r.originalName,
      mimeType: r.mimeType,
      size: r.size,
      uploadedBy: r.uploadedBy,
      createdAt: r.createdAt,
      url: `${protocol}://${host}/uploads/resources/${encodeURIComponent(r.filename)}`
    }));

    return res.json({ resources: resourcesWithUrl });
  } catch (err) {
    console.error('listResourcesByLab error:', err);
    return res.status(500).json({ error: err.message });
  }
}

/**
 * Download a resource by id with authorization check.
 * If you prefer not to expose static url, use this route to stream after checking permissions.
 */
export async function downloadResource(req, res) {
  try {
    const userId = req.user?.id;
    const resourceId = parseInt(req.params.id);

    const resource = await prisma.resource.findUnique({
      where: { id: resourceId },
      include: { lab: true }
    });

    if (!resource) return res.status(404).json({ error: 'Resource not found' });

    // Check assignment
    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user) return res.status(401).json({ error: 'Unauthorized' });

    let assignment;
    if (user.role === 'STUDENT') {
      assignment = await prisma.studentLabAssignment.findUnique({
        where: { studentId_labId: { studentId: userId, labId: resource.labId } }
      }).catch(() => null);
    } else {
      assignment = await prisma.staffLabAssignment.findUnique({
        where: { staffId_labId: { staffId: userId, labId: resource.labId } }
      }).catch(() => null);
    }

    if (!assignment) {
      return res.status(403).json({ error: 'Access denied to download this resource' });
    }

    const filePath = path.join(process.cwd(), 'uploads', 'resources', resource.filename);
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ error: 'File missing' });
    }

    res.setHeader('Content-Disposition', `attachment; filename="${resource.originalName}"`);
    res.setHeader('Content-Type', resource.mimeType || 'application/octet-stream');

    const stream = fs.createReadStream(filePath);
    stream.pipe(res);
  } catch (err) {
    console.error('downloadResource error:', err);
    return res.status(500).json({ error: err.message });
  }
}
