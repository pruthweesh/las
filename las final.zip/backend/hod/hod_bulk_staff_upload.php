echo json_encode([
    "created" => true,
    "message" => "Bulk staff upload successful"
]);
exit;
