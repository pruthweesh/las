
const BASE = process.env.REACT_APP_API || 'http://localhost:4000';

/**
 * Creates headers for API requests
 * @param {string} token - JWT authentication token
 * @returns {Object} Headers object with Content-Type and Authorization
 */
function _headers(token) {
  return {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
}

// ==================== CORE REQUEST HANDLER ====================
/**
 * Core HTTP request handler with comprehensive error handling
 * @param {string} path - API endpoint path
 * @param {Object} options - Request options (method, token, body)
 * @returns {Promise} Response data
 */
async function _req(path, { method = 'GET', token, body } = {}) {
  const url = `${BASE}${path}`;
  
  // Detailed logging for debugging
  console.log(`🌐 API Request: ${method} ${url}`);
  console.log(`🌐 BASE URL: ${BASE}`);
  if (body) console.log(`📤 Request body:`, body);
  if (token) console.log(`🔑 Token present: ${token.substring(0, 20)}...`);
  
  try {
    const res = await fetch(url, {
      method,
      headers: _headers(token),
      body: body ? JSON.stringify(body) : undefined,
      mode: 'cors',
      credentials: 'include'
    });
    
    console.log(`📡 Response status: ${res.status} ${res.statusText}`);
    
    // Parse JSON response
    let json;
    try {
      json = await res.json();
    } catch (jsonError) {
      console.error(`❌ JSON parsing failed:`, jsonError);
      json = { error: 'Invalid JSON response from server' };
    }
    
    // Handle error responses
    if (!res.ok) {
      console.error(`❌ API Error Response:`, json);
      throw json;
    }
    
    console.log(`✅ API Success Response:`, json);
    return json;
    
  } catch (fetchError) {
    console.error(`❌ Network/Fetch Error:`, fetchError);
    console.error(`❌ Error name: ${fetchError.name}`);
    console.error(`❌ Error message: ${fetchError.message}`);
    
    // Specific error handling for different error types
    if (fetchError.name === 'TypeError' && fetchError.message.includes('Failed to fetch')) {
      throw { 
        error: 'Cannot connect to backend server. Please check if the server is running on port 4000.',
        details: 'Connection failed - backend server may be down or unreachable.'
      };
    }
    
    if (fetchError.message && fetchError.message.includes('CORS')) {
      throw { 
        error: 'CORS error - backend server CORS configuration issue.',
        details: 'Cross-origin request blocked. Check backend CORS settings.'
      };
    }
    
    if (fetchError.message && fetchError.message.includes('NetworkError')) {
      throw { 
        error: 'Network error. Check your internet connection and backend server.',
        details: 'Network connectivity issue detected.'
      };
    }
    
    // Default error handling
    throw fetchError.error ? fetchError : { 
      error: `Connection failed: ${fetchError.message || 'Unknown error'}`,
      details: fetchError.message || 'An unexpected error occurred',
      originalError: fetchError.message,
      errorType: fetchError.name
    };
  }
}

// ==================== AUTHENTICATION ENDPOINTS ====================

/**
 * Login user with username, password, and role
 * @param {string} username - User's username
 * @param {string} password - User's password
 * @param {string} role - User's role (HOD, STAFF, STUDENT)
 * @returns {Promise} User data and JWT token
 */
export function login(username, password, role) {
  console.log(`🔐 Attempting login: ${username} as ${role}`);
  return _req('/auth/login', { method: 'POST', body: { username, password, role } });
}

/**
 * Register a new HOD account
 * @param {Object} payload - HOD registration data
 * @param {string} token - Admin JWT token
 * @returns {Promise} Registration result
 */
export function signupHOD(payload, token) {
  console.log(`📝 Registering new HOD:`, payload);
  return _req('/auth/signup-hod', { method: 'POST', token, body: payload });
}

/**
 * Change user's current password (requires current password)
 * @param {Object} data - Contains currentPassword and newPassword
 * @param {string} token - User's JWT token
 * @returns {Promise} Password change result
 */
export function changePassword({ currentPassword, newPassword }, token) {
  console.log(`🔑 Changing password`);
  return _req('/auth/change-password', { method: 'POST', token, body: { currentPassword, newPassword } });
}

/**
 * Reset password (for first-time login with temporary password)
 * @param {Object} data - Contains newPassword
 * @param {string} token - User's JWT token
 * @returns {Promise} Password reset result
 */
export function resetPassword({ newPassword }, token) {
  console.log(`🔄 Resetting password`);
  return _req('/auth/reset-password', { method: 'POST', token, body: { newPassword } });
}

// ==================== USER MANAGEMENT ENDPOINTS ====================

/**
 * Fetch all users with optional query filters
 * @param {string} token - JWT token
 * @param {Object} query - Optional query parameters (role, year, etc.)
 * @returns {Promise} Array of users
 */
export function fetchUsers(token, query = {}) {
  console.log(`👥 Fetching users with query:`, query);
  const q = Object.keys(query).length ? `?${new URLSearchParams(query).toString()}` : '';
  return _req(`/users${q}`, { token });
}

/**
 * Create a new user (HOD/STAFF/STUDENT)
 * @param {Object} payload - User data (name, role, year, etc.)
 * @param {string} token - JWT token
 * @returns {Promise} Created user with temporary password
 */
export function createUser(payload, token) {
  console.log(`➕ Creating user:`, payload);
  return _req('/users', { method: 'POST', token, body: payload });
}

/**
 * Delete a user by ID
 * @param {number|string} userId - User's ID
 * @param {string} token - JWT token
 * @returns {Promise} Deletion result
 */
export function deleteUser(userId, token) {
  console.log(`🗑️ Deleting user: ${userId}`);
  return _req(`/users/${encodeURIComponent(userId)}`, { method: 'DELETE', token });
}

/**
 * Update a user's password (admin function)
 * @param {number|string} userId - User's ID
 * @param {string} newPassword - New password
 * @param {string} token - JWT token
 * @returns {Promise} Update result
 */
export function setUserPassword(userId, newPassword, token) {
  console.log(`🔐 Setting password for user: ${userId}`);
  return _req(`/users/${encodeURIComponent(userId)}/password`, { method: 'PATCH', token, body: { newPassword } });
}

/**
 * Assign labs to a student
 * @param {number|string} studentId - Student's ID
 * @param {Array} labs - Array of lab IDs or names
 * @param {string} token - JWT token
 * @returns {Promise} Assignment result
 */
export function assignStudentLabs(studentId, labs, token) {
  console.log(`🧪 Assigning labs to student ${studentId}:`, labs);
  return _req(`/users/students/${encodeURIComponent(studentId)}/labs`, { method: 'PUT', token, body: { labs } });
}

// ==================== DEBUG FUNCTIONS ====================

/**
 * Debug: Get all users from database (for troubleshooting)
 * @param {string} token - JWT token
 * @returns {Promise} All users in database
 */
export function debugGetAllUsers(token) {
  console.log(`🔍 DEBUG: Getting all users from database`);
  return _req('/users/debug/all', { token });
}

/**
 * Test backend server connection
 * @returns {Promise} Health check result
 */
export function testBackendConnection() {
  console.log(`🏥 Testing backend health`);
  return _req('/health', {});
}

// ==================== LAB & SUBJECT MANAGEMENT ====================

/**
 * Get all labs
 * @param {string} token - JWT token
 * @returns {Promise} Array of labs
 */
export function listLabs(token) {
  console.log(`📚 Listing all labs`);
  return _req('/labs', { token });
}

/**
 * Get subjects for a specific year
 * @param {string} year - Year (2nd Year, 3rd Year, 4th Year)
 * @param {string} token - JWT token
 * @returns {Promise} Array of subjects for the year
 */
export function getYearSubjects(year, token) {
  console.log(`📖 Getting subjects for ${year}`);
  return _req(`/labs/years/${encodeURIComponent(year)}`, { token });
}

/**
 * Set/update subjects for a specific year
 * @param {string} year - Year (2nd Year, 3rd Year, 4th Year)
 * @param {Array} subjects - Array of subject names
 * @param {string} token - JWT token
 * @returns {Promise} Update result
 */
export function setYearSubjects(year, subjects, token) {
  console.log(`📝 Setting subjects for ${year}:`, subjects);
  return _req(`/labs/years/${encodeURIComponent(year)}`, { method: 'PUT', token, body: { subjects } });
}

/**
 * Add a new lab subject
 * @param {string} labName - Lab name
 * @param {string} year - Year (2nd Year, 3rd Year, 4th Year)
 * @param {string} token - JWT token
 * @returns {Promise} Created lab
 */
export function addLabSubject(labName, year, token) {
  console.log(`➕ Adding lab subject: ${labName} for ${year}`);
  
  // Enhanced validation
  if (!labName || !year) {
    throw { error: 'Lab name and year are required' };
  }
  
  const cleanLabName = labName.toString().trim();
  const cleanYear = year.toString().trim();
  
  if (cleanLabName.length === 0) {
    throw { error: 'Lab name cannot be empty' };
  }
  
  if (cleanLabName.length > 100) {
    throw { error: 'Lab name is too long (maximum 100 characters)' };
  }
  
  const validYears = ['2nd Year', '3rd Year', '4th Year'];
  if (!validYears.includes(cleanYear)) {
    throw { error: `Invalid year format. Must be one of: ${validYears.join(', ')}` };
  }
  
  return _req('/labs', { 
    method: 'POST', 
    token, 
    body: { name: cleanLabName, year: cleanYear } 
  });
}

/**
 * Remove/delete a lab subject by name and year
 * @param {string} labName - Lab name
 * @param {string} year - Year (2nd Year, 3rd Year, 4th Year)
 * @param {string} token - JWT token
 * @returns {Promise} Deletion result
 */
export function removeLabSubject(labName, year, token) {
  console.log(`🗑️ Removing lab subject: ${labName} for ${year}`);
  
  // Enhanced validation
  if (!labName || !year) {
    throw { error: 'Lab name and year are required' };
  }
  
  const cleanLabName = labName.toString().trim();
  const cleanYear = year.toString().trim();
  
  if (cleanLabName.length === 0) {
    throw { error: 'Lab name cannot be empty' };
  }
  
  const validYears = ['2nd Year', '3rd Year', '4th Year'];
  if (!validYears.includes(cleanYear)) {
    throw { error: `Invalid year format. Must be one of: ${validYears.join(', ')}` };
  }
  
  return _req('/labs/by-name-year', { 
    method: 'DELETE', 
    token, 
    body: { name: cleanLabName, year: cleanYear } 
  });
}

/**
 * Bulk assign students to multiple labs by year
 * @param {string} year - Year (2nd Year, 3rd Year, 4th Year)
 * @param {Array} labNames - Array of lab names to assign
 * @param {string} token - JWT token
 * @returns {Promise} Assignment result with count
 */
export function bulkAssignStudentsByYear(year, labNames, token) {
  console.log(`🎯 Bulk assigning ${labNames?.length || 0} labs to ${year} students:`, labNames);
  
  // Enhanced validation
  if (!year || !labNames) {
    throw { error: 'Year and lab names are required' };
  }
  
  if (!Array.isArray(labNames)) {
    throw { error: 'Lab names must be an array' };
  }
  
  const cleanYear = year.toString().trim();
  const cleanLabNames = labNames
    .map(name => name ? name.toString().trim() : '')
    .filter(name => name.length > 0);
  
  if (cleanLabNames.length === 0) {
    throw { error: 'At least one valid lab name is required' };
  }
  
  const validYears = ['2nd Year', '3rd Year', '4th Year'];
  if (!validYears.includes(cleanYear)) {
    throw { error: `Invalid year format. Must be one of: ${validYears.join(', ')}` };
  }
  
  return _req('/labs/bulk-assign', { 
    method: 'POST', 
    token, 
    body: { year: cleanYear, labNames: cleanLabNames } 
  });
}

// ==================== HOD LAB MANAGEMENT ====================

/**
 * Create a new lab (HOD function)
 * @param {Object} labData - Lab data (name, year, description)
 * @param {string} token - JWT token
 * @returns {Promise} Created lab
 */
export function createLab(labData, token) {
  console.log(`🏗️ Creating lab:`, labData);
  
  if (!labData || !labData.name || !labData.year) {
    throw { error: 'Lab name and year are required' };
  }
  
  return _req('/labs', { method: 'POST', token, body: labData });
}

/**
 * Update an existing lab (HOD function)
 * @param {number} labId - Lab ID
 * @param {Object} labData - Updated lab data
 * @param {string} token - JWT token
 * @returns {Promise} Updated lab
 */
export function updateLab(labId, labData, token) {
  console.log(`✏️ Updating lab ${labId}:`, labData);
  
  if (!labId || isNaN(parseInt(labId))) {
    throw { error: 'Valid lab ID is required' };
  }
  
  if (!labData || !labData.name || !labData.year) {
    throw { error: 'Lab name and year are required' };
  }
  
  return _req(`/labs/${labId}`, { method: 'PUT', token, body: labData });
}

/**
 * Delete a lab (HOD function)
 * @param {number} labId - Lab ID
 * @param {string} token - JWT token
 * @returns {Promise} Deletion result
 */
export function deleteLab(labId, token) {
  console.log(`🗑️ Deleting lab ${labId}`);
  
  if (!labId || isNaN(parseInt(labId))) {
    throw { error: 'Valid lab ID is required' };
  }
  
  return _req(`/labs/${labId}`, { method: 'DELETE', token });
}

/**
 * Assign staff member to multiple labs (HOD function)
 * @param {number} staffId - Staff member's ID
 * @param {Array} labIds - Array of lab IDs
 * @param {string} token - JWT token
 * @returns {Promise} Assignment result
 */
export function assignStaffToLabs(staffId, labIds, token) {
  console.log(`👨‍🏫 Assigning staff ${staffId} to labs:`, labIds);
  
  if (!staffId || isNaN(parseInt(staffId))) {
    throw { error: 'Valid staff ID is required' };
  }
  
  if (!Array.isArray(labIds) || labIds.length === 0) {
    throw { error: 'Lab IDs array is required' };
  }
  
  const cleanLabIds = labIds.filter(id => !isNaN(parseInt(id)));
  if (cleanLabIds.length === 0) {
    throw { error: 'At least one valid lab ID is required' };
  }
  
  return _req('/labs/assign-staff', { 
    method: 'POST', 
    token, 
    body: { staffId: parseInt(staffId), labIds: cleanLabIds.map(id => parseInt(id)) } 
  });
}

/**
 * Assign multiple students to a lab (HOD function)
 * @param {number} labId - Lab ID
 * @param {Array} studentIds - Array of student IDs
 * @param {string} token - JWT token
 * @returns {Promise} Assignment result
 */
export function assignStudentsToLab(labId, studentIds, token) {
  console.log(`👨‍🎓 Assigning students to lab ${labId}:`, studentIds);
  
  if (!labId || isNaN(parseInt(labId))) {
    throw { error: 'Valid lab ID is required' };
  }
  
  if (!Array.isArray(studentIds) || studentIds.length === 0) {
    throw { error: 'Student IDs array is required' };
  }
  
  const cleanStudentIds = studentIds.filter(id => !isNaN(parseInt(id)));
  if (cleanStudentIds.length === 0) {
    throw { error: 'At least one valid student ID is required' };
  }
  
  return _req('/labs/assign-students', { 
    method: 'POST', 
    token, 
    body: { labId: parseInt(labId), studentIds: cleanStudentIds.map(id => parseInt(id)) } 
  });
}

/**
 * Get lab assignment report (HOD function)
 * @param {string} token - JWT token
 * @returns {Promise} Report with lab assignments
 */
export function getLabAssignmentReport(token) {
  console.log(`📊 Getting lab assignment report`);
  return _req('/labs/report', { token });
}

// ==================== GENERAL ATTENDANCE ENDPOINTS ====================

/**
 * Submit attendance record
 * @param {Object} payload - Attendance data (student_id, lab_id, date, status)
 * @param {string} token - JWT token
 * @returns {Promise} Submitted attendance record
 */
export function submitAttendance(payload, token) {
  console.log(`✅ Submitting attendance:`, payload);
  return _req('/attendance', { method: 'POST', token, body: payload });
}

/**
 * Fetch attendance records for a specific student
 * @param {number|string} studentId - Student's ID
 * @param {string} token - JWT token
 * @returns {Promise} Student's attendance records
 */
export function fetchStudentAttendance(studentId, token) {
  console.log(`📋 Fetching attendance for student: ${studentId}`);
  return _req(`/attendance/student/${encodeURIComponent(studentId)}`, { token });
}

/**
 * Fetch attendance summary (HOD function)
 * @param {string} token - JWT token
 * @returns {Promise} Overall attendance summary
 */
export function fetchSummary(token) {
  console.log(`📊 Fetching attendance summary`);
  return _req('/attendance/summary', { token });
}

// ==================== STAFF ENDPOINTS ====================

/**
 * Get staff dashboard data
 * @param {string} token - Staff JWT token
 * @returns {Promise} Dashboard data with stats
 */
export function getStaffDashboard(token) {
  console.log(`📊 Getting staff dashboard`);
  return _req('/staff/dashboard', { token });
}

/**
 * Get labs assigned to staff member
 * @param {string} token - Staff JWT token
 * @returns {Promise} Array of assigned labs
 */
export function getStaffLabs(token) {
  console.log(`🧪 Getting staff labs`);
  return _req('/staff/labs', { token });
}

/**
 * Get students for staff (optionally filtered by lab)
 * @param {string} token - Staff JWT token
 * @param {number} labId - Optional lab ID filter
 * @returns {Promise} Array of students
 */
export function getStaffStudents(token, labId = null) {
  console.log(`👥 Getting staff students${labId ? ` for lab ${labId}` : ''}`);
  // ✅ CHANGED: Use query parameter instead of path parameter
  const endpoint = labId ? `/staff/students?labId=${labId}` : '/staff/students';
  return _req(endpoint, { token });
}

/**
 * Get attendance records for staff (optionally filtered by lab)
 * @param {string} token - Staff JWT token
 * @param {number} labId - Optional lab ID filter
 * @returns {Promise} Array of attendance records
 */
export function getStaffAttendance(token, labId = null) {
  console.log(`📋 Getting staff attendance${labId ? ` for lab ${labId}` : ''}`);
  // ✅ CHANGED: Use query parameter instead of path parameter
  const endpoint = labId ? `/staff/attendance?labId=${labId}` : '/staff/attendance';
  return _req(endpoint, { token });
}

/**
 * Mark attendance for students (staff function)
 * @param {Object} attendanceData - Attendance data
 * @param {string} token - Staff JWT token
 * @returns {Promise} Marked attendance record
 */
export function markStaffAttendance(attendanceData, token) {
  console.log(`✅ Marking attendance:`, attendanceData);
  return _req('/staff/attendance', { method: 'POST', token, body: attendanceData });
}

/**
 * Mark bulk attendance for multiple students (staff function)
 * @param {Object} bulkData - Bulk attendance data
 * @param {string} token - Staff JWT token
 * @returns {Promise} Bulk marking result
 */
export function markBulkStaffAttendance(bulkData, token) {
  console.log(`✅ Marking bulk attendance:`, bulkData);
  return _req('/staff/bulk-attendance', { method: 'POST', token, body: bulkData });
}

/**
 * Update an existing attendance record (staff function)
 * @param {number} attendanceId - Attendance record ID
 * @param {Object} updateData - Updated data
 * @param {string} token - Staff JWT token
 * @returns {Promise} Updated attendance record
 */
export function updateStaffAttendance(attendanceId, updateData, token) {
  console.log(`✏️ Updating attendance ${attendanceId}:`, updateData);
  return _req(`/staff/attendance/${attendanceId}`, { method: 'PUT', token, body: updateData });
}

/**
 * Delete an attendance record (staff function)
 * @param {number} attendanceId - Attendance record ID
 * @param {string} token - Staff JWT token
 * @returns {Promise} Deletion result
 */
export function deleteStaffAttendance(attendanceId, token) {
  console.log(`🗑️ Deleting attendance ${attendanceId}`);
  return _req(`/staff/attendance/${attendanceId}`, { method: 'DELETE', token });
}

/**
 * Get staff statistics
 * @param {string} token - Staff JWT token
 * @returns {Promise} Statistics object
 */
export function getStaffStats(token) {
  console.log(`📊 Getting staff statistics`);
  return _req('/staff/stats', { token });
}

// ==================== STUDENT ENDPOINTS ====================

/**
 * Get student dashboard data
 * @param {string} token - Student JWT token
 * @returns {Promise} Dashboard data with attendance summary
 */
export function getStudentDashboard(token) {
  console.log(`📊 Getting student dashboard`);
  return _req('/students/dashboard', { token });
}

/**
 * Get student's attendance records (optionally filtered by lab)
 * @param {string} token - Student JWT token
 * @param {number} labId - Optional lab ID filter
 * @returns {Promise} Array of attendance records
 */
export function getStudentAttendance(token, labId = null) {
  console.log(`📋 Getting student attendance${labId ? ` for lab ${labId}` : ''}`);
  const endpoint = labId ? `/students/attendance?lab_id=${labId}` : '/students/attendance';
  return _req(endpoint, { token });
}

/**
 * Get student's attendance statistics
 * @param {string} token - Student JWT token
 * @returns {Promise} Attendance statistics (percentages, trends)
 */
export function getStudentAttendanceStats(token) {
  console.log(`📈 Getting student attendance statistics`);
  return _req('/students/stats', { token });
}

/**
 * Get labs assigned to student
 * @param {string} token - Student JWT token
 * @returns {Promise} Array of assigned labs
 */
export function getStudentLabs(token) {
  console.log(`🧪 Getting student labs`);
  return _req('/students/labs', { token });
}

/**
 * Get student's notifications
 * @param {string} token - Student JWT token
 * @returns {Promise} Array of notifications
 */
export function getStudentNotifications(token) {
  console.log(`🔔 Getting student notifications`);
  return _req('/students/notifications', { token });
}

/**
 * Mark a notification as read
 * @param {number} notificationId - Notification ID
 * @param {string} token - Student JWT token
 * @returns {Promise} Update result
 */
export function markStudentNotificationRead(notificationId, token) {
  console.log(`✅ Marking notification ${notificationId} as read`);
  return _req(`/students/notifications/${notificationId}/read`, { method: 'POST', token });
}

/**
 * Update student profile
 * @param {Object} profileData - Profile data to update
 * @param {string} token - Student JWT token
 * @returns {Promise} Updated profile
 */
export function updateStudentProfile(profileData, token) {
  console.log(`👤 Updating student profile:`, profileData);
  return _req('/students/profile', { method: 'PUT', token, body: profileData });
}

// ==================== GENERIC HTTP METHODS ====================

/**
 * Generic GET request
 * @param {string} path - API endpoint path
 * @param {string} token - JWT token
 * @returns {Promise} Response data
 */
export function get(path, token) {
  return _req(path, { method: 'GET', token });
}

/**
 * Generic POST request
 * @param {string} path - API endpoint path
 * @param {Object} body - Request body
 * @param {string} token - JWT token
 * @returns {Promise} Response data
 */
export function post(path, body, token) {
  console.log(`📤 POST ${path}:`, body);
  return _req(path, { method: 'POST', token, body });
}

/**
 * Generic PUT request
 * @param {string} path - API endpoint path
 * @param {Object} body - Request body
 * @param {string} token - JWT token
 * @returns {Promise} Response data
 */
export function put(path, body, token) {
  console.log(`📤 PUT ${path}:`, body);
  return _req(path, { method: 'PUT', token, body });
}

/**
 * Generic PATCH request
 * @param {string} path - API endpoint path
 * @param {Object} body - Request body
 * @param {string} token - JWT token
 * @returns {Promise} Response data
 */
export function patch(path, body, token) {
  console.log(`📤 PATCH ${path}:`, body);
  return _req(path, { method: 'PATCH', token, body });
}

/**
 * Generic DELETE request
 * @param {string} path - API endpoint path
 * @param {string} token - JWT token
 * @returns {Promise} Response data
 */
export function deleteRequest(path, token) {
  console.log(`🗑️ DELETE ${path}`);
  return _req(path, { method: 'DELETE', token });
}

// inside api.js (export area)
async function uploadResource(formData, token) {
  const url = `${BASE}/api/resources/upload`;
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      ...(token ? { Authorization: `Bearer ${token}` } : {})
      // DO NOT set Content-Type explicitly for multipart/form-data
    },
    body: formData
  });
  return res.json();
}

async function getResourcesByLab(labId, token) {
  const url = `${BASE}/api/resources/lab/${encodeURIComponent(labId)}`;
  return _req(`/resources/lab/${encodeURIComponent(labId)}`, { method: 'GET', token });
}


// ==================== DEFAULT EXPORT ====================
// Export all functions as a default object for easy importing

export default {
  // Authentication
  login,
  signupHOD,
  changePassword,
  resetPassword,
  
  // User Management
  fetchUsers,
  createUser,
  deleteUser,
  setUserPassword,
  assignStudentLabs,
  
  // Debug Functions
  debugGetAllUsers,
  testBackendConnection,
  
  // Lab & Subject Management
  listLabs,
  getYearSubjects,
  setYearSubjects,
  addLabSubject,
  removeLabSubject,
  bulkAssignStudentsByYear,
  
  // General Attendance
  submitAttendance,
  fetchStudentAttendance,
  fetchSummary,
  
  // Staff Functions
  getStaffDashboard,
  getStaffLabs,
  getStaffStudents,
  getStaffAttendance,
  markStaffAttendance,
  markBulkStaffAttendance,
  updateStaffAttendance,
  deleteStaffAttendance,
  getStaffStats,
  
  // Student Functions
  getStudentDashboard,
  getStudentAttendance,
  getStudentAttendanceStats,
  getStudentLabs,
  getStudentNotifications,
  markStudentNotificationRead,
  updateStudentProfile,
  
  // HOD Lab Management
  createLab,
  updateLab,
  deleteLab,
  assignStaffToLabs,
  assignStudentsToLab,
  getLabAssignmentReport,
  
  // Generic HTTP Methods
  get,
  post,
  put,
  patch,
  delete: deleteRequest,
  uploadResource,
  getResourcesByLab,
};