// components/HODDashboard.js
import React, { useEffect, useState } from "react";

import { saveAuth, getToken, getUser, clearAuth } from '../utils/auth';
import api from '../utils/api';

import { 
  FaUser, FaSignOutAlt, FaFilter, FaPlus, FaKey, FaEye, FaDownload, 
  FaTrash, FaChevronRight, FaBell, FaUsers, FaChartPie, FaCog, FaCheck, FaTimes,
  FaBook, FaGraduationCap, FaEdit, FaSave, FaCheckCircle, FaExclamationTriangle
} from 'react-icons/fa';
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const HODDashboard = ({ 
  currentUser = { name: 'Dr. John Smith', email: 'john.smith@university.edu' },
  handleLogout = () => console.log('Logout'),
}) => {
  // State Management
  const [users, setUsers] = useState([]);
  const [yearFilter, setYearFilter] = useState('All');
  const [labFilter, setLabFilter] = useState('All Labs');
  const [openDropdowns, setOpenDropdowns] = useState({});
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [showAddModal, setShowAddModal] = useState(null);
  const [tempPassword, setTempPassword] = useState(null);
  const [activeSection, setActiveSection] = useState('overview');
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showChangePassword, setShowChangePassword] = useState(false);
  const [drilldownYear, setDrilldownYear] = useState(null);
  const [studentIdSearch, setStudentIdSearch] = useState('');
  const [showLabAssignModal, setShowLabAssignModal] = useState(null);
  const [selectedStaffLabs, setSelectedStaffLabs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [allLabs, setAllLabs] = useState([]);
  const [summary, setSummary] = useState({});
  const [yearSubjects, setYearSubjects] = useState({});
  
  // Lab Subject Management States
  const [selectedYear, setSelectedYear] = useState('2nd Year');
  const [labSubjects, setLabSubjects] = useState({
    '2nd Year': ['Physics Lab', 'Chemistry Lab'],
    '3rd Year': ['Electronics Lab', 'Computer Lab', 'Circuit Analysis Lab'],
    '4th Year': ['Project Lab', 'Advanced Electronics Lab', 'Research Lab']
  });
  const [newSubject, setNewSubject] = useState('');
  const [editingSubject, setEditingSubject] = useState(null);
  const [editingValue, setEditingValue] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [notification, setNotification] = useState({ type: '', message: '' });
  const [notifications, setNotifications] = useState([]);
  const [students, setStudents] = useState([]);
  const [attendance, setAttendance] = useState([]);
  const [staff, setStaff] = useState([]);
  
  // ADD these state variables
const [showAddLabModal, setShowAddLabModal] = useState(false);

  // Helper function to normalize year format
  const normalizeYear = (year) => {
    if (!year) return null;
    const yearStr = year.toString().toLowerCase().trim();
    if (yearStr === '2' || yearStr === '2nd' || yearStr === 'second' || yearStr === '2nd year') return '2nd Year';
    if (yearStr === '3' || yearStr === '3rd' || yearStr === 'third' || yearStr === '3rd year') return '3rd Year';
    if (yearStr === '4' || yearStr === '4th' || yearStr === 'fourth' || yearStr === '4th year') return '4th Year';
    return year;
  };

 
 const loadAllUsers = async () => {
  try {
    console.log("\n🟦 ===== FRONTEND DEBUG SESSION =====");
    console.log("🟦 Step 1: Starting loadAllUsers");
    
    setLoading(true);
    setError(null);
    const token = getToken();

    console.log("🟦 Step 2: Token check");
    console.log("  - Token exists:", !!token);

    console.log("🟦 Step 3: Making API call to /users/hod/dashboard");
    const res = await api.get("/users/hod/dashboard", token);
    
    console.log("🟦 Step 4: RAW API Response received:");
    console.log("  - Full response:", res);
    
    // 🔥 FIX: Extract all data including students with lab assignments
    console.log("\n🟦 Step 5: Extracting data from response");
    console.log("  - res.students:", res.students ? `Array of ${res.students.length}` : "undefined/null");
    console.log("  - res.staff:", res.staff ? `Array of ${res.staff.length}` : "undefined/null");
    console.log("  - res.attendance:", res.attendance ? `Array of ${res.attendance.length}` : "undefined/null");
    
    // Check if students have assignedLabs
    if (res.students && res.students.length > 0) {
      console.log("  - Sample student:", res.students[0]);
      console.log("  - Student has assignedLabs:", !!res.students[0].assignedLabs);
      if (res.students[0].assignedLabs) {
        console.log("  - Student assignedLabs:", res.students[0].assignedLabs);
      }
    }
    
    // 🔥 FIX: Combine students and staff into users array
    const allUsers = [...(res.students || []), ...(res.staff || [])];
    console.log("🟦 Step 6: Combined users array length:", allUsers.length);
    
    // Set all state with the response data
    setUsers(allUsers);
    setStudents(res.students || []);
    setStaff(res.staff || []);
    setAttendance(res.attendance || []); // 🔥 Store attendance separately
    
    setSummary({
      totalStudents: res.studentsCount || 0,
      totalStaff: res.staffCount || 0,
      totalLabAssignments: res.totalLabAssignments || 0,
      avgAttendance: res.avgAttendance || 0
    });
    
    console.log("🟦 Step 7: State updated successfully");
    console.log("  - users:", allUsers.length);
    console.log("  - students:", res.students?.length || 0);
    console.log("  - staff:", res.staff?.length || 0);
    console.log("  - attendance:", res.attendance?.length || 0);
    
    // Log students with lab assignments for debugging
    const studentsWithLabs = (res.students || []).filter(s => s.assignedLabs && s.assignedLabs.length > 0);
    console.log("  - Students with lab assignments:", studentsWithLabs.length);
    if (studentsWithLabs.length > 0) {
      console.log("  - Example student with labs:", {
        name: studentsWithLabs[0].name,
        year: studentsWithLabs[0].year,
        assignedLabs: studentsWithLabs[0].assignedLabs
      });
    }
    
    setLoading(false);
    console.log("🟦 ===== FRONTEND DEBUG COMPLETE =====\n");
    
  } catch (err) {
    console.error("❌ Error in loadAllUsers:", err);
    setError(err.message || 'Failed to load data');
    setLoading(false);
  }
};




  const loadAllLabs = async () => {
    try {
      console.log('📚 Loading all labs from API...');
      const labs = await api.get('/labs', getToken());
      setAllLabs(labs);
      
      console.log(`✅ Loaded ${labs.length} labs:`);
      labs.forEach(lab => {
        console.log(`   ${lab.name} (${lab.year}): ${lab.student_count} students, ${lab.staff_count} staff`);
      });
      
      return labs;
    } catch (error) {
      console.error('❌ Load labs error:', error);
      showNotification('error', 'Failed to load lab data');
      return [];
    }
  };

  const loadLabSubjects = async () => {
  try {
    console.log('📚 Loading lab subjects from database...');
    
    const allLabs = await api.listLabs(getToken());
    console.log('📊 All labs loaded:', allLabs.length);
    
    // Organize labs by year
    const subjectsByYear = {
      '2nd Year': [],
      '3rd Year': [],
      '4th Year': []
    };
    
    allLabs.forEach(lab => {
      if (subjectsByYear[lab.year]) {
        subjectsByYear[lab.year].push(lab.name);
      }
    });
    
    // Sort subjects alphabetically within each year
    Object.keys(subjectsByYear).forEach(year => {
      subjectsByYear[year].sort();
    });
    
    console.log('📋 Subjects by year:', subjectsByYear);
    setLabSubjects(subjectsByYear);
    
  } catch (error) {
    console.error('❌ Load lab subjects error:', error);
    
    let errorMessage = 'Failed to load lab subjects from database';
    
    if (error.error) {
      errorMessage = error.error;
    } else if (error.details) {
      errorMessage = error.details;
    } else if (error.message) {
      errorMessage = error.message;
    }
    
    if (errorMessage.includes('connection') || errorMessage.includes('fetch')) {
      errorMessage = 'Cannot connect to server. Please check if the backend is running.';
    }
    
    showNotification('error', errorMessage);
    
    // Set empty state on error
    setLabSubjects({
      '2nd Year': [],
      '3rd Year': [],
      '4th Year': []
    });
  }
};

const yearOrder = ["2nd Year", "3rd Year", "4th Year"];
const uniqueYears = yearOrder;

useEffect(() => {
  const initializeData = async () => {
    if (getToken()) {
      loadLabSubjects();
      loadLabSubjectsFromDatabase();
      try {
        setLoading(true);
        
        // Load users first
        await loadAllUsers();
        
        // Then load labs
        await loadAllLabs();
        
        // Validate assignments (optional - for debugging)
        const report = await validateAssignments();
        if (report) {
          console.log('✅ Data initialization complete with validation');
        }
        
      } catch (error) {
        console.error('❌ Data initialization failed:', error);
        setError('Failed to load dashboard data');
      } finally {
        setLoading(false);
      }
    }
  };
  
  initializeData();
}, []);


// ADD this function to sync lab subjects with database
const syncLabSubjectsWithDB = async () => {
  try {
    const token = getToken();
    
    // Get all unique lab subjects from all years
    const allSubjects = [];
    Object.keys(labSubjects).forEach(year => {
      if (labSubjects[year]) {
        labSubjects[year].forEach(subject => {
          if (!allSubjects.find(s => s.name === subject)) {
            allSubjects.push({ name: subject, year });
          }
        });
      }
    });
    
    // Create labs in database if they don't exist
    for (const subject of allSubjects) {
      try {
        await api.createLab({
          name: subject.name,
          year: subject.year
        }, token);
        console.log(`Created lab: ${subject.name} for ${subject.year}`);
      } catch (error) {
        // Lab might already exist, ignore error
        if (!error.error?.includes('already exists')) {
          console.warn(`Failed to create lab ${subject.name}:`, error);
        }
      }
    }
    
    // Reload labs after sync
    await loadAllLabs();
    
  } catch (error) {
    console.error('Error syncing lab subjects:', error);
  }
};
// REPLACE with this enhanced version that includes all lab subjects
const labNames = React.useMemo(() => {
  // Get labs from database
  const dbLabs = allLabs?.map(l => (typeof l === "string" ? l : l.name)).filter(Boolean) || [];
  
  // Get all lab subjects from Lab Subject Management for all years
  const subjectLabs = [];
  Object.keys(labSubjects).forEach(year => {
    if (labSubjects[year] && Array.isArray(labSubjects[year])) {
      labSubjects[year].forEach(subject => {
        if (!subjectLabs.includes(subject)) {
          subjectLabs.push(subject);
        }
      });
    }
  });
  
  // Combine and remove duplicates
  const allLabNames = [...new Set([...dbLabs, ...subjectLabs])];
  console.log("Available lab names:", allLabNames);
  
  return allLabNames;
}, [allLabs, labSubjects]);

  // Helper Functions
  const toggleDropdown = (key) => {
    setOpenDropdowns(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  const getAttendanceColor = (percentage) => {
    if (percentage >= 85) return 'row-good';
    if (percentage >= 75) return 'row-mid';
    return 'row-low';
  };

  const exportCSV = (data, filename) => {
    if (!data || data.length === 0) {
      alert('No data to export');
      return;
    }
    
    const csvContent = "data:text/csv;charset=utf-8," 
      + Object.keys(data[0]).join(",") + "\n"
      + data.map(row => Object.values(row).join(",")).join("\n");
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Lab Subject Management Functions
  const showNotification = (type, message) => {
  console.log(`📢 Notification [${type}]:`, message);
  
  setNotification({ type, message });
  
  // Add to notifications list for history
  const newNotification = {
    id: Date.now(),
    type,
    message,
    timestamp: new Date().toISOString()
  };
  
  setNotifications(prev => [newNotification, ...prev.slice(0, 9)]); // Keep last 10 notifications
  
  // Auto-clear success and info notifications after 5 seconds
  if (type === 'success' || type === 'info') {
    setTimeout(() => {
      setNotification(prev => {
        if (prev.message === message) {
          return { type: '', message: '' };
        }
        return prev;
      });
    }, 5000);
  }
  
  // Auto-clear warning notifications after 8 seconds
  if (type === 'warning') {
    setTimeout(() => {
      setNotification(prev => {
        if (prev.message === message) {
          return { type: '', message: '' };
        }
        return prev;
      });
    }, 8000);
  }
};

const validateAssignments = async () => {
    try {
      console.log('🔍 Validating lab assignments...');
      
      const report = await api.get('/labs/report', getToken());
      
      console.log('📊 Assignment validation report:');
      console.log(`   Total labs: ${report.total_labs}`);
      console.log(`   Total assignments: ${report.total_assignments}`);
      
      Object.keys(report.year_summary).forEach(year => {
        const yearData = report.year_summary[year];
        console.log(`   ${year}: ${yearData.totalUniqueStudents} unique students assigned across ${yearData.totalLabs} labs`);
      });
      
      return report;
      
    } catch (error) {
      console.error('❌ Validation failed:', error);
      return null;
    }
  };
  const updateStudentLabAssignments = async (year, subjects) => {
  try {
    console.log(`🎯 Frontend: Calling bulk assignment API for ${year} with subjects:`, subjects);
    setLoading(true);
    setError(null);
    
    // **FIXED**: Use the bulkAssignStudentsByYear function instead of generic api.post
    const result = await api.bulkAssignStudentsByYear(year, subjects, getToken());
    
    console.log('✅ Bulk assignment API result:', result);
    
    // Show detailed success notification
    const { summary } = result;
    showNotification('success', 
      `Successfully assigned ${summary.labsProcessed} labs to ${summary.studentsAffected} ${year} students. ` +
      `Created ${summary.newAssignments} new assignments.`
    );
    
    // Update local state to reflect changes
    const updatedUsers = users.map(user => {
      if (user.role === 'STUDENT' && user.year === year) {
        return {
          ...user,
          labs: subjects
        };
      }
      return user;
    });
    setUsers(updatedUsers);
    
    // Reload labs to get updated counts
    await loadAllLabs();
    
    return result;
    
  } catch (error) {
    console.error('❌ Lab assignment API error:', error);
    const errorMessage = error.error || error.message || 'Failed to assign labs to students';
    showNotification('error', errorMessage);
    throw error;
  } finally {
    setLoading(false);
  }
};
  
const handleAddSubject = async () => {
  if (!newSubject.trim()) {
    showNotification('error', 'Subject name cannot be empty');
    return;
  }

  const trimmedSubject = newSubject.trim();

  // Check for duplicate (case-insensitive)
  const existingSubjects = labSubjects[selectedYear] || [];
  if (existingSubjects.some(subject => 
    subject.toLowerCase() === trimmedSubject.toLowerCase()
  )) {
    showNotification('error', 'Subject already exists for this year');
    return;
  }

  try {
    console.log(`➕ Adding new lab subject: ${trimmedSubject} for ${selectedYear}`);
    setLoading(true);
    
    // 🔧 FIXED: Actually create the lab in the database with proper error handling
    const createdLab = await api.addLabSubject(trimmedSubject, selectedYear, getToken());
    
    console.log('✅ Lab created in database:', createdLab);
    
    // Update local state immediately for better UX
    const updatedSubjects = {
      ...labSubjects,
      [selectedYear]: [...(labSubjects[selectedYear] || []), trimmedSubject]
    };
    
    setLabSubjects(updatedSubjects);
    setNewSubject('');
    setShowAddForm(false);
    
    // Reload labs to get updated data from server
    await loadAllLabs();
    
    showNotification('success', 
      `"${trimmedSubject}" added to ${selectedYear} successfully! ` +
      `Lab created in database. Click "Apply to All Students" to assign it to ${getStudentCount(selectedYear)} students.`
    );
    
  } catch (error) {
    console.error('❌ Add subject error:', error);
    
    // Enhanced error handling
    let errorMessage = 'Failed to add subject to database';
    
    if (error.error) {
      errorMessage = error.error;
    } else if (error.details) {
      errorMessage = error.details;
    } else if (error.message) {
      errorMessage = error.message;
    }
    
    // Check for specific error types
    if (errorMessage.includes('already exists') || errorMessage.includes('409')) {
      errorMessage = `Subject "${trimmedSubject}" already exists for ${selectedYear}`;
    } else if (errorMessage.includes('connection') || errorMessage.includes('fetch')) {
      errorMessage = 'Cannot connect to server. Please check if the backend is running.';
    } else if (errorMessage.includes('Invalid year')) {
      errorMessage = 'Invalid year format. Please try again.';
    }
    
    showNotification('error', errorMessage);
  } finally {
    setLoading(false);
  }
};

const handleRemoveSubject = async (subjectToRemove) => {
  const studentCount = getStudentCount(selectedYear);
  
  const message = `Remove "${subjectToRemove}" from ${selectedYear}?\n\n` +
    `This will:\n` +
    `• Remove the lab from the database\n` +
    `• Delete all student assignments for this lab\n` +
    `• Delete all staff assignments for this lab\n` +
    `• Delete all attendance records for this lab\n` +
    `• Affect ${studentCount} students in ${selectedYear}\n\n` +
    `This action cannot be undone. Are you sure?`;

  if (window.confirm(message)) {
    try {
      console.log(`🗑️ Removing lab subject: ${subjectToRemove} for ${selectedYear}`);
      setLoading(true);
      
      // 🔧 FIXED: Actually delete the lab from the database with proper error handling
      const result = await api.removeLabSubject(subjectToRemove, selectedYear, getToken());
      
      console.log('✅ Lab deleted from database:', result);
      
      // Update local state immediately for better UX
      const updatedSubjects = {
        ...labSubjects,
        [selectedYear]: labSubjects[selectedYear].filter(subject => subject !== subjectToRemove)
      };
      
      setLabSubjects(updatedSubjects);
      
      // Reload labs to get updated data from server
      await loadAllLabs();
      
      showNotification('success', 
        `"${subjectToRemove}" has been completely removed from ${selectedYear}. ` +
        `All related assignments and data have been deleted from the database.`
      );
      
    } catch (error) {
      console.error('❌ Remove subject error:', error);
      
      // Enhanced error handling
      let errorMessage = 'Failed to remove subject from database';
      
      if (error.error) {
        errorMessage = error.error;
      } else if (error.details) {
        errorMessage = error.details;
      } else if (error.message) {
        errorMessage = error.message;
      }
      
      // Check for specific error types
      if (errorMessage.includes('not found') || errorMessage.includes('404')) {
        errorMessage = `Subject "${subjectToRemove}" not found in database`;
      } else if (errorMessage.includes('connection') || errorMessage.includes('fetch')) {
        errorMessage = 'Cannot connect to server. Please check if the backend is running.';
      }
      
      showNotification('error', errorMessage);
    } finally {
      setLoading(false);
    }
  }
};


const handleEditSubject = (index, subject) => {
    setEditingSubject(index);
    setEditingValue(subject);
  };

  const handleSaveEdit = async (index) => {
    if (!editingValue.trim()) {
      showNotification('error', 'Subject name cannot be empty');
      return;
    }

    if (editingValue.trim() === labSubjects[selectedYear][index]) {
      // No changes made
      setEditingSubject(null);
      setEditingValue('');
      return;
    }

    if (labSubjects[selectedYear].includes(editingValue.trim()) && editingValue.trim() !== labSubjects[selectedYear][index]) {
      showNotification('error', 'Subject with this name already exists');
      return;
    }

    try {
      const oldName = labSubjects[selectedYear][index];
      
      // For editing, we need to create new lab and delete old one
      console.log(`✏️ Editing lab subject: ${oldName} -> ${editingValue.trim()}`);
      
      // Create new lab
      await api.addLabSubject(editingValue.trim(), selectedYear, getToken());
      
      // Delete old lab
      await api.removeLabSubject(oldName, selectedYear, getToken());
      
      // Update local state
      const updatedSubjects = {
        ...labSubjects,
        [selectedYear]: labSubjects[selectedYear].map((subject, i) => 
          i === index ? editingValue.trim() : subject
        )
      };
      
      setLabSubjects(updatedSubjects);
      setEditingSubject(null);
      setEditingValue('');
      
      // Reload labs to get updated data
      await loadAllLabs();
      
      showNotification('success', `Lab subject renamed successfully in database`);
      
    } catch (error) {
      console.error('❌ Edit subject error:', error);
      showNotification('error', error.error || 'Failed to update subject in database');
    }
  };

const handleCancelEdit = () => {
    setEditingSubject(null);
    setEditingValue('');
  };

  const handleCancelAdd = () => {
  setNewSubject('');
  setShowAddForm(false);
  // Clear any existing error notifications
  if (notification.type === 'error') {
    setNotification({ type: '', message: '' });
  }
};

const getStudentCount = (year) => {
    if (!users || !Array.isArray(users)) return 0;
    
    return users.filter(user => {
      if (!user || user.role !== 'STUDENT') return false;
      
      const userYear = user.year;
      if (!userYear) return false;
      
      // Direct match first
      if (userYear === year) return true;
      
      // Flexible matching for different year formats
      const yearNum = year.charAt(0); // Get first character (2, 3, or 4)
      
      if (year === '2nd Year') {
        return userYear === '2' || userYear === 2 || userYear === '2nd' || 
               userYear === 'second' || userYear === '2nd Year';
      }
      if (year === '3rd Year') {
        return userYear === '3' || userYear === 3 || userYear === '3rd' || 
               userYear === 'third' || userYear === '3rd Year';
      }
      if (year === '4th Year') {
        return userYear === '4' || userYear === 4 || userYear === '4th' || 
               userYear === 'fourth' || userYear === '4th Year';
      }
      
      return false;
    }).length;
  };


const getAssignmentStatus = async (year) => {
  try {
    const labs = allLabs.filter(lab => lab.year === year);
    const assignedLabs = labs.filter(lab => lab.student_count > 0);
    const totalStudents = getStudentCount(year);
    
    // Calculate unique assigned students
    const assignedStudentIds = new Set();
    labs.forEach(lab => {
      lab.students?.forEach(student => {
        assignedStudentIds.add(student.id);
      });
    });
    
    return {
      year,
      totalStudents,
      assignedStudents: assignedStudentIds.size,
      totalLabs: labs.length,
      assignedLabs: assignedLabs.length,
      assignmentRate: totalStudents > 0 ? Math.round((assignedStudentIds.size / totalStudents) * 100) : 0,
      hasAssignments: assignedLabs.length > 0
    };
  } catch (error) {
    console.error('❌ Error getting assignment status:', error);
    return {
      year,
      totalStudents: 0,
      assignedStudents: 0,
      totalLabs: 0,
      assignedLabs: 0,
      assignmentRate: 0,
      hasAssignments: false
    };
  }
};


const applySubjectsToStudents = async () => {
  const currentYearSubjects = labSubjects[selectedYear] || [];
  const studentCount = getStudentCount(selectedYear);
  
  if (currentYearSubjects.length === 0) {
    showNotification('error', `No subjects available for ${selectedYear}. Please add subjects first.`);
    return;
  }
  
  if (studentCount === 0) {
    showNotification('warning', `No students found in ${selectedYear}. Assignment will create lab records but no student assignments will be made.`);
  }
  
  const message = `Apply ${currentYearSubjects.length} lab subjects to all ${selectedYear} students?\n\n` +
    `This will:\n` +
    `• Assign ${currentYearSubjects.length} subjects to ${studentCount} students\n` +
    `• Create ${currentYearSubjects.length * studentCount} lab assignments in total\n` +
    `• Make subjects available for attendance marking\n\n` +
    `Subjects to assign:\n${currentYearSubjects.map(s => `• ${s}`).join('\n')}\n\n` +
    `Continue?`;

  if (window.confirm(message)) {
    try {
      console.log(`🎯 Applying ${currentYearSubjects.length} subjects to all ${selectedYear} students`);
      setLoading(true);
      
      // Show initial progress
      showNotification('info', 
        `Starting bulk assignment of ${currentYearSubjects.length} subjects to ${studentCount} students in ${selectedYear}...`
      );
      
      // 🔧 FIXED: Use the bulk assignment API with proper error handling
      const result = await api.bulkAssignStudentsByYear(selectedYear, currentYearSubjects, getToken());
      
      console.log('✅ Bulk assignment completed:', result);
      
      // Update UI with results
      await loadAllLabs();
      await loadAllUsers(); // Refresh student data
      
      // Show detailed success message
      const summary = result.assignment_summary;
      showNotification('success', 
        `Assignment completed successfully!\n\n` +
        `📊 Summary:\n` +
        `• Year: ${summary.year}\n` +
        `• Students: ${summary.students_count}\n` +
        `• Lab Subjects: ${summary.labs_count}\n` +
        `• New Assignments: ${summary.new_assignments}\n` +
        `• Total Assignments: ${summary.total_assignments}\n\n` +
        `All ${selectedYear} students now have access to the assigned lab subjects for attendance marking.`
      );
      
    } catch (error) {
      console.error('❌ Apply subjects error:', error);
      
      // Enhanced error handling
      let errorMessage = 'Failed to apply subjects to students';
      
      if (error.error) {
        errorMessage = error.error;
      } else if (error.details) {
        errorMessage = error.details;
      } else if (error.message) {
        errorMessage = error.message;
      }
      
      // Check for specific error types
      if (errorMessage.includes('not found') && errorMessage.includes('labs')) {
        errorMessage = `Some lab subjects were not found in database. Please refresh and try again.`;
      } else if (errorMessage.includes('not found') && errorMessage.includes('students')) {
        errorMessage = `No students found for ${selectedYear}. Please check if students are properly enrolled.`;
      } else if (errorMessage.includes('connection') || errorMessage.includes('fetch')) {
        errorMessage = 'Cannot connect to server. Please check if the backend is running.';
      } else if (errorMessage.includes('Invalid year')) {
        errorMessage = `Invalid year format: ${selectedYear}. Please try again.`;
      }
      
      showNotification('error', errorMessage);
    } finally {
      setLoading(false);
    }
  }
};


  // Load lab subjects from database
  const loadLabSubjectsFromDatabase = async () => {
    try {
      console.log('🔄 Loading lab subjects from database...');
      const labs = await api.listLabs(getToken());
      
      // Group labs by year
      const subjectsByYear = {
        '2nd Year': [],
        '3rd Year': [],
        '4th Year': []
      };
      
      if (labs && Array.isArray(labs)) {
        labs.forEach(lab => {
          const year = lab.year;
          if (subjectsByYear[year] && !subjectsByYear[year].includes(lab.name)) {
            subjectsByYear[year].push(lab.name);
          }
        });
      }
      
      setLabSubjects(subjectsByYear);
      console.log('✅ Lab subjects loaded from database:', subjectsByYear);
      
    } catch (error) {
      console.error('❌ Failed to load lab subjects:', error);
      // Don't show error notification on initial load failure
      // Keep the default empty subjects as fallback
    }
  };

  

  const filteredStudents = users.filter(u => {
  // Handle case sensitivity for role
  const userRole = (u.role || '').toLowerCase();
  if (userRole !== 'student') return false;
  
  // Year filter
  if (yearFilter !== 'All' && u.year !== yearFilter) return false;
  
  // 🔥 FIX: Lab filter - Check assignedLabs array instead of attendance
  if (labFilter !== 'All Labs') {
    // Check if student has this lab assigned
    const hasLab = u.assignedLabs && u.assignedLabs.includes(labFilter);
    if (!hasLab) return false;
  }
  
  // Student ID search
  if (studentIdSearch && !String(u.studentId || '').toLowerCase().includes(studentIdSearch.toLowerCase())) return false;
  
  return true;
});

  const filteredStaff = users.filter(u => (u.role || '').toLowerCase() === 'staff');

  const studentsByYear = yearOrder.reduce((acc, year) => {
    acc[year] = filteredStudents.filter(s => {
      const studentYear = s.year;
      
      // Direct match first
      if (studentYear === year) return true;
      
      // Flexible matching for different year formats
      if (year === '2nd Year' && (studentYear === '2' || studentYear === 2 || studentYear === '2nd' || studentYear === 'second')) return true;
      if (year === '3rd Year' && (studentYear === '3' || studentYear === 3 || studentYear === '3rd' || studentYear === 'third')) return true;
      if (year === '4th Year' && (studentYear === '4' || studentYear === 4 || studentYear === '4th' || studentYear === 'fourth')) return true;
      
      return false;
    });
    return acc;
  }, {});

  // Group staff by department
  const staffByDept = staff.reduce((acc, s) => {
    const deptKey = s.department || "Unassigned Dept";
    if (!acc[deptKey]) acc[deptKey] = [];
    acc[deptKey].push(s);
    return acc;
  }, {});

  // Calculate statistics
  const totalStudents = filteredStudents.length;
  const totalStaff = filteredStaff.length;
  const avgAttendance = attendance.length > 0 
    ? Math.round(attendance.reduce((sum, a) => sum + a.percentage, 0) / attendance.length)
    : 0;

  // Pie chart data
  const pieData = yearOrder.map(year => {
    const yearStudents = studentsByYear[year] || [];
    const yearAttendance = yearStudents.length > 0
      ? yearStudents.reduce((sum, student) => {
          const studentAttendance = attendance.filter(a => a.studentId === student.studentId);
          const avgAtt = studentAttendance.length > 0
            ? studentAttendance.reduce((s, a) => s + a.percentage, 0) / studentAttendance.length
            : 0;
          return sum + avgAtt;
        }, 0) / yearStudents.length
      : 0;
    
    return {
      name: year,
      value: Math.round(yearAttendance) || 0,
      students: yearStudents.length
    };
  }).filter(item => item.students > 0);

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

  // Backend functions
  async function createUser(e, role) {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const payload = Object.fromEntries(form.entries());
    const base = {
      name: payload.name,
      email: payload.email,
      username: payload.username,
      password: payload.password,
      role: role.toUpperCase()
    };
    if (role.toUpperCase() === 'STUDENT') {
      base.year = normalizeYear(payload.year);
      base.studentId = payload.studentId;
      base.labs = (payload.labs || '').split(',').map(s => s.trim()).filter(Boolean);
    }
    if (role.toUpperCase() === 'STAFF') {
      base.assignedLabs = (payload.assignedLabs || '').split(',').map(s => s.trim()).filter(Boolean);
      base.department = currentUser?.department || base.department;
    }
    
    try {
      const out = await api.createUser(base, getToken());
      await loadAllUsers();
      e.currentTarget.reset();
      alert('User created');
    } catch (err) {
      alert(err?.error || err?.message || 'Failed to create user');
    }
  }

  const createUserBackend = async (userData) => {
    try {
      const res = await api.createUser(userData, getToken());
      await loadAllUsers();
      return res;
    } catch (err) {
      console.error('createUserBackend error', err);
      throw err;
    }
  };

  async function removeUser(id) {
    if (!window.confirm('Delete this user?')) return;
    try {
      await api.deleteUser(id, getToken());
      await loadAllUsers();
    } catch (e) {
      alert(e?.error || 'Failed to delete');
      throw e;
    }
  }

  async function setPassword(id) {
    const pwd = prompt('New password for user? (min 6 chars)');
    if (!pwd) return;
    try {
      await api.setUserPassword(id, pwd, getToken());
      alert('Password updated');
    } catch (e) { alert(e?.error || 'Failed to set password'); }
  }

  const handleGenerateTempPassword = async (userId) => {
    const password = 'temp' + Math.random().toString(36).substr(2, 6);
    try {
      await api.setUserPassword(userId, password, getToken());
      setTempPassword(password);
      showNotification('success', 'Temporary password set for user');
    } catch (err) {
      showNotification('error', err?.error || 'Failed to set temporary password');
    }
  };
  
  async function assignStudentLabs(user) {
    const val = prompt('Comma-separated labs for student', (user.labs || []).join(', '));
    if (val == null) return;
    const labs = val.split(',').map(s => s.trim()).filter(Boolean);
    try {
      await api.assignStudentLabs(user.id || user.studentId, labs, getToken());
      setUsers(prev => prev.map(u => (u.id === user.id ? { ...u, labs } : u)));
    } catch(e) { alert(e?.error || 'Failed to assign labs'); }
  }

  async function saveSubjects(year) {
    const list = (yearSubjects[year] || []).map(s => s.trim()).filter(Boolean);
    try {
      await api.setYearSubjects(year, list, getToken());
      alert('Saved');
    } catch (e) { alert(e?.error || 'Failed to save'); }
  }

  const handleViewAttendance = (student) => {
    setSelectedStudent(student);
  };

  const handleAddUser = (password) => {
    setTempPassword(password);
  };

  const handleChangePassword = (newPassword) => {
    if (!currentUser || !newPassword) return;
    setUsers(users.map(u => u.id === currentUser.id ? { ...u, password: newPassword, temporaryPassword: false } : u));
    setShowChangePassword(false);
    alert('Password updated successfully.');
  };

  const handleAssignLabs = (staff) => {
    setShowLabAssignModal(staff);
    setSelectedStaffLabs(staff.assignedLabs || []);
  };

  const handleLabToggle = (labName) => {
    setSelectedStaffLabs(prev => {
      if (prev.includes(labName)) {
        return prev.filter(lab => lab !== labName);
      } else {
        return [...prev, labName];
      }
    });
  };

 // REPLACE the existing handleSaveLabAssignment function
const handleSaveLabAssignment = async () => {
  if (!showLabAssignModal) return;
  
  setLoading(true);
  try {
    const token = getToken();
    
    // Get lab IDs from selected lab names
    const labIds = allLabs
      .filter(lab => selectedStaffLabs.includes(lab.name))
      .map(lab => lab.id);
    
    console.log(`ðŸ”§ Assigning staff ${showLabAssignModal.id} to labs:`, {
      staffId: showLabAssignModal.id,
      labIds: labIds,
      labNames: selectedStaffLabs
    });
    
    // Call API to assign labs
    await api.assignStaffToLabs(showLabAssignModal.id, labIds, token);
    
    // CRITICAL FIX: Reload both users and labs data
    await Promise.all([
      loadAllUsers(),
      loadAllLabs()
    ]);
    
    showNotification('success', `Lab assignments updated successfully for ${showLabAssignModal.name}`);
    
    // Close modal and reset state
    setShowLabAssignModal(null);
    setSelectedStaffLabs([]);
    
  } catch (error) {
    console.error('âŒ Lab assignment error:', error);
    showNotification('error', error.error || 'Failed to assign labs');
  } finally {
    setLoading(false);
  }
};

  // Modal Components
  const AddUserModal = ({ type, onClose, onAdd }) => {
    const [formData, setFormData] = useState({
      name: '', email: '', year: '2nd Year', studentId: '', assignedLabs: []
    });
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleSubmit = async () => {
      if (!formData.name || !formData.email) {
        alert('Please fill in all required fields');
        return;
      }

      setIsSubmitting(true);

      const userData = {
        ...formData,
        username: formData.username || (formData.email ? formData.email.split('@')[0] : `user${Date.now()}`),
        password: formData.password || ('temp' + Math.random().toString(36).substr(2,6)),
        role: type === 'student' ? 'STUDENT' : 'STAFF',
        studentId: type === 'student' ? (formData.studentId || `STU${Date.now()}`) : undefined,
        year: type === 'student' ? normalizeYear(formData.year) : undefined,
        labs: type === 'student' ? formData.labs || [] : undefined,
        assignedLabs: type === 'staff' ? formData.assignedLabs || [] : undefined,
        department: type === 'staff' ? (currentUser?.department || formData.department) : undefined
      };

      try {
        await createUserBackend(userData);
        setFormData({ name: '', email: '', year: '2nd Year', studentId: '', assignedLabs: [] });
        await new Promise(resolve => setTimeout(resolve, 500));
        await loadAllUsers(); 
        onAdd(userData.password);
        onClose();
        showNotification('success', `${userData.name} added successfully`);
      } catch (err) {
        const msg = err?.error || err?.message || 'Create user failed';
        alert(msg);
      } finally {
        setIsSubmitting(false);
      }
    };

    return (
      <div className="modal-overlay">
        <div className="modal">
          <h2 className="modal-header">Add New {type === 'student' ? 'Student' : 'Staff'}</h2>
          <div className="form-box">
            <div className="form-group">
              <label className="form-label">Full Name</label>
              <input
                type="text"
                className="form-input"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                placeholder="Enter full name"
              />
            </div>
            
            <div className="form-group">
              <label className="form-label">Email</label>
              <input
                type="email"
                className="form-input"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                placeholder="Enter email address"
              />
            </div>
            
            {type === 'student' && (
              <>
                <div className="form-group">
                  <label className="form-label">Student ID (Optional)</label>
                  <input
                    type="text"
                    className="form-input"
                    value={formData.studentId}
                    onChange={(e) => setFormData({...formData, studentId: e.target.value})}
                    placeholder="Auto-generated if empty"
                  />
                </div>
                
                <div className="form-group">
                  <label className="form-label">Year</label>
                  <select
                    className="form-input"
                    value={formData.year}
                    onChange={(e) => setFormData({...formData, year: e.target.value})}
                    required
                  >
                    {yearOrder.map(year => (
                      <option key={year} value={year}>{year}</option>
                    ))}
                  </select>
                </div>
              </>
            )}
            
            {type === 'staff' && (
              <div className="form-group">
                <label className="form-label">Assigned Labs (Optional)</label>
                <select
                  multiple
                  className="form-input"
                  style={{ height: '120px' }}
                  value={formData.assignedLabs}
                  onChange={(e) => {
                    const selected = Array.from(e.target.selectedOptions, option => option.value);
                    setFormData({...formData, assignedLabs: selected});
                  }}
                >
                  {labNames.map(lab => (
                    <option key={lab} value={lab}>{lab}</option>
                  ))}
                </select>
                <small style={{ fontSize: '12px', color: '#666' }}>
                  Hold Ctrl/Cmd to select multiple labs. You can assign labs later.
                </small>
              </div>
            )}
            
            <div className="modal-actions">
              <button className="btn btn-secondary" onClick={onClose} disabled={isSubmitting}>
                Cancel
              </button>
              <button onClick={handleSubmit} className="btn btn-primary" disabled={isSubmitting}>
                {isSubmitting ? 'Creating...' : `Add ${type === 'student' ? 'Student' : 'Staff'}`}
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const TempPasswordModal = ({ password, onClose }) => (
    <div className="modal-overlay">
      <div className="modal">
        <div className="temp-password-display">
          <h2 className="modal-header">Temporary Password Generated</h2>
          <p>The user has been created successfully. Please share this temporary password:</p>
          
          <div className="temp-password-box">
            <div className="temp-password-value">{password}</div>
          </div>
          
          <div className="temp-password-note">
            <strong>Important:</strong> The user must login with this password and will be prompted to set a new password on their first login.
          </div>
          
          <div className="modal-actions">
            <button className="btn btn-primary" onClick={onClose}>
              Got it!
            </button>
          </div>
        </div>
      </div>
    </div>
  );
// ADD this NEW component before LabAssignmentModal
const AddLabModal = ({ onClose, onLabAdded }) => {
  const [labName, setLabName] = useState('');
  const [labYear, setLabYear] = useState('2nd Year');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleCreateLab = async (e) => {
    e.preventDefault();
    if (!labName.trim()) return;

    setIsSubmitting(true);
    try {
      const token = getToken();
      const newLab = await api.createLab({
        name: labName.trim(),
        year: labYear
      }, token);

      // Refresh labs data
      await loadAllLabs();
      
      showNotification('success', `Lab "${labName}" created successfully!`);
      onLabAdded(newLab);
      onClose();
    } catch (error) {
      console.error('Create lab error:', error);
      showNotification('error', error.error || 'Failed to create lab');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="modal-overlay">
      <div className="modal" style={{ maxWidth: '400px' }}>
        <div className="modal-content">
          <h2 className="modal-header">
            <FaPlus style={{ marginRight: '10px' }} />
            Add New Lab Subject
          </h2>
          
          <form onSubmit={handleCreateLab}>
            <div style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold' }}>
                Lab Name
              </label>
              <input
                type="text"
                value={labName}
                onChange={(e) => setLabName(e.target.value)}
                placeholder="Enter lab name (e.g., Chemistry Lab)"
                style={{
                  width: '100%',
                  padding: '10px',
                  border: '1px solid #ddd',
                  borderRadius: '4px',
                  fontSize: '14px'
                }}
                required
              />
            </div>

            <div style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold' }}>
                Year
              </label>
              <select
                value={labYear}
                onChange={(e) => setLabYear(e.target.value)}
                style={{
                  width: '100%',
                  padding: '10px',
                  border: '1px solid #ddd',
                  borderRadius: '4px',
                  fontSize: '14px'
                }}
              >
                <option value="2nd Year">2nd Year</option>
                <option value="3rd Year">3rd Year</option>
                <option value="4th Year">4th Year</option>
              </select>
            </div>

            <div className="modal-actions">
              <button
                type="button"
                className="btn btn-secondary"
                onClick={onClose}
                disabled={isSubmitting}
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn btn-primary"
                disabled={isSubmitting || !labName.trim()}
              >
                {isSubmitting ? 'Creating...' : 'Create Lab'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};


// REPLACE the existing LabAssignmentModal component
const LabAssignmentModal = ({ staff, onClose }) => (
  <div className="modal-overlay">
    <div className="modal" style={{ maxWidth: '500px' }}>
      <div className="lab-assignment-modal">
        <h2 className="modal-header">Assign Labs to {staff.name}</h2>
        <p style={{ color: '#666', marginBottom: '20px' }}>
          Select the lab subjects that {staff.name} will be responsible for managing.
        </p>
        
        {/* ENHANCED: Scrollable Lab Selection */}
        <div style={{
          maxHeight: '300px',
          overflowY: 'auto',
          border: '1px solid #ddd',
          borderRadius: '6px',
          padding: '10px',
          marginBottom: '20px'
        }}>
          <div className="lab-selection-grid">
            {labNames.length > 0 ? labNames.map(lab => (
              <div key={lab} className="lab-selection-item" style={{ marginBottom: '8px' }}>
                <label className="lab-checkbox" style={{
                  display: 'flex',
                  alignItems: 'center',
                  cursor: 'pointer',
                  padding: '8px',
                  border: '1px solid #e5e7eb',
                  borderRadius: '4px',
                  transition: 'background 0.15s ease'
                }}>
                  <input
                    type="checkbox"
                    checked={selectedStaffLabs.includes(lab)}
                    onChange={() => handleLabToggle(lab)}
                    style={{ marginRight: '10px' }}
                  />
                  <span className="checkmark">
                    {selectedStaffLabs.includes(lab) ? <FaCheck style={{ color: '#16a34a' }} /> : ''}
                  </span>
                  <span className="lab-name" style={{ marginLeft: '8px' }}>{lab}</span>
                </label>
              </div>
            )) : (
              <div style={{ padding: '20px', textAlign: 'center', color: '#666' }}>
                <FaBook size={32} style={{ opacity: 0.3, marginBottom: '10px' }} />
                <p>No labs available. Create a new lab to get started.</p>
                <button 
                  className="btn btn-primary"
                  onClick={() => setShowAddLabModal(true)}
                  style={{ marginTop: '10px' }}
                >
                  <FaPlus /> Create New Lab
                </button>
              </div>
            )}
          </div>
        </div>
        
        <div className="assignment-summary" style={{
          background: '#f8f9fa',
          padding: '15px',
          borderRadius: '4px',
          marginBottom: '20px'
        }}>
          <h4>Assignment Summary:</h4>
          <p>
            <strong>{selectedStaffLabs.length}</strong> lab{selectedStaffLabs.length !== 1 ? 's' : ''} selected
            {selectedStaffLabs.length > 0 && (
              <span style={{ color: '#16a34a', marginLeft: '10px' }}>
                âœ“ {selectedStaffLabs.join(', ')}
              </span>
            )}
          </p>
          <div style={{ fontSize: '12px', color: '#666', marginTop: '8px' }}>
            The lab count will be updated immediately after assignment.
          </div>
        </div>
        
        <div className="modal-actions">
          <button className="btn btn-secondary" onClick={onClose} disabled={loading}>
            Cancel
          </button>
          <button 
            className="btn btn-primary" 
            onClick={handleSaveLabAssignment}
            disabled={loading || selectedStaffLabs.length === 0}
          >
            {loading ? 'Saving...' : `Save Assignment (${selectedStaffLabs.length} labs)`}
          </button>
        </div>
      </div>
    </div>
  </div>
);

{/* ADD this modal after the existing modals */}
{showAddLabModal && (
  <AddLabModal
    onClose={() => setShowAddLabModal(false)}
    onLabAdded={(labName) => {
      console.log('Lab added:', labName);
    }}
  />
)}

  return (
    <div style={dashboardContainerStyles}>
      {/* Header */}
      <div style={dashboardHeaderStyles}>
        <div style={dashboardNavStyles}>
          <h1 style={dashboardTitleStyles}>HOD Dashboard</h1>
          <div style={profileAreaStyles}>
            <button style={profileButtonStyles} onClick={() => setShowProfileMenu(v => !v)} aria-label="Profile menu">
              <FaUser />
            </button>
            {showProfileMenu && (
              <div style={profileDropdownStyles}>
                <div style={profileInfoRowStyles}><strong>{currentUser?.name}</strong></div>
                <div style={profileInfoRowStyles}>{currentUser?.email}</div>
                <div style={profileDividerStyles} />
                <button style={profileItemStyles} onClick={() => { setShowChangePassword(true); setShowProfileMenu(false); }}>Change Password</button>
                <button style={profileItemStyles} onClick={() => setShowProfileMenu(false)}>View Profile</button>
                <button style={{...profileItemStyles, color: '#dc3545'}} onClick={handleLogout}><FaSignOutAlt /> Logout</button>
              </div>
            )}
          </div>
        </div>
      </div>

      <div style={dashboardContentStyles}>
        {/* Sidebar */}
        <aside style={sidebarStyles}>
          <button style={{
            ...sidebarItemStyles,
            ...(activeSection === 'overview' ? sidebarItemActiveStyles : {})
          }} onClick={() => setActiveSection('overview')}>
            <FaChartPie /> Overview
          </button>
          <button style={{
            ...sidebarItemStyles,
            ...(activeSection === 'students' ? sidebarItemActiveStyles : {})
          }} onClick={() => setActiveSection('students')}>
            <FaUsers /> Students
          </button>
          <button style={{
            ...sidebarItemStyles,
            ...(activeSection === 'staff' ? sidebarItemActiveStyles : {})
          }} onClick={() => setActiveSection('staff')}>
            <FaUsers /> Staff
          </button>
          <button style={{
            ...sidebarItemStyles,
            ...(activeSection === 'subjects' ? sidebarItemActiveStyles : {})
          }} onClick={() => setActiveSection('subjects')}>
            <FaBook /> Lab Subjects
          </button>
          <button style={{
            ...sidebarItemStyles,
            ...(activeSection === 'analytics' ? sidebarItemActiveStyles : {})
          }} onClick={() => setActiveSection('analytics')}>
            <FaChartPie /> Analytics
          </button>
        </aside>

        <main style={dashboardMainStyles}>
          {/* Notification Display */}
      {notification.message && (
        <div style={{
          position: 'fixed',
          top: '20px',
          right: '20px',
          padding: '15px 20px',
          backgroundColor: notification.type === 'error' ? '#f8d7da' : 
                          notification.type === 'success' ? '#d1edcb' : '#bee5eb',
          color: notification.type === 'error' ? '#721c24' : 
                 notification.type === 'success' ? '#155724' : '#0c5460',
          border: `1px solid ${notification.type === 'error' ? '#f5c6cb' : 
                               notification.type === 'success' ? '#c3e6cb' : '#b8daff'}`,
          borderRadius: '8px',
          boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
          zIndex: 1000,
          maxWidth: '400px'
        }}>
          <strong style={{ display: 'block', marginBottom: '5px' }}>
            {notification.type === 'error' ? '❌ Error' : 
             notification.type === 'success' ? '✅ Success' : 'ℹ️ Info'}
          </strong>
          {notification.message}
        </div>
      )}
          {/* Controls Bar */}
          {activeSection !== 'staff' && activeSection !== 'subjects' && activeSection !== 'overview' && (
          <div style={controlsBarStyles}>
            <div style={filterGroupStyles}>
              <label style={filterLabelStyles}>
                <FaFilter /> Year Filter
              </label>
              <select
                style={filterSelectStyles}
                value={yearFilter}
                onChange={(e) => setYearFilter(e.target.value)}
              >
                <option value="All">All Years</option>
                {yearOrder.map(year => (
                  <option key={year} value={year}>{year}</option>
                ))}
              </select>
            </div>
            
            <div style={filterGroupStyles}>
              <label style={filterLabelStyles}>Lab Filter</label>
              <select
                style={filterSelectStyles}
                value={labFilter}
                onChange={(e) => setLabFilter(e.target.value)}
              >
                <option value="All Labs">All Labs</option>
                {labNames.map(lab => (
                  <option key={lab} value={lab}>{lab}</option>
                ))}
              </select>
            </div>

            {activeSection === 'students' && (
              <div style={filterGroupStyles}>
                <label style={filterLabelStyles}>Search by Student ID</label>
                <input
                  type="text"
                  style={formInputStyles}
                  placeholder="e.g., STU001"
                  value={studentIdSearch}
                  onChange={(e) => setStudentIdSearch(e.target.value)}
                />
              </div>
            )}
          </div>
          )}

     

{/* Overview Section - FIXED VERSION */}
{activeSection === 'overview' && (
  <>
    {/* Summary Cards - FIXED */}
    <div style={summaryCardsStyles}>
      <div style={summaryCardStyles}>
        <div style={summaryCardIconStyles}>
          <FaUsers />
        </div>
        <div style={summaryCardContentStyles}>
          {/* FIXED: Use multiple fallbacks for student count */}
          <div style={summaryCardValueStyles}>
            {summary.studentsCount ?? 
             users.filter(u => u.role === 'student' || u.role === 'STUDENT').length ?? 
             students.length ?? 
             0}
          </div>
          <div style={summaryCardTitleStyles}>Total Students</div>
        </div>
      </div>
      <div style={summaryCardStyles}>
        <div style={{...summaryCardIconStyles, backgroundColor: '#f0f9ff', color: '#0284c7'}}>
          <FaUsers />
        </div>
        <div style={summaryCardContentStyles}>
          {/* FIXED: Use multiple fallbacks for staff count */}
          <div style={summaryCardValueStyles}>
            {summary.staffCount ?? 
             users.filter(u => u.role === 'staff' || u.role === 'STAFF').length ?? 
             staff.length ?? 
             0}
          </div>
          <div style={summaryCardTitleStyles}>Total Staff</div>
        </div>
      </div>
      <div style={summaryCardStyles}>
        <div style={{...summaryCardIconStyles, backgroundColor: '#f0fdf4', color: '#16a34a'}}>
          <FaChartPie />
        </div>
        <div style={summaryCardContentStyles}>
          <div style={summaryCardValueStyles}>{summary.avgAttendance ?? avgAttendance ?? 0}%</div>
          <div style={summaryCardTitleStyles}>Avg Attendance</div>
        </div>
      </div>
      <div style={summaryCardStyles}>
        <div style={{...summaryCardIconStyles, backgroundColor: '#fef3c7', color: '#d97706'}}>
          <FaCog />
        </div>
        <div style={summaryCardContentStyles}>
          <div style={summaryCardValueStyles}>
            {summary.totalLabAssignments ?? 
             staff.reduce((sum, s) => sum + (s.assignedLabs?.length || 0), 0) ?? 
             0}
          </div>
          <div style={summaryCardTitleStyles}>Lab Assignments</div>
        </div>
      </div>
    </div>

    {/* Students by Year - FIXED */}
    <div style={sectionStyles}>
      <div style={sectionHeaderStyles}>
        <h2 style={sectionTitleStyles}>
          <FaGraduationCap /> Students by Year
        </h2>
        {/* FIXED: Add debug info */}
        <div style={{fontSize: '12px', color: '#666'}}>
          Total: {summary.studentsCount ?? users.filter(u => u.role === 'student' || u.role === 'STUDENT').length ?? 0}
        </div>
      </div>
      <div style={studentsByYearGridStyles}>
        {yearOrder.map((year) => {
          // FIXED: Enhanced year count with debugging
          const yearCount = users.filter(user => {
            const userRole = (user.role || '').toLowerCase();
            const isStudent = userRole === 'student';
            
            let matchesYear = false;
            if (year === '2nd Year') {
              matchesYear = user.year === '2nd Year' || user.year === '2nd' || user.year === '2' || user.year === 2;
            } else if (year === '3rd Year') {
              matchesYear = user.year === '3rd Year' || user.year === '3rd' || user.year === '3' || user.year === 3;
            } else if (year === '4th Year') {
              matchesYear = user.year === '4th Year' || user.year === '4th' || user.year === '4' || user.year === 4;
            } else {
              matchesYear = user.year === year;
            }
            
            return isStudent && matchesYear;
          }).length;
          
          return (
            <div key={year} style={yearOverviewCardStyles}>
              <div style={yearCardHeaderStyles}>
                <div style={yearTitleStyles}>{year}</div>
                <div style={yearIconStyles}>
                  <FaGraduationCap />
                </div>
              </div>
              <div style={yearCardContentStyles}>
                <div style={studentCountDisplayStyles}>
                  <span style={countNumberStyles}>{yearCount}</span>
                  <span style={countLabelStyles}>students</span>
                </div>
                <div style={subjectCountDisplayStyles}>
                  <span style={subjectCountStyles}>{labSubjects[year]?.length || 0}</span>
                  <span style={subjectLabelStyles}>lab subjects</span>
                </div>
              </div>
              <div style={yearCardFooterStyles}>
                <button
                  style={viewDetailsBtnStyles}
                  onClick={() => setActiveSection('students')}
                >
                  View Details →
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>

  
              {/* Quick Actions */}
              <div style={sectionStyles}>
                <div style={sectionHeaderStyles}>
                  <h2 style={sectionTitleStyles}>
                    <FaCog /> Quick Actions
                  </h2>
                </div>
                <div style={quickActionsStyles}>
                  <button 
                    style={quickActionBtnStyles}
                    onClick={() => setActiveSection('students')}
                  >
                    <div style={quickActionIconStyles}>
                      <FaPlus />
                    </div>
                    <span style={quickActionTextStyles}>Add Student</span>
                  </button>
                  <button 
                    style={quickActionBtnStyles}
                    onClick={() => setActiveSection('staff')}
                  >
                    <div style={{...quickActionIconStyles, backgroundColor: '#f0f9ff', color: '#0284c7'}}>
                      <FaPlus />
                    </div>
                    <span style={quickActionTextStyles}>Add Staff</span>
                  </button>
                  <button 
                    style={quickActionBtnStyles}
                    onClick={() => setActiveSection('subjects')}
                  >
                    <div style={{...quickActionIconStyles, backgroundColor: '#f0fdf4', color: '#16a34a'}}>
                      <FaBook />
                    </div>
                    <span style={quickActionTextStyles}>Lab Subjects</span>
                  </button>
                  <button 
                    style={quickActionBtnStyles}
                    onClick={() => setActiveSection('analytics')}
                  >
                    <div style={{...quickActionIconStyles, backgroundColor: '#fef3c7', color: '#d97706'}}>
                      <FaChartPie />
                    </div>
                    <span style={quickActionTextStyles}>Analytics</span>
                  </button>
                </div>
              </div>
            </>
          )}

          {/* Students Section */}
          {activeSection === 'students' && (
          <>
            <div style={summaryCardsStyles}>
              <div style={summaryCardStyles}>
                <div style={summaryCardIconStyles}>
                  <FaUsers />
                </div>
                <div style={summaryCardContentStyles}>
                  <div style={summaryCardValueStyles}>{totalStudents}</div>
                  <div style={summaryCardTitleStyles}>Total Students</div>
                </div>
              </div>
              <div style={summaryCardStyles}>
                <div style={{...summaryCardIconStyles, backgroundColor: '#f0fdf4', color: '#16a34a'}}>
                  <FaChartPie />
                </div>
                <div style={summaryCardContentStyles}>
                  <div style={summaryCardValueStyles}>{avgAttendance}%</div>
                  <div style={summaryCardTitleStyles}>Avg Attendance</div>
                </div>
              </div>
            </div>

            <div style={sectionStyles}>
              <div style={sectionHeaderStyles}>
                <h2 style={sectionTitleStyles}>
                  <FaUsers /> Students Management
                </h2>
                <button 
                  style={{...btnStyles, ...btnPrimaryStyles}}
                  onClick={() => setShowAddModal('student')}
                >
                  <FaPlus /> Add Student
                </button>
              </div>
              
              {yearOrder.map(year => {
                const yearStudents = studentsByYear[year];
                return (
                  <div key={year} style={dropdownSectionStyles}>
                    <div 
                      style={dropdownHeaderStyles}
                      onClick={() => toggleDropdown(`students-${year}`)}
                    >
                      <span>{year} ({yearStudents.length} students)</span>
                      <span style={{
                        ...chevronStyles,
                        transform: openDropdowns[`students-${year}`] ? 'rotate(90deg)' : 'rotate(0deg)'
                      }}>
                        <FaChevronRight />
                      </span>
                    </div>

                    {openDropdowns[`students-${year}`] && (
                      <div style={dropdownContentStyles}>
                        {yearStudents.length === 0 ? (
                          <p style={{ padding: '10px', color: '#666' }}>
                            No students in this year
                          </p>
                        ) : (
                          <div style={tableContainerStyles}>
                            <table style={tableStyles}>
                              <thead>
                                <tr>
                                  <th style={tableHeaderStyles}>ID</th>
                                  <th style={tableHeaderStyles}>Name</th>
                                  <th style={tableHeaderStyles}>Email</th>
                                  <th style={tableHeaderStyles}>Attendance %</th>
                                  <th style={tableHeaderStyles}>Actions</th>
                                </tr>
                              </thead>
                              <tbody>
                                {yearStudents.map(student => {
                                  const studentAttendance = attendance.filter(a => a.studentId === student.studentId);
                                  const avgAttendance = studentAttendance.length > 0
                                    ? Math.round(studentAttendance.reduce((sum, a) => sum + a.percentage, 0) / studentAttendance.length)
                                    : 0;

                                  return (
                                    <tr key={student.id} style={tableRowStyles}>
                                      <td style={tableCellStyles}>{student.studentId}</td>
                                      <td style={tableCellStyles}>{student.name}</td>
                                      <td style={tableCellStyles}>{student.email}</td>
                                      <td style={tableCellStyles}>
                                        <span style={{
                                          ...attendancePercentageStyles,
                                          color: avgAttendance >= 85 ? '#16a34a' : avgAttendance >= 75 ? '#d97706' : '#dc2626'
                                        }}>
                                          {avgAttendance}%
                                        </span>
                                      </td>
                                      <td style={tableCellStyles}>
                                        <div style={actionButtonsStyles}>
                                          <button 
                                            style={{...actionBtnStyles, ...actionBtnPrimaryStyles}}
                                            onClick={() => handleGenerateTempPassword(student.id)}
                                            title="Generate Temporary Password"
                                          >
                                            <FaKey />
                                          </button>
                                          <button 
                                            style={{...actionBtnStyles, ...actionBtnSecondaryStyles}}
                                            onClick={() => handleViewAttendance(student)}
                                            title="View Attendance"
                                          >
                                            <FaEye />
                                          </button>
                                          <button 
                                            style={{...actionBtnStyles, ...actionBtnSuccessStyles}}
                                            onClick={() => exportCSV(studentAttendance, `${student.studentId}_attendance.csv`)}
                                            title="Export CSV"
                                          >
                                            <FaDownload />
                                          </button>
                                          <button 
                                            style={{...actionBtnStyles, ...actionBtnDangerStyles}}
                                            onClick={async () => {
                                              if (window.confirm(`Are you sure you want to delete ${student.name}?`)) {
                                                try {
                                                  await removeUser(student.id);
                                                  await loadAllUsers();
                                                  showNotification('success', `${student.name} deleted`);
                                                } catch (err) {
                                                  showNotification('error', err?.error || 'Delete failed');
                                                }
                                              }
                                            }}
                                            title="Delete Student"
                                          >
                                            <FaTrash />
                                          </button>
                                        </div>
                                      </td>
                                    </tr>
                                  );
                                })}
                              </tbody>
                            </table>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </>
          )}

          {/* Staff Section */}
          {activeSection === 'staff' && (
            <>
              <div style={summaryCardsStyles}>
                <div style={summaryCardStyles}>
                  <div style={{...summaryCardIconStyles, backgroundColor: '#f0f9ff', color: '#0284c7'}}>
                    <FaUsers />
                  </div>
                  <div style={summaryCardContentStyles}>
                    <div style={summaryCardValueStyles}>{totalStaff}</div>
                    <div style={summaryCardTitleStyles}>Total Staff</div>
                  </div>
                </div>
                <div style={summaryCardStyles}>
                  <div style={{...summaryCardIconStyles, backgroundColor: '#fef3c7', color: '#d97706'}}>
                    <FaCog />
                  </div>
                  <div style={summaryCardContentStyles}>
                    <div style={summaryCardValueStyles}>{filteredStaff.reduce((sum, s) => sum + (s.assignedLabs?.length || 0), 0)}</div>
                    <div style={summaryCardTitleStyles}>Lab Assignments</div>
                  </div>
                </div>
              </div>

              <div style={sectionStyles}>
                <div style={sectionHeaderStyles}>
                  <h2 style={sectionTitleStyles}>
                    <FaUsers /> Staff Management
                  </h2>
                  <button 
                    style={{...btnStyles, ...btnPrimaryStyles}}
                    onClick={() => setShowAddModal('staff')}
                  >
                    <FaPlus /> Add Staff
                  </button>
                </div>

                <div style={tableContainerStyles}>
                  <table style={tableStyles}>
                    <thead>
                      <tr>
                        <th style={tableHeaderStyles}>Name</th>
                        <th style={tableHeaderStyles}>Email</th>
                        <th style={tableHeaderStyles}>Assigned Labs</th>
                        <th style={tableHeaderStyles}>Lab Count</th>
                        <th style={tableHeaderStyles}>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredStaff.length === 0 ? (
                        <tr>
                          <td colSpan="5" style={{ textAlign: 'center', padding: '15px', color: '#666' }}>
                            No staff members found
                          </td>
                        </tr>
                      ) : (
                        Object.keys(staffByDept).map(dept => {
                          const deptStaff = staffByDept[dept];
                          return (
                            <React.Fragment key={dept}>
                              <tr>
                                <td colSpan="5" style={{ background: '#f3f4f6', fontWeight: 'bold', padding: '10px' }}>
                                  {dept} ({deptStaff.length} staff)
                                </td>
                              </tr>
                              {deptStaff.map(staff => (
                                <tr key={staff.id} style={tableRowStyles}>
                                  <td style={tableCellStyles}>{staff.name}</td>
                                  <td style={tableCellStyles}>{staff.email}</td>
                                  <td style={tableCellStyles}>
                                    <div>
                                      {staff.assignedLabs && staff.assignedLabs.length > 0 ? (
                                        <div>
                                          {staff.assignedLabs.map((lab, index) => (
                                            <span key={lab} style={labTagStyles}>
                                              {lab}
                                              {index < staff.assignedLabs.length - 1 && ', '}
                                            </span>
                                          ))}
                                        </div>
                                      ) : (
                                        <span style={{ color: '#999', fontStyle: 'italic' }}>No labs assigned</span>
                                      )}
                                    </div>
                                  </td>
                                  <td style={tableCellStyles}>
                                    <span style={{
                                      ...labCountStyles,
                                      backgroundColor: (staff.assignedLabs?.length || 0) > 0 ? '#3b82f6' : '#6b7280',
                                      color: 'white'
                                    }}>
                                      {staff.assignedLabs?.length || 0}
                                    </span>
                                  </td>
                                  <td style={tableCellStyles}>
                                    <div style={actionButtonsStyles}>
                                      <button 
                                        style={{...actionBtnStyles, ...actionBtnInfoStyles}}
                                        onClick={() => handleAssignLabs(staff)}
                                        title="Assign Labs"
                                      >
                                        <FaCog /> Assign
                                      </button>
                                      <button 
                                        style={{...actionBtnStyles, ...actionBtnPrimaryStyles}}
                                        onClick={() => handleGenerateTempPassword(staff.id)}
                                        title="Generate Temporary Password"
                                      >
                                        <FaKey />
                                      </button>
                                      <button 
                                        style={{...actionBtnStyles, ...actionBtnDangerStyles}}
                                        onClick={async () => {
                                          if (window.confirm(`Are you sure you want to delete ${staff.name}?`)) {
                                            try {
                                              await removeUser(staff.id);
                                              await loadAllUsers();
                                              showNotification('success', `${staff.name} deleted`);
                                            } catch (err) {
                                              showNotification('error', err?.error || 'Delete failed');
                                            }
                                          }
                                        }}
                                        title="Delete Staff"
                                      >
                                        <FaTrash />
                                      </button>
                                    </div>
                                  </td>
                                </tr>
                              ))}
                            </React.Fragment>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}

          {/* Lab Subjects Management Section */}
          {activeSection === 'subjects' && (
        <div className="section">
          <div className="section-header">
            <h2 className="section-title">
              <FaBook /> Lab Subject Management
            </h2>
            <div className="manager-controls">
              <button 
                className={`btn ${loading ? 'btn-loading' : 'btn-primary'}`}
                onClick={applySubjectsToStudents}
                disabled={labSubjects[selectedYear]?.length === 0 || loading}
                style={{ 
                  opacity: loading ? 0.7 : 1,
                  cursor: loading ? 'not-allowed' : 'pointer',
                  position: 'relative'
                }}
              >
                {loading ? (
                  <>
                    <div className="spinner" style={{
                      display: 'inline-block',
                      width: '16px',
                      height: '16px',
                      border: '2px solid #ffffff',
                      borderRadius: '50%',
                      borderTopColor: 'transparent',
                      animation: 'spin 1s linear infinite',
                      marginRight: '8px'
                    }} />
                    Processing Assignment...
                  </>
                ) : (
                  <>
                    <FaCheckCircle /> Apply to All {selectedYear} Students ({getStudentCount(selectedYear)} students)
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Year Selector */}
          <div className="year-selector" style={{ 
            marginBottom: '20px',
            padding: '15px',
            backgroundColor: '#f8f9fa',
            borderRadius: '8px',
            border: '1px solid #e9ecef'
          }}>
            <label style={{ 
              fontWeight: 'bold', 
              marginBottom: '8px', 
              display: 'block',
              color: '#495057'
            }}>
              📚 Select Year to Manage:
            </label>
            <select 
              value={selectedYear}
              onChange={(e) => setSelectedYear(e.target.value)}
              style={{
                padding: '10px 15px',
                borderRadius: '6px',
                border: '1px solid #ced4da',
                backgroundColor: 'white',
                fontSize: '16px',
                fontWeight: '500',
                color: '#495057',
                cursor: 'pointer',
                minWidth: '200px'
              }}
            >
              <option value="2nd Year">2nd Year ({getStudentCount('2nd Year')} students)</option>
              <option value="3rd Year">3rd Year ({getStudentCount('3rd Year')} students)</option>
              <option value="4th Year">4th Year ({getStudentCount('4th Year')} students)</option>
            </select>
          </div>

          {/* Lab Subjects List */}
          <div className="lab-subjects-container" style={{
            backgroundColor: 'white',
            borderRadius: '8px',
            border: '1px solid #e9ecef',
            overflow: 'hidden'
          }}>
            {/* Header */}
            <div style={{
              backgroundColor: '#f8f9fa',
              padding: '15px',
              borderBottom: '1px solid #e9ecef',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center'
            }}>
              <h3 style={{ margin: 0, color: '#495057' }}>
                👨‍🎓 {selectedYear} Lab Subjects ({labSubjects[selectedYear]?.length || 0} subjects)
              </h3>
              <button 
                className="btn-primaryls"
                onClick={() => setShowAddForm(true)}
                disabled={showAddForm}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px'
                }}
              >
                <FaPlus /> Add Subject
              </button>
            </div>

            {/* Add New Subject Form */}
            {showAddForm && (
              <div style={{
                padding: '20px',
                backgroundColor: '#f8f9fa',
                borderBottom: '1px solid #e9ecef'
              }}>
                <label style={{
                  fontWeight: 'bold',
                  marginBottom: '10px',
                  display: 'block',
                  color: '#495057'
                }}>
                  ✏️ New Subject Name:
                </label>
                
                <div style={{ 
                  display: 'flex', 
                  gap: '12px', 
                  alignItems: 'center',
                  marginBottom: '15px'
                }}>
                  <input
                    type="text"
                    value={newSubject}
                    onChange={(e) => setNewSubject(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleAddSubject()}
                    placeholder="Enter lab subject name (e.g., Advanced Physics Lab)"
                    autoFocus
                    style={{
                      flex: 1,
                      padding: '12px 16px',
                      fontSize: '16px',
                      border: '2px solid #ced4da',
                      borderRadius: '6px',
                      outline: 'none',
                      transition: 'border-color 0.2s ease',
                      backgroundColor: 'white'
                    }}
                    onFocus={(e) => {
                      e.target.style.borderColor = '#007bff';
                    }}
                    onBlur={(e) => {
                      e.target.style.borderColor = '#ced4da';
                    }}
                  />
                  
                  <button 
                    className="btn-primaryls"
                    onClick={handleAddSubject}
                    disabled={!newSubject.trim()}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '6px',
                      minWidth: '100px'
                    }}
                  >
                    <FaSave /> Save
                  </button>
                  
                  <button 
                    className="btn-secondaryls"
                    onClick={handleCancelAdd}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '6px'
                    }}
                  >
                    <FaTimes /> Cancel
                  </button>
                </div>

                <div style={{
                  padding: '10px',
                  backgroundColor: '#d1ecf1',
                  border: '1px solid #bee5eb',
                  borderRadius: '6px',
                  fontSize: '14px',
                  color: '#0c5460'
                }}>
                  <FaGraduationCap style={{ marginRight: '8px' }} />
                  This subject will be created in the database and available for assignment to <strong>{selectedYear}</strong> students.
                  Click "Apply to All Students" after adding subjects to assign them.
                </div>
              </div>
            )}

            {/* Subjects List */}
            <div style={{ padding: '15px' }}>
              {(!labSubjects[selectedYear] || labSubjects[selectedYear].length === 0) ? (
                <div style={{
                  textAlign: 'center',
                  padding: '40px 20px',
                  color: '#6c757d'
                }}>
                  <div style={{ fontSize: '48px', marginBottom: '16px' }}>📚</div>
                  <h4 style={{ margin: '0 0 8px 0', color: '#495057' }}>
                    No lab subjects assigned to {selectedYear} yet.
                  </h4>
                  <p style={{ margin: 0, fontSize: '14px' }}>
                    Click "Add Subject" to start assigning lab subjects.
                  </p>
                </div>
              ) : (
                <div className="subjects-list">
                  <table style={{
                    width: '100%',
                    borderCollapse: 'collapse'
                  }}>
                    <thead>
                      <tr style={{ backgroundColor: '#f8f9fa' }}>
                        <th style={{
                          padding: '12px',
                          textAlign: 'left',
                          borderBottom: '2px solid #e9ecef',
                          color: '#495057',
                          fontWeight: 'bold'
                        }}>#</th>
                        <th style={{
                          padding: '12px',
                          textAlign: 'left',
                          borderBottom: '2px solid #e9ecef',
                          color: '#495057',
                          fontWeight: 'bold'
                        }}>SUBJECT NAME</th>
                        <th style={{
                          padding: '12px',
                          textAlign: 'center',
                          borderBottom: '2px solid #e9ecef',
                          color: '#495057',
                          fontWeight: 'bold'
                        }}>ACTIONS</th>
                      </tr>
                    </thead>
                    <tbody>
                      {labSubjects[selectedYear].map((subject, index) => (
                        <tr key={index} style={{
                          borderBottom: '1px solid #e9ecef'
                        }}>
                          <td style={{ 
                            padding: '12px',
                            color: '#6c757d',
                            fontWeight: 'bold'
                          }}>
                            {index + 1}
                          </td>
                          <td style={{ 
                            padding: '12px',
                            color: '#495057',
                            fontWeight: '500'
                          }}>
                            {editingSubject === index ? (
                              <input
                                type="text"
                                value={editingValue}
                                onChange={(e) => setEditingValue(e.target.value)}
                                onKeyPress={(e) => {
                                  if (e.key === 'Enter') handleSaveEdit(index);
                                  if (e.key === 'Escape') handleCancelEdit();
                                }}
                                onBlur={() => handleSaveEdit(index)}
                                autoFocus
                                style={{
                                  width: '100%',
                                  padding: '8px',
                                  border: '2px solid #007bff',
                                  borderRadius: '4px',
                                  fontSize: '14px'
                                }}
                              />
                            ) : (
                              subject
                            )}
                          </td>
                          <td style={{ 
                            padding: '12px',
                            textAlign: 'center'
                          }}>
                            {editingSubject === index ? (
                              <div style={{ display: 'flex', gap: '8px', justifyContent: 'center' }}>
                                <button
                                  onClick={() => handleSaveEdit(index)}
                                  style={{
                                    padding: '6px 12px',
                                    backgroundColor: '#28a745',
                                    color: 'white',
                                    border: 'none',
                                    borderRadius: '4px',
                                    cursor: 'pointer',
                                    fontSize: '12px'
                                  }}
                                >
                                  <FaCheck />
                                </button>
                                <button
                                  onClick={handleCancelEdit}
                                  style={{
                                    padding: '6px 12px',
                                    backgroundColor: '#6c757d',
                                    color: 'white',
                                    border: 'none',
                                    borderRadius: '4px',
                                    cursor: 'pointer',
                                    fontSize: '12px'
                                  }}
                                >
                                  <FaTimes />
                                </button>
                              </div>
                            ) : (
                              <div style={{ display: 'flex', gap: '8px', justifyContent: 'center' }}>
                                <button
                                  onClick={() => handleEditSubject(index, subject)}
                                  style={{
                                    padding: '6px 12px',
                                    backgroundColor: '#007bff',
                                    color: 'white',
                                    border: 'none',
                                    borderRadius: '4px',
                                    cursor: 'pointer',
                                    fontSize: '12px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '4px'
                                  }}
                                >
                                  <FaEdit /> Edit
                                </button>
                                <button
                                  onClick={() => handleRemoveSubject(subject)}
                                  style={{
                                    padding: '6px 12px',
                                    backgroundColor: '#dc3545',
                                    color: 'white',
                                    border: 'none',
                                    borderRadius: '4px',
                                    cursor: 'pointer',
                                    fontSize: '12px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '4px'
                                  }}
                                >
                                  <FaTrash /> Remove
                                </button>
                              </div>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>

          {/* Impact Information */}
          <div style={{
            marginTop: '20px',
            padding: '15px',
            backgroundColor: '#d1ecf1',
            border: '1px solid #bee5eb',
            borderRadius: '8px'
          }}>
            <h4 style={{ margin: '0 0 8px 0', color: '#0c5460' }}>
              <FaCheckCircle style={{ marginRight: '8px' }} />
              Impact Information
            </h4>
            <p style={{ margin: 0, color: '#0c5460', fontSize: '14px' }}>
              Changes to {selectedYear} subjects will automatically update lab assignments for <strong>{getStudentCount(selectedYear)} students</strong> in this year group.
              All lab subjects are stored in the database and will be available for staff assignment.
            </p>
          </div>
        </div>
      )}




          {/* Selected Student Attendance Details */}
          {selectedStudent && (
            <div style={sectionStyles}>
              <div style={sectionHeaderStyles}>
                <h2 style={sectionTitleStyles}>
                  Attendance Details - {selectedStudent.name}
                </h2>
                <div style={{display: 'flex', gap: '10px'}}>
                  <button 
                    style={{...btnStyles, ...btnSuccessStyles}}
                    onClick={() => {
                      const studentAttendance = attendance.filter(a => a.studentId === selectedStudent.studentId);
                      exportCSV(studentAttendance, `${selectedStudent.studentId}_detailed_attendance.csv`);
                    }}
                  >
                    <FaDownload /> Export CSV
                  </button>
                  <button 
                    style={{...btnStyles, ...btnSecondaryStyles}}
                    onClick={() => setSelectedStudent(null)}
                  >
                    Close
                  </button>
                </div>
              </div>
              <div style={tableContainerStyles}>
                <table style={tableStyles}>
                  <thead>
                    <tr>
                      <th style={tableHeaderStyles}>Date</th>
                      <th style={tableHeaderStyles}>Subject/Lab</th>
                      <th style={tableHeaderStyles}>Status</th>
                      <th style={tableHeaderStyles}>Percentage</th>
                    </tr>
                  </thead>
                  <tbody>
                    {attendance
                      .filter(a => a.studentId === selectedStudent.studentId)
                      .map(record => (
                        <tr key={record.id} style={tableRowStyles}>
                          <td style={tableCellStyles}>{record.date}</td>
                          <td style={tableCellStyles}>{record.lab}</td>
                          <td style={tableCellStyles}>
                            <span style={{
                              ...attendancePercentageStyles,
                              color: record.status === 'present' ? '#16a34a' : '#dc2626'
                            }}>
                              {record.status.toUpperCase()}
                            </span>
                          </td>
                          <td style={tableCellStyles}>{record.percentage}%</td>
                        </tr>
                      ))
                    }
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Analytics Chart */}
          {activeSection === 'analytics' && (
          <div style={chartContainerStyles}>
            <h2 style={chartTitleStyles}>
              <FaChartPie /> Year-wise Attendance Distribution
            </h2>
            <ResponsiveContainer width="100%" height={400}>
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({name, value, students}) => `${name}: ${value}% (${students} students)`}
                  outerRadius={120}
                  fill="#8884d8"
                  dataKey="value"
                  onClick={(data, index) => setDrilldownYear(pieData[index]?.name || null)}
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value, name, props) => [
                  `${value}%`, 
                  `${props.payload.name} (${props.payload.students} students)`
                ]} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
          )}
          
          {activeSection === 'analytics' && drilldownYear && (
            <div style={sectionStyles}>
              <div style={sectionHeaderStyles}>
                <h2 style={sectionTitleStyles}>{drilldownYear} - Students Detail</h2>
                <button style={{...btnStyles, ...btnSecondaryStyles}} onClick={() => setDrilldownYear(null)}>Close</button>
              </div>
              {(studentsByYear[drilldownYear] || []).map(student => (
                <div key={student.id} style={{...tableContainerStyles, marginBottom: '16px'}}>
                  <h3 style={{ margin: '8px 0' }}>{student.name} ({student.studentId})</h3>
                  <table style={tableStyles}>
                    <thead>
                      <tr>
                        <th style={tableHeaderStyles}>Date</th>
                        <th style={tableHeaderStyles}>Subject/Lab</th>
                        <th style={tableHeaderStyles}>Status</th>
                        <th style={tableHeaderStyles}>Percentage</th>
                      </tr>
                    </thead>
                    <tbody>
                      {attendance
                        .filter(a => a.studentId === student.studentId && (labFilter === 'All Labs' || a.lab === labFilter))
                        .map(record => (
                          <tr key={record.id} style={tableRowStyles}>
                            <td style={tableCellStyles}>{record.date}</td>
                            <td style={tableCellStyles}>{record.lab}</td>
                            <td style={tableCellStyles}>
                              <span style={{
                                ...attendancePercentageStyles,
                                color: record.status === 'present' ? '#16a34a' : '#dc2626'
                              }}>
                                {record.status.toUpperCase()}
                              </span>
                            </td>
                            <td style={tableCellStyles}>{record.percentage}%</td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              ))}
            </div>
          )}

        </main>
      </div>

      {/* Modals */}
      {showAddModal && (
        <AddUserModal
          type={showAddModal}
          onClose={() => setShowAddModal(null)}
          onAdd={handleAddUser}
        />
      )}

      {tempPassword && (
        <TempPasswordModal
          password={tempPassword}
          onClose={() => setTempPassword(null)}
        />
      )}

      {showLabAssignModal && (
        <LabAssignmentModal
          staff={showLabAssignModal}
          onClose={() => {
            setShowLabAssignModal(null);
            setSelectedStaffLabs([]);
          }}
        />
      )}

      {showChangePassword && (
        <div className="modal-overlay">
          <div className="modal">
            <h2 className="modal-header">Change Password</h2>
            <ChangePasswordForm onCancel={() => setShowChangePassword(false)} onSave={handleChangePassword} />
          </div>
        </div>
      )}
    </div>
  );
};

const ChangePasswordForm = ({ onCancel, onSave }) => {
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const canSave = password && password.length >= 6 && password === confirm;
  return (
    <div>
      <div className="form-group">
        <label className="form-label">New Password</label>
        <input className="form-input" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Enter new password" />
      </div>
      <div className="form-group">
        <label className="form-label">Confirm Password</label>
        <input className="form-input" type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} placeholder="Re-enter password" />
      </div>
      <div className="modal-actions">
        <button className="btn btn-secondary" onClick={onCancel}>Cancel</button>
        <button className="btn btn-primary" disabled={!canSave} onClick={() => onSave(password)}>Save Password</button>
      </div>
    </div>
  );
};

// Styles
const dashboardContainerStyles = {
  background: '#f8fafc',
  minHeight: '100vh',
  fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
  color: '#1e293b'
};

const dashboardHeaderStyles = {
  background: '#3b82f6',
  boxShadow: '0 1px 3px rgba(0, 0, 0, 0.12), 0 1px 2px rgba(0, 0, 0, 0.24)',
  padding: '16px 24px',
  borderBottom: '1px solid #e2e8f0'
};

const dashboardNavStyles = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center'
};

const dashboardTitleStyles = {
  color: 'white',
  fontSize: '20px',
  fontWeight: '600',
  margin: 0
};

const profileAreaStyles = {
  position: 'relative'
};


const profileButtonStyles = {
  background: 'rgba(255, 255, 255, 0.1)',
  border: '1px solid rgba(255, 255, 255, 0.2)',
  borderRadius: '50%',
  width: '36px',
  height: '36px',
  color: 'white',
  cursor: 'pointer',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  fontSize: '16px',
  transition: 'all 0.2s ease'
};

const profileDropdownStyles = {
  position: 'absolute',
  top: '45px',
  right: '0',
  background: 'white',
  borderRadius: '8px',
  boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
  minWidth: '200px',
  zIndex: 1000,
  overflow: 'hidden',
  border: '1px solid #e5e7eb'
};

const profileInfoRowStyles = {
  padding: '10px 16px',
  fontSize: '14px',
  color: '#374151',
  borderBottom: '1px solid #f3f4f6'
};

const profileDividerStyles = {
  height: '1px',
  background: '#e5e7eb',
  margin: '4px 0'
};

const profileItemStyles = {
  width: '100%',
  background: 'none',
  border: 'none',
  padding: '10px 16px',
  textAlign: 'left',
  cursor: 'pointer',
  fontSize: '14px',
  color: '#374151',
  display: 'flex',
  alignItems: 'center',
  gap: '8px',
  transition: 'background 0.15s ease'
};

const dashboardContentStyles = {
  display: 'flex',
  minHeight: 'calc(100vh - 73px)'
};

const sidebarStyles = {
  width: '220px',
  background: 'white',
  boxShadow: '1px 0 3px rgba(0, 0, 0, 0.1)',
  padding: '16px 0',
  borderRight: '1px solid #e5e7eb'
};

const sidebarItemStyles = {
  width: '100%',
  background: 'none',
  border: 'none',
  padding: '12px 20px',
  textAlign: 'left',
  cursor: 'pointer',
  fontSize: '14px',
  color: '#6b7280',
  display: 'flex',
  alignItems: 'center',
  gap: '12px',
  transition: 'all 0.15s ease',
  fontWeight: '500'
};

const sidebarItemActiveStyles = {
  background: '#3b82f6',
  color: 'white',
  borderRight: '3px solid #1d4ed8'
};

const dashboardMainStyles = {
  flex: 1,
  background: 'white',
  borderRadius: '0',
  padding: '24px',
  margin: '0',
  boxShadow: 'none',
  overflow: 'auto'
};

const controlsBarStyles = {
  display: 'flex',
  gap: '16px',
  marginBottom: '20px',
  padding: '16px',
  background: '#f8fafc',
  borderRadius: '8px',
  border: '1px solid #e5e7eb'
};

const filterGroupStyles = {
  display: 'flex',
  flexDirection: 'column',
  gap: '6px'
};

const filterLabelStyles = {
  fontSize: '13px',
  fontWeight: '500',
  color: '#374151',
  display: 'flex',
  alignItems: 'center',
  gap: '6px'
};

const filterSelectStyles = {
  padding: '6px 10px',
  border: '1px solid #d1d5db',
  borderRadius: '6px',
  fontSize: '13px',
  backgroundColor: 'white',
  minWidth: '140px'
};

const summaryCardsStyles = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
  gap: '16px',
  marginBottom: '24px'
};

const summaryCardStyles = {
  background: 'white',
  border: '1px solid #e5e7eb',
  borderRadius: '8px',
  padding: '20px',
  display: 'flex',
  alignItems: 'center',
  gap: '16px',
  transition: 'all 0.2s ease',
  boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)',
  cursor: 'default'
};

const summaryCardIconStyles = {
  width: '48px',
  height: '48px',
  borderRadius: '8px',
  backgroundColor: '#dbeafe',
  color: '#3b82f6',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  fontSize: '20px',
  flexShrink: 0
};

const summaryCardContentStyles = {
  display: 'flex',
  flexDirection: 'column',
  gap: '4px'
};

const summaryCardValueStyles = {
  fontSize: '28px',
  fontWeight: '700',
  color: '#1e293b',
  lineHeight: 1
};

const summaryCardTitleStyles = {
  fontSize: '13px',
  color: '#6b7280',
  fontWeight: '500',
  textTransform: 'uppercase',
  letterSpacing: '0.5px'
};

const studentsByYearGridStyles = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
  gap: '20px',
  marginBottom: '24px'
};

const yearOverviewCardStyles = {
  background: 'white',
  border: '1px solid #e5e7eb',
  borderRadius: '8px',
  padding: '20px',
  transition: 'all 0.2s ease',
  boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)',
  cursor: 'default'
};

const yearCardHeaderStyles = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginBottom: '16px'
};

const yearTitleStyles = {
  fontSize: '18px',
  fontWeight: '600',
  color: '#1e293b',
  margin: 0
};

const yearIconStyles = {
  width: '40px',
  height: '40px',
  borderRadius: '50%',
  background: '#3b82f6',
  color: 'white',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  fontSize: '16px'
};

const yearCardContentStyles = {
  marginBottom: '16px'
};

const studentCountDisplayStyles = {
  display: 'flex',
  alignItems: 'baseline',
  gap: '8px',
  marginBottom: '8px'
};

const countNumberStyles = {
  fontSize: '32px',
  fontWeight: '700',
  color: '#3b82f6',
  lineHeight: 1
};

const countLabelStyles = {
  fontSize: '14px',
  color: '#6b7280',
  fontWeight: '500'
};

const subjectCountDisplayStyles = {
  display: 'flex',
  alignItems: 'baseline',
  gap: '8px',
  paddingLeft: '12px',
  borderLeft: '3px solid #e5e7eb'
};

const subjectCountStyles = {
  fontSize: '20px',
  fontWeight: '600',
  color: '#374151'
};

const subjectLabelStyles = {
  fontSize: '12px',
  color: '#6b7280',
  fontWeight: '500'
};

const yearCardFooterStyles = {
  borderTop: '1px solid #e5e7eb',
  paddingTop: '16px'
};

const viewDetailsBtnStyles = {
  width: '100%',
  background: '#3b82f6',
  color: 'white',
  border: 'none',
  padding: '10px 16px',
  borderRadius: '6px',
  fontSize: '14px',
  fontWeight: '500',
  cursor: 'pointer',
  transition: 'background 0.2s ease'
};

const quickActionsStyles = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
  gap: '16px',
  marginBottom: '24px'
};

const quickActionBtnStyles = {
  background: 'white',
  border: '1px solid #e5e7eb',
  borderRadius: '8px',
  padding: '16px',
  display: 'flex',
  alignItems: 'center',
  gap: '12px',
  cursor: 'pointer',
  transition: 'all 0.2s ease',
  boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)'
};

const quickActionIconStyles = {
  width: '36px',
  height: '36px',
  borderRadius: '6px',
  backgroundColor: '#dbeafe',
  color: '#3b82f6',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  fontSize: '16px',
  flexShrink: 0
};

const quickActionTextStyles = {
  fontSize: '14px',
  fontWeight: '500',
  color: '#374151'
};

const sectionStyles = {
  marginBottom: '32px'
};

const sectionHeaderStyles = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginBottom: '16px',
  paddingBottom: '12px',
  borderBottom: '1px solid #e5e7eb'
};

const sectionTitleStyles = {
  fontSize: '20px',
  fontWeight: '600',
  color: '#1e293b',
  display: 'flex',
  alignItems: 'center',
  gap: '8px',
  margin: 0
};

const dropdownSectionStyles = {
  marginBottom: '16px',
  border: '1px solid #e5e7eb',
  borderRadius: '8px',
  overflow: 'hidden',
  boxShadow: '0 1px 3px rgba(0, 0, 0, 0.05)'
};

const dropdownHeaderStyles = {
  padding: '14px 16px',
  background: '#f8fafc',
  cursor: 'pointer',
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  fontWeight: '500',
  color: '#374151',
  transition: 'background 0.15s ease',
  fontSize: '14px'
};

const chevronStyles = {
  transition: 'transform 0.2s ease',
  fontSize: '12px'
};

const dropdownContentStyles = {
  padding: '16px'
};

const tableContainerStyles = {
  background: 'white',
  borderRadius: '8px',
  overflow: 'hidden',
  boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)',
  border: '1px solid #e5e7eb'
};

const tableStyles = {
  width: '100%',
  borderCollapse: 'collapse'
};

const tableHeaderStyles = {
  background: '#3b82f6',
  color: 'white',
  padding: '12px',
  textAlign: 'left',
  fontWeight: '500',
  fontSize: '13px',
  textTransform: 'uppercase',
  letterSpacing: '0.5px'
};

const tableRowStyles = {
  borderBottom: '1px solid #e5e7eb',
  transition: 'background 0.15s ease'
};

const tableCellStyles = {
  padding: '12px',
  fontSize: '13px',
  color: '#374151'
};

const attendancePercentageStyles = {
  fontWeight: '500',
  padding: '2px 6px',
  borderRadius: '4px',
  fontSize: '12px'
};

const actionButtonsStyles = {
  display: 'flex',
  gap: '6px',
  flexWrap: 'wrap'
};

const actionBtnStyles = {
  border: 'none',
  borderRadius: '4px',
  padding: '6px 10px',
  cursor: 'pointer',
  fontSize: '12px',
  display: 'flex',
  alignItems: 'center',
  gap: '4px',
  transition: 'all 0.15s ease',
  fontWeight: '500'
};

const actionBtnPrimaryStyles = {
  background: '#3b82f6',
  color: 'white'
};

const actionBtnSecondaryStyles = {
  background: '#6b7280',
  color: 'white'
};

const actionBtnSuccessStyles = {
  background: '#16a34a',
  color: 'white'
};

const actionBtnDangerStyles = {
  background: '#dc2626',
  color: 'white'
};

const actionBtnInfoStyles = {
  background: '#0284c7',
  color: 'white'
};

const labTagStyles = {
  display: 'inline-block',
  background: '#f3f4f6',
  color: '#374151',
  padding: '2px 6px',
  borderRadius: '4px',
  fontSize: '12px',
  fontWeight: '500'
};

const labCountStyles = {
  padding: '2px 8px',
  borderRadius: '10px',
  fontSize: '12px',
  fontWeight: '500'
};

const btnStyles = {
  border: 'none',
  borderRadius: '6px',
  padding: '10px 16px',
  cursor: 'pointer',
  fontSize: '14px',
  fontWeight: '500',
  display: 'flex',
  alignItems: 'center',
  gap: '6px',
  transition: 'all 0.2s ease'
};

const btnPrimaryStyles = {
  background: '#3b82f6',
  color: 'white'
};

const btnSecondaryStyles = {
  background: '#6b7280',
  color: 'white'
};

const btnSuccessStyles = {
  background: '#16a34a',
  color: 'white'
};

const chartContainerStyles = {
  background: 'white',
  borderRadius: '8px',
  padding: '20px',
  marginBottom: '24px',
  border: '1px solid #e5e7eb',
  boxShadow: '0 1px 3px rgba(0, 0, 0, 0.05)'
};

const chartTitleStyles = {
  fontSize: '18px',
  fontWeight: '600',
  color: '#1e293b',
  marginBottom: '16px',
  display: 'flex',
  alignItems: 'center',
  gap: '8px'
};

const formInputStyles = {
  padding: '8px 12px',
  border: '1px solid #d1d5db',
  borderRadius: '6px',
  fontSize: '13px',
  transition: 'border-color 0.15s ease',
  boxSizing: 'border-box',
  width: '100%'
};
export default HODDashboard;