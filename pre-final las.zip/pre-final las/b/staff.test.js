/**
 * Lab Filter Feature Test Suite - Node Native Test Runner Version
 * Tests the new lab-based student filtering functionality
 * 
 * Run: node staff-lab-filter.test.js
 */

import { test, describe, before, after } from 'node:test';
import assert from 'node:assert';

// Configuration
const BASE_URL = process.env.API_URL || 'http://localhost:4000';
const STAFF_USERNAME = 'yok';
const STAFF_PASSWORD = 'temphkqtvh';
const STAFF_ROLE = 'STAFF';

// Test data storage
let authToken = null;
let staffData = null;
let assignedLabs = [];
let allStudents = [];
let transformedStudents = [];

// Helper function to make HTTP requests
async function request(method, path, options = {}) {
  const url = `${BASE_URL}${path}`;
  const headers = {
    'Content-Type': 'application/json',
    ...(options.token ? { Authorization: `Bearer ${options.token}` } : {}),
  };

  const config = {
    method,
    headers,
  };

  if (options.body) {
    config.body = JSON.stringify(options.body);
  }

  const response = await fetch(url, config);
  const data = await response.json();

  return {
    status: response.status,
    body: data,
    ok: response.ok,
  };
}

// Frontend transformation logic (simulating StaffDashboard.js)
function transformStudentData(apiStudents, assignedLabNames) {
  const studentMap = new Map();
  
  apiStudents.forEach(studentRecord => {
    const studentId = studentRecord.student_id;
    if (!studentMap.has(studentId)) {
      studentMap.set(studentId, {
        id: studentRecord.id,
        studentId: studentRecord.student_id,
        name: studentRecord.name,
        email: studentRecord.email,
        year: studentRecord.year,
        role: 'student',
        labs: []
      });
    }
    // Add lab name to student's labs array
    studentMap.get(studentId).labs.push(studentRecord.lab_name);
  });
  
  return Array.from(studentMap.values());
}

function filterStudentsByLab(students, labName) {
  if (labName === 'All') return students;
  return students.filter(student => student.labs.includes(labName));
}

function groupStudentsByYear(students) {
  const grouped = {
    '2nd': [],
    '3rd': [],
    '4th': []
  };
  
  students.forEach(student => {
    if (grouped[student.year]) {
      grouped[student.year].push(student);
    }
  });
  
  return grouped;
}

describe('🔬 Lab Filter Feature - Complete Test Suite', () => {
  
  // ====================
  // 1. AUTHENTICATION TESTS
  // ====================
  describe('1️⃣ Authentication Test', () => {
    
    test('1.1 Login with staff credentials (yok/temphkqtvh)', async () => {
      const res = await request('POST', '/auth/login', {
        body: {
          username: STAFF_USERNAME,
          password: STAFF_PASSWORD,
          role: STAFF_ROLE
        }
      });

      assert.strictEqual(res.status, 200, 'Status should be 200');
      assert.ok(res.body.token, 'Response should have token');
      assert.ok(res.body.user, 'Response should have user');
      assert.strictEqual(res.body.user.role, 'STAFF', 'User role should be STAFF');
      
      authToken = res.body.token;
      staffData = res.body.user;
      
      console.log('✅ Staff authenticated:', staffData.name);
    });
  });

  // ====================
  // 2. DATA RETRIEVAL TESTS
  // ====================
  describe('2️⃣ Dashboard & Data Retrieval Test', () => {
    
    test('2.1 Fetch staff dashboard', async () => {
      const res = await request('GET', '/staff/dashboard', { token: authToken });

      assert.strictEqual(res.status, 200, 'Status should be 200');
      assert.ok(res.body.user_name, 'Should have user_name');
      assert.ok(Array.isArray(res.body.assigned_labs), 'assigned_labs should be array');
      assert.ok(res.body.assigned_labs.length > 0, 'Should have at least one assigned lab');
      
      console.log('✅ Dashboard loaded with', res.body.assigned_labs.length, 'labs');
    });

    test('2.2 Fetch assigned labs', async () => {
      const res = await request('GET', '/staff/labs', { token: authToken });

      assert.strictEqual(res.status, 200, 'Status should be 200');
      assert.ok(Array.isArray(res.body), 'Response should be array');
      assert.ok(res.body.length > 0, 'Should have assigned labs');
      
      assignedLabs = res.body;
      
      console.log('✅ Found', assignedLabs.length, 'assigned labs');
      assignedLabs.forEach(lab => {
        console.log(`   - ${lab.name} (${lab.year})`);
      });
    });

    test('2.3 Fetch all students in assigned labs', async () => {
      const res = await request('GET', '/staff/students', { token: authToken });

      assert.strictEqual(res.status, 200, 'Status should be 200');
      assert.ok(Array.isArray(res.body), 'Response should be array');
      assert.ok(res.body.length > 0, 'Should have students');
      
      allStudents = res.body;
      
      // Transform data like frontend does
      const labNames = assignedLabs.map(lab => lab.name);
      transformedStudents = transformStudentData(allStudents, labNames);
      
      console.log('✅ Found', allStudents.length, 'student-lab records');
      console.log('✅ Transformed to', transformedStudents.length, 'unique students');
    });
  });

  // ====================
  // 3. LAB FILTERING LOGIC TESTS
  // ====================
  describe('3️⃣ Lab Filtering Logic Test', () => {
    
    test('3.1 Filter: All Labs (should show all students)', async () => {
      const filtered = filterStudentsByLab(transformedStudents, 'All');
      
      assert.strictEqual(filtered.length, transformedStudents.length, 
        'All Labs filter should return all students');
      
      console.log('✅ "All Labs" shows', filtered.length, 'students');
    });

    test('3.2 Filter: Python Programming', async () => {
      const pythonLab = assignedLabs.find(lab => lab.name === 'Python Programming');
      
      if (pythonLab) {
        const filtered = filterStudentsByLab(transformedStudents, 'Python Programming');
        
        assert.ok(filtered.length > 0, 'Should have students in Python Programming');
        
        // Verify all filtered students have this lab
        filtered.forEach(student => {
          assert.ok(student.labs.includes('Python Programming'), 
            `Student ${student.name} should have Python Programming in labs`);
        });
        
        const grouped = groupStudentsByYear(filtered);
        console.log('✅ "Python Programming" shows', filtered.length, 'students');
        console.log(`   2nd: ${grouped['2nd'].length}, 3rd: ${grouped['3rd'].length}, 4th: ${grouped['4th'].length}`);
      }
    });

    test('3.3 Filter: Workflow Test Lab', async () => {
      const workflowLab = assignedLabs.find(lab => lab.name === 'Workflow Test Lab');
      
      if (workflowLab) {
        const filtered = filterStudentsByLab(transformedStudents, 'Workflow Test Lab');
        
        assert.ok(filtered.length > 0, 'Should have students in Workflow Test Lab');
        
        filtered.forEach(student => {
          assert.ok(student.labs.includes('Workflow Test Lab'), 
            `Student ${student.name} should have Workflow Test Lab in labs`);
        });
        
        const grouped = groupStudentsByYear(filtered);
        console.log('✅ "Workflow Test Lab" shows', filtered.length, 'students');
        console.log(`   2nd: ${grouped['2nd'].length}, 3rd: ${grouped['3rd'].length}, 4th: ${grouped['4th'].length}`);
      }
    });

    test('3.4 Filter: pet', async () => {
      const petLab = assignedLabs.find(lab => lab.name === 'pet');
      
      if (petLab) {
        const filtered = filterStudentsByLab(transformedStudents, 'pet');
        
        assert.ok(filtered.length > 0, 'Should have students in pet');
        
        filtered.forEach(student => {
          assert.ok(student.labs.includes('pet'), 
            `Student ${student.name} should have pet in labs`);
        });
        
        const grouped = groupStudentsByYear(filtered);
        console.log('✅ "pet" shows', filtered.length, 'students');
        console.log(`   2nd: ${grouped['2nd'].length}, 3rd: ${grouped['3rd'].length}, 4th: ${grouped['4th'].length}`);
      }
    });

    test('3.5 Filter: Physics Lab', async () => {
      const physicsLab = assignedLabs.find(lab => lab.name === 'Physics Lab');
      
      if (physicsLab) {
        const filtered = filterStudentsByLab(transformedStudents, 'Physics Lab');
        
        assert.ok(filtered.length > 0, 'Should have students in Physics Lab');
        
        filtered.forEach(student => {
          assert.ok(student.labs.includes('Physics Lab'), 
            `Student ${student.name} should have Physics Lab in labs`);
        });
        
        const grouped = groupStudentsByYear(filtered);
        console.log('✅ "Physics Lab" shows', filtered.length, 'students');
        console.log(`   2nd: ${grouped['2nd'].length}, 3rd: ${grouped['3rd'].length}, 4th: ${grouped['4th'].length}`);
      }
    });
  });

  // ====================
  // 4. YEAR GROUPING TESTS
  // ====================
  describe('4️⃣ Year Grouping Test', () => {
    
    test('4.1 Group all students by year', async () => {
      const grouped = groupStudentsByYear(transformedStudents);
      
      assert.ok(grouped['2nd'], 'Should have 2nd year group');
      assert.ok(grouped['3rd'], 'Should have 3rd year group');
      assert.ok(grouped['4th'], 'Should have 4th year group');
      
      const total2nd = grouped['2nd'].length;
      const total3rd = grouped['3rd'].length;
      const total4th = grouped['4th'].length;
      
      console.log('✅ Year distribution:');
      console.log(`   2nd Year: ${total2nd} students`);
      console.log(`   3rd Year: ${total3rd} students`);
      console.log(`   4th Year: ${total4th} students`);
      
      if (total2nd > 0) {
        console.log(`   2nd Year Students: ${grouped['2nd'].map(s => s.name).join(', ')}`);
      }
      if (total3rd > 0) {
        console.log(`   3rd Year Students: ${grouped['3rd'].map(s => s.name).join(', ')}`);
      }
    });

    test('4.2 Verify each student has valid year format', async () => {
      transformedStudents.forEach(student => {
        assert.ok(['1st', '2nd', '3rd', '4th'].includes(student.year), 
          `Student ${student.name} should have valid year (got: ${student.year})`);
      });
      
      console.log('✅ All students have valid year format');
    });
  });

  // ====================
  // 5. SPECIFIC SCENARIOS TESTS
  // ====================
  describe('5️⃣ Specific Scenario Tests', () => {
    
    test('5.1 Python Programming should show only 2nd year students', async () => {
      const pythonLab = assignedLabs.find(lab => lab.name === 'Python Programming');
      
      if (pythonLab) {
        const filtered = filterStudentsByLab(transformedStudents, 'Python Programming');
        const grouped = groupStudentsByYear(filtered);
        
        assert.ok(grouped['2nd'].length > 0, 'Python Programming should have 2nd year students');
        assert.strictEqual(grouped['3rd'].length, 0, 'Python Programming should not have 3rd year students');
        
        console.log('✅ Python Programming correctly shows only 2nd year:', grouped['2nd'].length, 'students');
      }
    });

    test('5.2 Physics Lab should show only 3rd year students', async () => {
      const physicsLab = assignedLabs.find(lab => lab.name === 'Physics Lab');
      
      if (physicsLab) {
        const filtered = filterStudentsByLab(transformedStudents, 'Physics Lab');
        const grouped = groupStudentsByYear(filtered);
        
        assert.strictEqual(grouped['2nd'].length, 0, 'Physics Lab should not have 2nd year students');
        assert.ok(grouped['3rd'].length > 0, 'Physics Lab should have 3rd year students');
        
        console.log('✅ Physics Lab correctly shows only 3rd year:', grouped['3rd'].length, 'students');
      }
    });

    test('5.3 Verify students can be in multiple labs', async () => {
      const studentsInMultipleLabs = transformedStudents.filter(s => s.labs.length > 1);
      
      assert.ok(studentsInMultipleLabs.length > 0, 'Should have students in multiple labs');
      
      console.log('✅ Found', studentsInMultipleLabs.length, 'students in multiple labs:');
      studentsInMultipleLabs.forEach(student => {
        console.log(`   - ${student.name}: ${student.labs.join(', ')}`);
      });
    });

    test('5.4 Verify lab filter does not lose students', async () => {
      // Total unique students should equal sum of students across all years
      const grouped = groupStudentsByYear(transformedStudents);
      const totalFromGroups = grouped['2nd'].length + grouped['3rd'].length + grouped['4th'].length;
      
      assert.strictEqual(totalFromGroups, transformedStudents.length, 
        'Total from year groups should equal total unique students');
      
      console.log('✅ No students lost in grouping:', totalFromGroups, '=', transformedStudents.length);
    });
  });

  // ====================
  // 6. EXPECTED BEHAVIOR VALIDATION
  // ====================
  describe('6️⃣ Expected Behavior Validation', () => {
    
    test('6.1 Should have unique students enrolled in labs', async () => {
      assert.ok(transformedStudents.length > 0, 
        'Should have at least one unique student');
      
      // Verify that unique students count is less than or equal to total records
      assert.ok(transformedStudents.length <= allStudents.length, 
        'Unique students should be less than or equal to total student-lab records');
      
      console.log('✅ Confirmed:', transformedStudents.length, 'unique students from', allStudents.length, 'records');
    });

    test('6.2 Should have exactly 4 assigned labs', async () => {
      const expectedLabs = 4;
      assert.strictEqual(assignedLabs.length, expectedLabs, 
        `Should have exactly ${expectedLabs} assigned labs`);
      
      console.log('✅ Confirmed:', assignedLabs.length, 'assigned labs');
    });

    test('6.3 2nd year students should match lab enrollments', async () => {
      const grouped = groupStudentsByYear(transformedStudents);
      
      // Should have at least some 2nd year students (Python Programming and Workflow Test Lab are 2nd year)
      assert.ok(grouped['2nd'].length > 0, 
        'Should have at least one 2nd year student');
      
      console.log('✅ Confirmed:', grouped['2nd'].length, '2nd year students');
    });

    test('6.4 3rd year students should match lab enrollments', async () => {
      const grouped = groupStudentsByYear(transformedStudents);
      
      // Should have at least some 3rd year students (pet and Physics Lab are 3rd year)
      assert.ok(grouped['3rd'].length > 0, 
        'Should have at least one 3rd year student');
      
      console.log('✅ Confirmed:', grouped['3rd'].length, '3rd year students');
    });

    test('6.5 All expected lab names should exist', async () => {
      const expectedLabs = ['Python Programming', 'Workflow Test Lab', 'pet', 'Physics Lab'];
      const actualLabNames = assignedLabs.map(lab => lab.name);
      
      expectedLabs.forEach(expectedLab => {
        assert.ok(actualLabNames.includes(expectedLab), 
          `Should have lab: ${expectedLab}`);
      });
      
      console.log('✅ All expected labs present:', expectedLabs.join(', '));
    });
  });

  // ====================
  // 7. FRONTEND SIMULATION TEST
  // ====================
  describe('7️⃣ Frontend User Action Simulation', () => {
    
    test('7.1 Simulate user selecting different labs', async () => {
      const scenarios = [
        { filter: 'All', description: 'User selects "All Labs"' },
        { filter: 'Python Programming', description: 'User selects "Python Programming"' },
        { filter: 'Physics Lab', description: 'User selects "Physics Lab"' },
        { filter: 'pet', description: 'User selects "pet"' },
        { filter: 'Workflow Test Lab', description: 'User selects "Workflow Test Lab"' }
      ];
      
      console.log('✅ Simulating user actions:');
      
      for (const scenario of scenarios) {
        const filtered = filterStudentsByLab(transformedStudents, scenario.filter);
        const grouped = groupStudentsByYear(filtered);
        
        console.log(`\n   ${scenario.description}:`);
        console.log(`   → Shows ${filtered.length} students`);
        console.log(`   → 2nd Year: ${grouped['2nd'].length}, 3rd Year: ${grouped['3rd'].length}`);
        
        if (filtered.length > 0) {
          assert.ok(filtered.every(s => 
            scenario.filter === 'All' || s.labs.includes(scenario.filter)
          ), 'All filtered students should have the selected lab');
        }
      }
      
      console.log('\n✅ All user scenarios work correctly');
    });
  });

  // ====================
  // SUMMARY
  // ====================
  after(() => {
    console.log('\n' + '='.repeat(70));
    console.log('🎯 LAB FILTER FEATURE TEST SUMMARY');
    console.log('='.repeat(70));
    console.log(`Staff Account: ${STAFF_USERNAME}`);
    console.log(`Assigned Labs: ${assignedLabs.length}`);
    console.log(`Total Unique Students: ${transformedStudents.length}`);
    console.log(`Total Student-Lab Records: ${allStudents.length}`);
    console.log('');
    console.log('📊 Lab Breakdown:');
    assignedLabs.forEach(lab => {
      const filtered = filterStudentsByLab(transformedStudents, lab.name);
      console.log(`   - ${lab.name}: ${filtered.length} students`);
    });
    console.log('');
    console.log('📅 Year Distribution:');
    const grouped = groupStudentsByYear(transformedStudents);
    console.log(`   - 2nd Year: ${grouped['2nd'].length} students`);
    console.log(`   - 3rd Year: ${grouped['3rd'].length} students`);
    console.log(`   - 4th Year: ${grouped['4th'].length} students`);
    console.log('='.repeat(70));
    console.log('\n✅ All lab filter feature tests passed successfully!\n');
  });
});