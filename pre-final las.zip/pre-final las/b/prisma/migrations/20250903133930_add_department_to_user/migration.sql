-- AlterTable
ALTER TABLE `user` ADD COLUMN `department` VARCHAR(191) NULL;
