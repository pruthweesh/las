import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { prisma } from '../config/prisma.js';
import { signupHodSchema, loginSchema, changePasswordSchema } from '../utils/validators.js';

// ✅ FIXED: Include department and temporaryPassword in JWT token
function sign(user) {
  return jwt.sign(
    { 
      id: user.id, 
      role: user.role, 
      username: user.username, 
      name: user.name,
      department: user.department,
      temporaryPassword: user.temporaryPassword || false
    },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );
}

// ✅ Allow multiple HODs, each with a department
export async function signupHod(req, res) {
  try {
    const data = signupHodSchema.parse(req.body);

    const passwordHash = await bcrypt.hash(data.password, 10);
    const user = await prisma.user.create({
      data: {
        name: data.name,
        email: data.email,
        username: data.username,
        password: passwordHash,
        role: 'HOD',
        department: data.department
      }
    });

    res.status(201).json({
      user: { ...user, password: undefined },
      token: sign(user)
    });
  } catch (e) {
    if (e.code === 'P2002') {
      return res.status(400).json({ error: 'Username or email already exists' });
    }
    if (e.errors) {
      return res.status(400).json({ error: e.errors.map(x => x.message).join(', ') });
    }
    return res.status(500).json({ error: e.message });
  }
}

export async function login(req, res) {
  try {
    const data = loginSchema.parse(req.body);
    const user = await prisma.user.findUnique({ where: { username: data.username } });

    if (!user || user.role !== data.role) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const ok = await bcrypt.compare(data.password, user.password);
    if (!ok) return res.status(401).json({ error: 'Invalid credentials' });

    const token = sign(user);
    res.json({ 
      token, 
      user: { 
        ...user, 
        password: undefined,
        temporaryPassword: user.temporaryPassword || false
      } 
    });
  } catch (e) {
    if (e.errors) {
      return res.status(400).json({ error: e.errors.map(x => x.message).join(', ') });
    }
    return res.status(500).json({ error: e.message });
  }
}

export async function changeOwnPassword(req, res) {
  try {
    const data = changePasswordSchema.parse(req.body);
    const user = await prisma.user.findUnique({ where: { id: req.user.id } });

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const ok = await bcrypt.compare(data.currentPassword, user.password);
    if (!ok) return res.status(400).json({ error: 'Current password incorrect' });

    if (data.newPassword.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }

    const newHash = await bcrypt.hash(data.newPassword, 10);
    await prisma.user.update({
      where: { id: user.id },
      data: { 
        password: newHash,
        temporaryPassword: false
      }
    });

    res.json({ message: 'Password updated' });
  } catch (e) {
    if (e.errors) {
      return res.status(400).json({ error: e.errors.map(x => x.message).join(', ') });
    }
    return res.status(500).json({ error: e.message });
  }
}

// ✅ FIXED: Reset password endpoint with proper validation
export async function resetPassword(req, res) {
  try {
    const { newPassword } = req.body;
    
    if (!newPassword || typeof newPassword !== 'string') {
      return res.status(400).json({ error: 'Password is required' });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }

    if (newPassword.length > 100) {
      return res.status(400).json({ error: 'Password is too long (maximum 100 characters)' });
    }

    const userId = req.user.id;
    const newHash = await bcrypt.hash(newPassword, 10);
    
    await prisma.user.update({
      where: { id: userId },
      data: { 
        password: newHash, 
        temporaryPassword: false 
      }
    });
    
    res.json({ message: 'Password reset successfully' });
  } catch (e) {
    console.error('Reset password error:', e);
    return res.status(500).json({ error: e.message || 'Failed to reset password' });
  }
}