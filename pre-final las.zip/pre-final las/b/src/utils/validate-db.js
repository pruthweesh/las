// backend/src/utils/validate-db.js - Database Structure Validation
import 'dotenv/config';
import { prisma } from '../config/prisma.js';

async function validateDatabase() {
  console.log('🔍 Validating existing database structure...\n');
  
  try {
    // Test basic connection
    await prisma.$connect();
    console.log('✅ Database connection successful');
    
    // Check required tables exist
    const tables = await prisma.$queryRaw`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = DATABASE()
    `;
    
    const tableNames = tables.map(t => t.table_name || t.TABLE_NAME);
    const requiredTables = ['user', 'lab', 'stafflabassignment', 'studentlabassignment', 'attendance'];
    
    console.log('\n📊 Database Tables Found:');
    tableNames.forEach(table => console.log(`   - ${table}`));
    
    console.log('\n✅ Required Tables Check:');
    const missingTables = [];
    requiredTables.forEach(table => {
      const exists = tableNames.some(t => t.toLowerCase() === table.toLowerCase());
      if (exists) {
        console.log(`   ✅ ${table}`);
      } else {
        console.log(`   ❌ ${table} (MISSING)`);
        missingTables.push(table);
      }
    });
    
    if (missingTables.length > 0) {
      console.log('\n⚠️  Missing tables detected. Run: npm run prisma:migrate');
      return false;
    }
    
    // Check for staff users
    const staffCount = await prisma.user.count({
      where: { role: 'STAFF' }
    });
    
    console.log(`\n👨‍🏫 Staff Users Found: ${staffCount}`);
    
    if (staffCount === 0) {
      console.log('⚠️  No staff users found. You need at least one staff user to test the system.');
    }
    
    // Check for labs
    const labCount = await prisma.lab.count();
    console.log(`🔬 Labs Found: ${labCount}`);
    
    // Check for students  
    const studentCount = await prisma.user.count({
      where: { role: 'STUDENT' }
    });
    console.log(`👨‍🎓 Students Found: ${studentCount}`);
    
    // Check for attendance records
    const attendanceCount = await prisma.attendance.count();
    console.log(`📊 Attendance Records: ${attendanceCount}`);
    
    // Check staff-lab assignments
    const staffLabCount = await prisma.staffLabAssignment.count();
    console.log(`🔗 Staff-Lab Assignments: ${staffLabCount}`);
    
    if (staffLabCount === 0) {
      console.log('⚠️  No staff-lab assignments found. Staff won\'t have any labs assigned.');
    }
    
    console.log('\n🎉 Database validation complete!');
    
    if (staffCount > 0 && labCount > 0) {
      console.log('✅ Your database is ready for the staff page!');
      return true;
    } else {
      console.log('⚠️  Database needs staff users and labs to work properly.');
      return false;
    }
    
  } catch (error) {
    console.error('❌ Database validation failed:', error.message);
    return false;
  } finally {
    await prisma.$disconnect();
  }
}
// Add this to your validate-db.js after the staffLabCount check:
const studentLabCount = await prisma.studentLabAssignment.count();
console.log(`🔗 Student-Lab Assignments: ${studentLabCount}`);

if (studentLabCount === 0) {
  console.log('⚠️  No student-lab assignments found. This is why staff see no students!');
}
// Run validation if called directly
if (process.argv.includes('--validate')) {
  validateDatabase()
    .then(success => {
      process.exit(success ? 0 : 1);
    })
    .catch(error => {
      console.error('💥 Validation error:', error);
      process.exit(1);
    });
}

export default validateDatabase;