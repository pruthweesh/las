// routes/staff.js - Updated with lab-specific student endpoint
import { Router } from 'express';
import { auth, requireRole } from '../middleware/auth.js';
import { 
  getStaffDashboard,
  getStaffLabs,
  getStaffStudents,
  getStaffStudentsByLab,
  getStaffAttendance,
  markAttendance,
  bulkMarkAttendance,
  updateAttendance,
  deleteAttendance,
  getStaffStats
} from '../controllers/Staffcontroller.js';

const router = Router();

// Require authentication for all staff routes
router.use(auth(true));

// Require STAFF role for all routes
router.use(requireRole('STAFF'));

// Staff dashboard - get staff info and basic stats
router.get('/dashboard', getStaffDashboard);

// Staff statistics
router.get('/stats', getStaffStats);

// Staff labs - get assigned labs
router.get('/labs', getStaffLabs);

// Staff students - get students in assigned labs
router.get('/students', getStaffStudents); // All students or filtered by ?labId=X
router.get('/students/lab/:labId', getStaffStudentsByLab); // Students in specific lab (detailed)

// Staff attendance management
router.get('/attendance', getStaffAttendance); // All attendance or filtered by ?labId=X
router.post('/attendance', markAttendance); // Mark single attendance
router.post('/bulk-attendance', bulkMarkAttendance); // Mark multiple attendance
router.put('/attendance/:id', updateAttendance); // Update attendance record
router.delete('/attendance/:id', deleteAttendance); // Delete attendance record

export default router;