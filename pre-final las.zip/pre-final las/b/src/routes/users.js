import { Router } from 'express';
import { auth, requireRole } from '../middleware/auth.js';
import { createUser,getHodDashboard, listUsers, deleteUser, setUserPassword, assignStudentLabs, debugListAllUsers, assignUserDepartment, fixDepartmentAssignments, diagnosticDepartmentData } from '../controllers/userController.js';

const router = Router();

router.use(auth(true));
router.use(requireRole('HOD'));
router.get("/hod/dashboard", getHodDashboard);

router.post('/', createUser);                 // HOD creates STAFF or STUDENT with direct password (no temp)
router.get('/', listUsers);
router.delete('/:id', deleteUser);
router.patch('/:id/password', setUserPassword);
router.put('/students/:id/labs', assignStudentLabs);

// Department management routes
router.patch('/:id/department', assignUserDepartment);
router.post('/fix-departments', fixDepartmentAssignments);

// Debug endpoints
router.get('/debug/all', debugListAllUsers);
router.get('/debug/departments', diagnosticDepartmentData);

export default router;