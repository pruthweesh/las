// api-complete-fix.js - Enhanced API Utility with Full Debugging
const BASE = process.env.REACT_APP_API || 'http://localhost:4000';

function _headers(token) {
  return {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
}

async function _req(path, { method = 'GET', token, body } = {}) {
  const url = `${BASE}${path}`;
  
  console.log(`🌐 API Request: ${method} ${url}`);
  console.log(`🌐 BASE URL: ${BASE}`);
  if (body) console.log(`📤 Request body:`, body);
  if (token) console.log(`🔑 Token present: ${token.substring(0, 20)}...`);
  
  try {
    const res = await fetch(url, {
      method,
      headers: _headers(token),
      body: body ? JSON.stringify(body) : undefined,
      mode: 'cors',
      credentials: 'include'
    });
    
    console.log(`📡 Response status: ${res.status} ${res.statusText}`);
    
    let json;
    try {
      json = await res.json();
    } catch (jsonError) {
      console.error(`❌ JSON parsing failed:`, jsonError);
      json = { error: 'Invalid JSON response from server' };
    }
    
    if (!res.ok) {
      console.error(`❌ API Error Response:`, json);
      throw json;
    }
    
    console.log(`✅ API Success Response:`, json);
    return json;
    
  } catch (fetchError) {
    console.error(`❌ Network/Fetch Error:`, fetchError);
    console.error(`❌ Error name: ${fetchError.name}`);
    console.error(`❌ Error message: ${fetchError.message}`);
    
    // More specific error handling
    if (fetchError.name === 'TypeError' && fetchError.message.includes('Failed to fetch')) {
      throw { error: 'Cannot connect to backend server. Check if it is running on port 4000.' };
    }
    
    if (fetchError.message.includes('CORS')) {
      throw { error: 'CORS error - backend server CORS configuration issue.' };
    }
    
    if (fetchError.message.includes('NetworkError')) {
      throw { error: 'Network error. Check your internet connection and backend server.' };
    }
    
    // For debugging: throw the original error instead of masking it
    throw { 
      error: `Connection failed: ${fetchError.message}`,
      originalError: fetchError.message,
      errorType: fetchError.name
    };
  }
}

/* Authentication */
export function login(username, password, role) {
  console.log(`🔐 Attempting login: ${username} as ${role}`);
  return _req('/auth/login', { method: 'POST', body: { username, password, role } });
}

export function signupHOD(payload, token) {
  return _req('/auth/signup-hod', { method: 'POST', token, body: payload });
}

export function changePassword({ currentPassword, newPassword }, token) {
  return _req('/auth/change-password', { method: 'POST', token, body: { currentPassword, newPassword } });
}

export function resetPassword({ newPassword }, token) {
  return _req('/auth/reset-password', { method: 'POST', token, body: { newPassword } });
}

/* Users - Enhanced with debugging */
export function fetchUsers(token, query = {}) {
  console.log(`👥 Fetching users with query:`, query);
  const q = Object.keys(query).length ? `?${new URLSearchParams(query).toString()}` : '';
  return _req(`/users${q}`, { token });
}

export function createUser(payload, token) {
  console.log(`➕ Creating user:`, payload);
  return _req('/users', { method: 'POST', token, body: payload });
}

export function deleteUser(userId, token) {
  return _req(`/users/${encodeURIComponent(userId)}`, { method: 'DELETE', token });
}

export function setUserPassword(userId, newPassword, token) {
  return _req(`/users/${encodeURIComponent(userId)}/password`, { method: 'PATCH', token, body: { newPassword } });
}

export function assignStudentLabs(studentId, labs, token) {
  return _req(`/users/students/${encodeURIComponent(studentId)}/labs`, { method: 'PUT', token, body: { labs } });
}

/* Debug Functions */
export function debugGetAllUsers(token) {
  console.log(`🔍 DEBUG: Getting all users from database`);
  return _req('/users/debug/all', { token });
}

export function testBackendConnection() {
  console.log(`🏥 Testing backend health`);
  return _req('/health', {});
}

/* Labs & Subjects */
export function listLabs(token) {
  return _req('/labs', { token });
}

export function getYearSubjects(year, token) {
  return _req(`/labs/years/${encodeURIComponent(year)}`, { token });
}

export function setYearSubjects(year, subjects, token) {
  return _req(`/labs/years/${encodeURIComponent(year)}`, { method: 'PUT', token, body: { subjects } });
}

/* Attendance (General) */
export function submitAttendance(payload, token) {
  return _req('/attendance', { method: 'POST', token, body: payload });
}

export function fetchStudentAttendance(studentId, token) {
  return _req(`/attendance/student/${encodeURIComponent(studentId)}`, { token });
}

export function fetchSummary(token) {
  return _req('/attendance/summary', { token });
}

// Staff Endpoints (keeping existing ones)
export function getStaffDashboard(token) {
  return _req('/staff/dashboard', { token });
}

export function getStaffLabs(token) {
  return _req('/staff/labs', { token });
}

export function getStaffStudents(token, labId = null) {
  const endpoint = labId ? `/staff/students/${labId}` : '/staff/students';
  return _req(endpoint, { token });
}

export function getStaffAttendance(token, labId = null) {
  const endpoint = labId ? `/staff/attendance/${labId}` : '/staff/attendance';
  return _req(endpoint, { token });
}

export function markStaffAttendance(attendanceData, token) {
  return _req('/staff/attendance', { method: 'POST', token, body: attendanceData });
}

export function markBulkStaffAttendance(bulkData, token) {
  return _req('/staff/bulk-attendance', { method: 'POST', token, body: bulkData });
}

export function updateStaffAttendance(attendanceId, updateData, token) {
  return _req(`/staff/attendance/${attendanceId}`, { method: 'PUT', token, body: updateData });
}

export function deleteStaffAttendance(attendanceId, token) {
  return _req(`/staff/attendance/${attendanceId}`, { method: 'DELETE', token });
}

export function getStaffStats(token) {
  return _req('/staff/stats', { token });
}

// HOD Lab Management
export function createLab(labData, token) {
  return _req('/labs', { method: 'POST', token, body: labData });
}

export function assignStaffToLabs(staffId, labIds, token) {
  return _req('/labs/assign-staff', { method: 'POST', token, body: { staffId, labIds } });
}

export function assignStudentsToLab(labId, studentIds, token) {
  return _req('/labs/assign-students', { method: 'POST', token, body: { labId, studentIds } });
}
export function get(path, token) {
  return _req(path, { method: 'GET', token });
}
// Default export with all functions
export default {
  // Authentication
  login,
  signupHOD,
  changePassword,
  resetPassword,
  
  // Users
  fetchUsers,
  createUser,
  deleteUser,
  setUserPassword,
  assignStudentLabs,
  
  // Debug functions
  debugGetAllUsers,
  testBackendConnection,
  
  // Labs & Subjects
  listLabs,
  getYearSubjects,
  setYearSubjects,
  
  // General Attendance
  submitAttendance,
  fetchStudentAttendance,
  fetchSummary,
  
  // Staff Functions
  getStaffDashboard,
  getStaffLabs,
  getStaffStudents,
  getStaffAttendance,
  markStaffAttendance,
  markBulkStaffAttendance,
  updateStaffAttendance,
  deleteStaffAttendance,
  getStaffStats,
  
  // HOD Lab Management
  createLab,
  assignStaffToLabs,
  assignStudentsToLab,
  get,
};