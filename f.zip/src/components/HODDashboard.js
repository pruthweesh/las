// components/HODDashboard.js
import React, { useEffect, useState } from "react";

import { saveAuth, getToken, getUser, clearAuth } from '../utils/auth';
import api from '../utils/api';

import { 
  FaUser, FaSignOutAlt, FaFilter, FaPlus, FaKey, FaEye, FaDownload, 
  FaTrash, FaChevronRight, FaBell, FaUsers, FaChartPie, FaCog, FaCheck, FaTimes,
  FaBook, FaGraduationCap, FaEdit, FaSave, FaCheckCircle, FaExclamationTriangle
} from 'react-icons/fa';
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const HODDashboard = ({ 
  currentUser = { name: 'Dr. John Smith', email: 'john.smith@university.edu' },
  handleLogout = () => console.log('Logout'),
}) => {
  // State Management
  const [users, setUsers] = useState([]);
  const [yearFilter, setYearFilter] = useState('All');
  const [labFilter, setLabFilter] = useState('All Labs');
  const [openDropdowns, setOpenDropdowns] = useState({});
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [showAddModal, setShowAddModal] = useState(null);
  const [tempPassword, setTempPassword] = useState(null);
  const [activeSection, setActiveSection] = useState('overview');
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showChangePassword, setShowChangePassword] = useState(false);
  const [drilldownYear, setDrilldownYear] = useState(null);
  const [studentIdSearch, setStudentIdSearch] = useState('');
  const [showLabAssignModal, setShowLabAssignModal] = useState(null);
  const [selectedStaffLabs, setSelectedStaffLabs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [allLabs, setAllLabs] = useState([]);
  const [summary, setSummary] = useState({});
  const [yearSubjects, setYearSubjects] = useState({});
  
  // Lab Subject Management States
  const [selectedYear, setSelectedYear] = useState('2nd Year');
  const [labSubjects, setLabSubjects] = useState({
    '2nd Year': ['Physics Lab', 'Chemistry Lab'],
    '3rd Year': ['Electronics Lab', 'Computer Lab', 'Circuit Analysis Lab'],
    '4th Year': ['Project Lab', 'Advanced Electronics Lab', 'Research Lab']
  });
  const [newSubject, setNewSubject] = useState('');
  const [editingSubject, setEditingSubject] = useState(null);
  const [editingValue, setEditingValue] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [notification, setNotification] = useState({ type: '', message: '' });
  const [notifications, setNotifications] = useState([]);
  const [students, setStudents] = useState([]);
  const [attendance, setAttendance] = useState([]);
  const [staff, setStaff] = useState([]);
  // ADD these state variables
const [showAddLabModal, setShowAddLabModal] = useState(false);

  // Helper function to normalize year format
  const normalizeYear = (year) => {
    if (!year) return null;
    const yearStr = year.toString().toLowerCase().trim();
    if (yearStr === '2' || yearStr === '2nd' || yearStr === 'second' || yearStr === '2nd year') return '2nd Year';
    if (yearStr === '3' || yearStr === '3rd' || yearStr === 'third' || yearStr === '3rd year') return '3rd Year';
    if (yearStr === '4' || yearStr === '4th' || yearStr === 'fourth' || yearStr === '4th year') return '4th Year';
    return year;
  };

  // Load all users from backend
 // FIXED loadAllUsers
// ENHANCED loadAllUsers function - Replace in /frontend/src/components/HODDashboard.js (lines 70-104)

const loadAllUsers = async () => {
  try {
    console.log("\n🟦 ===== FRONTEND DEBUG SESSION =====");
    console.log("🟦 Step 1: Starting loadAllUsers");
    
    setLoading(true);
    setError(null);
    const token = getToken();

    console.log("🟦 Step 2: Token check");
    console.log("  - Token exists:", !!token);
    console.log("  - Token preview:", token ? token.substring(0, 20) + "..." : "No token");

    console.log("🟦 Step 3: Making API call to /users/hod/dashboard");
    const res = await api.get("/users/hod/dashboard", token);
    
    console.log("🟦 Step 4: RAW API Response received:");
    console.log("  - Type:", typeof res);
    console.log("  - Keys:", Object.keys(res || {}));
    console.log("  - Full response:", res);
    
    // Extract the actual data
    console.log("\n🟦 Step 5: Extracting data from response");
    console.log("  - res.studentsCount:", res.studentsCount, "(type:", typeof res.studentsCount, ")");
    console.log("  - res.staffCount:", res.staffCount, "(type:", typeof res.staffCount, ")");
    console.log("  - res.students:", res.students ? `Array of ${res.students.length}` : "undefined/null");
    console.log("  - res.staff:", res.staff ? `Array of ${res.staff.length}` : "undefined/null");
    console.log("  - res.avgAttendance:", res.avgAttendance);
    console.log("  - res.totalRecords:", res.totalRecords);
    
    // Check debug info if available
    if (res.debug) {
      console.log("\n🟦 Step 6: DEBUG INFO from backend:");
      console.log("  - Total users in DB:", res.debug.totalUsersInDB);
      console.log("  - HOD department:", res.debug.hodDepartment);
      console.log("  - Students found by query:", res.debug.queryResults?.studentsFound);
      console.log("  - Staff found by query:", res.debug.queryResults?.staffFound);
      
      if (res.debug.allUsers) {
        console.log("  - All users from DB:");
        res.debug.allUsers.forEach((user, i) => {
          console.log(`    ${i+1}. ${user.name} (${user.role}) - Dept: "${user.department}" - Year: "${user.year}"`);
        });
      }
    }
    
    // Process the arrays
    const studentsList = res.students || [];
    const staffList = res.staff || [];
    
    console.log("\n🟦 Step 7: Processing arrays");
    console.log("  - studentsList length:", studentsList.length);
    console.log("  - staffList length:", staffList.length);
    
    if (studentsList.length > 0) {
      console.log("  - Sample students:");
      studentsList.slice(0, 3).forEach((s, i) => {
        console.log(`    ${i+1}. ${s.name} (${s.year}) - Role: ${s.role}`);
      });
    } else {
      console.log("  - ⚠️ Students array is EMPTY");
    }
    
    if (staffList.length > 0) {
      console.log("  - Sample staff:");
      staffList.slice(0, 3).forEach((s, i) => {
        console.log(`    ${i+1}. ${s.name} - Role: ${s.role}`);
      });
    } else {
      console.log("  - ⚠️ Staff array is EMPTY");
    }
    
    // Calculate final counts
    const studentsCount = res.studentsCount ?? studentsList.length;
    const staffCount = res.staffCount ?? staffList.length;
    
    console.log("\n🟦 Step 8: Final count calculation");
    console.log("  - API studentsCount:", res.studentsCount);
    console.log("  - Array length:", studentsList.length);
    console.log("  - Final studentsCount:", studentsCount);
    console.log("  - API staffCount:", res.staffCount);
    console.log("  - Array length:", staffList.length);
    console.log("  - Final staffCount:", staffCount);

    // Update component states
    console.log("\n🟦 Step 9: Updating component states");
    const allUsers = [...studentsList, ...staffList];
    console.log("  - Combined users array:", allUsers.length);
    console.log("  - Setting users state with:", allUsers.length, "items");
    console.log("  - Setting students state with:", studentsList.length, "items");
    console.log("  - Setting staff state with:", staffList.length, "items");
    
    setUsers(allUsers);
    setStudents(studentsList);
    setStaff(staffList);

    // Update summary
    const newSummary = {
      studentsCount: studentsCount,
      staffCount: staffCount,
      avgAttendance: res.avgAttendance ?? 0,
      totalRecords: res.totalRecords ?? 0,
      totalLabAssignments: res.totalLabAssignments ?? staffList.reduce((sum, s) => sum + (s.assignedLabs?.length || 0), 0) ?? 0,
    };
    
    console.log("🟦 Step 10: Setting summary state:");
    console.log("  - Summary object:", newSummary);
    console.log("  - Lab assignments count:", newSummary.totalLabAssignments);
    setSummary(newSummary);
    
    // Verify what will be displayed
    console.log("\n🟦 Step 11: VERIFY UI WILL SHOW:");
    console.log("  - users.filter(u => u.role === 'student').length =", allUsers.filter(u => u.role === 'student').length);
    console.log("  - users.filter(u => u.role === 'STUDENT').length =", allUsers.filter(u => u.role === 'STUDENT').length);
    console.log("  - users.filter(u => (u.role || '').toLowerCase() === 'staff').length =", allUsers.filter(u => (u.role || '').toLowerCase() === 'staff').length);
    
    console.log("🟦 ===== FRONTEND DEBUG COMPLETE =====\n");

    // Show success/warning
    if (studentsCount > 0 || staffCount > 0) {
      console.log(`✅ Successfully loaded ${studentsCount} students and ${staffCount} staff`);
    } else {
      console.log("⚠️ No students or staff loaded - check logs above");
    }

  } catch (err) {
    console.error("\n❌ ===== FRONTEND ERROR =====");
    console.error("❌ Error type:", err.constructor.name);
    console.error("❌ Error message:", err.message || err.error || "Unknown error");
    console.error("❌ Full error:", err);
    console.error("❌ Stack trace:", err.stack);
    console.error("❌ ========================\n");
    
    setError(err?.message || err?.error || "Failed to load users");
    setSummary({
      studentsCount: 0,
      staffCount: 0,
      avgAttendance: 0,
      totalRecords: 0,
      totalLabAssignments: 0,
    });
  } finally {
    setLoading(false);
  }
};



// Load all labs separately
const loadAllLabs = async () => {
  try {
    const token = getToken();
    console.log("Loading all labs...");

    const labs = await api.listLabs(token);
    console.log("Labs loaded:", labs);

    setAllLabs(labs || []);
  } catch (error) {
    console.error("Error loading labs:", error);
    showNotification("error", "Failed to load labs");
  }
};

const yearOrder = ["2nd Year", "3rd Year", "4th Year"];
const uniqueYears = yearOrder;

// useEffect now reuses loadAllUsers instead of duplicating logic
useEffect(() => {
  (async () => {
    const token = getToken();
    try {
      setLoading(true);

      // 1. Load labs
      await loadAllLabs();

      // 2. Load users (students & staff) + summary
      await loadAllUsers();

      // 3. Load year subjects
      const subjMap = {};
      await Promise.all(uniqueYears.map(async year => {
        try {
          const out = await api.getYearSubjects(year, token);
          subjMap[year] = out.subjects || out || [];
        } catch (e) {
          subjMap[year] = labSubjects[year] || [];
        }
      }));
      setYearSubjects(subjMap);

    } catch (err) {
      setError(err?.error || err?.message || "Failed to load data");
    } finally {
      setLoading(false);
    }
  })();
}, []);


// ADD this function to sync lab subjects with database
const syncLabSubjectsWithDB = async () => {
  try {
    const token = getToken();
    
    // Get all unique lab subjects from all years
    const allSubjects = [];
    Object.keys(labSubjects).forEach(year => {
      if (labSubjects[year]) {
        labSubjects[year].forEach(subject => {
          if (!allSubjects.find(s => s.name === subject)) {
            allSubjects.push({ name: subject, year });
          }
        });
      }
    });
    
    // Create labs in database if they don't exist
    for (const subject of allSubjects) {
      try {
        await api.createLab({
          name: subject.name,
          year: subject.year
        }, token);
        console.log(`Created lab: ${subject.name} for ${subject.year}`);
      } catch (error) {
        // Lab might already exist, ignore error
        if (!error.error?.includes('already exists')) {
          console.warn(`Failed to create lab ${subject.name}:`, error);
        }
      }
    }
    
    // Reload labs after sync
    await loadAllLabs();
    
  } catch (error) {
    console.error('Error syncing lab subjects:', error);
  }
};
// REPLACE with this enhanced version that includes all lab subjects
const labNames = React.useMemo(() => {
  // Get labs from database
  const dbLabs = allLabs?.map(l => (typeof l === "string" ? l : l.name)).filter(Boolean) || [];
  
  // Get all lab subjects from Lab Subject Management for all years
  const subjectLabs = [];
  Object.keys(labSubjects).forEach(year => {
    if (labSubjects[year] && Array.isArray(labSubjects[year])) {
      labSubjects[year].forEach(subject => {
        if (!subjectLabs.includes(subject)) {
          subjectLabs.push(subject);
        }
      });
    }
  });
  
  // Combine and remove duplicates
  const allLabNames = [...new Set([...dbLabs, ...subjectLabs])];
  console.log("Available lab names:", allLabNames);
  
  return allLabNames;
}, [allLabs, labSubjects]);

  // Helper Functions
  const toggleDropdown = (key) => {
    setOpenDropdowns(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  const getAttendanceColor = (percentage) => {
    if (percentage >= 85) return 'row-good';
    if (percentage >= 75) return 'row-mid';
    return 'row-low';
  };

  const exportCSV = (data, filename) => {
    if (!data || data.length === 0) {
      alert('No data to export');
      return;
    }
    
    const csvContent = "data:text/csv;charset=utf-8," 
      + Object.keys(data[0]).join(",") + "\n"
      + data.map(row => Object.values(row).join(",")).join("\n");
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Lab Subject Management Functions
  const showNotification = (type, message) => {
    setNotification({ type, message });
    setTimeout(() => setNotification({ type: '', message: '' }), 3000);
  };

  const updateStudentLabAssignments = (year, subjects) => {
    const updatedUsers = users.map(user => {
      if (user.role === 'student' && user.year === year) {
        return {
          ...user,
          labs: subjects
        };
      }
      return user;
    });
    setUsers(updatedUsers);
  };

  const handleAddSubject = () => {
    if (!newSubject.trim()) {
      showNotification('error', 'Subject name cannot be empty');
      return;
    }

    if (labSubjects[selectedYear].includes(newSubject.trim())) {
      showNotification('error', 'Subject already exists for this year');
      return;
    }

    const updatedSubjects = {
      ...labSubjects,
      [selectedYear]: [...labSubjects[selectedYear], newSubject.trim()]
    };
    
    setLabSubjects(updatedSubjects);
    updateStudentLabAssignments(selectedYear, updatedSubjects[selectedYear]);
    setNewSubject('');
    setShowAddForm(false);
    showNotification('success', `"${newSubject.trim()}" added to ${selectedYear} successfully`);
  };

  const handleRemoveSubject = (subjectToRemove) => {
    if (window.confirm(`Are you sure you want to remove "${subjectToRemove}" from ${selectedYear}? This will affect all ${selectedYear} students.`)) {
      const updatedSubjects = {
        ...labSubjects,
        [selectedYear]: labSubjects[selectedYear].filter(subject => subject !== subjectToRemove)
      };
      
      setLabSubjects(updatedSubjects);
      updateStudentLabAssignments(selectedYear, updatedSubjects[selectedYear]);
      showNotification('success', `"${subjectToRemove}" removed from ${selectedYear} successfully`);
    }
  };

  const handleEditSubject = (subject) => {
    setEditingSubject(subject);
    setEditingValue(subject);
  };

  const handleSaveEdit = () => {
    if (!editingValue.trim()) {
      showNotification('error', 'Subject name cannot be empty');
      return;
    }

    if (editingValue.trim() !== editingSubject && labSubjects[selectedYear].includes(editingValue.trim())) {
      showNotification('error', 'Subject already exists for this year');
      return;
    }

    const updatedSubjects = {
      ...labSubjects,
      [selectedYear]: labSubjects[selectedYear].map(subject => 
        subject === editingSubject ? editingValue.trim() : subject
      )
    };
    
    setLabSubjects(updatedSubjects);
    updateStudentLabAssignments(selectedYear, updatedSubjects[selectedYear]);
    setEditingSubject(null);
    setEditingValue('');
    showNotification('success', `Subject updated to "${editingValue.trim()}" successfully`);
  };

  const handleCancelEdit = () => {
    setEditingSubject(null);
    setEditingValue('');
  };

  const handleCancelAdd = () => {
    setShowAddForm(false);
    setNewSubject('');
  };

  const getStudentCount = (year) => {
    return users.filter(user => {
      // Handle case sensitivity - database stores 'STUDENT' but we might check for 'student'
      const userRole = (user.role || '').toLowerCase();
      const isStudent = userRole === 'student';
      
      // Handle different year formats: '4th Year' vs '4' vs 4
      const userYear = user.year;
      let matchesYear = false;
      
      if (year === '2nd Year') {
        matchesYear = userYear === '2nd Year' || userYear === '2nd' || userYear === '2' || userYear === 2;
      } else if (year === '3rd Year') {
        matchesYear = userYear === '3rd Year' || userYear === '3rd' || userYear === '3' || userYear === 3;
      } else if (year === '4th Year') {
        matchesYear = userYear === '4th Year' || userYear === '4th' || userYear === '4' || userYear === 4;
      } else {
        matchesYear = userYear === year;
      }
      
      return isStudent && matchesYear;
    }).length;
  };

  const applySubjectsToStudents = () => {
    if (window.confirm(`Apply current subject list to all ${selectedYear} students? This will override their existing lab assignments.`)) {
      updateStudentLabAssignments(selectedYear, labSubjects[selectedYear]);
      showNotification('success', `Lab subjects applied to all ${selectedYear} students successfully`);
    }
  };

  // Data Processing
  const filteredStudents = users.filter(u => {
    // Handle case sensitivity for role
    const userRole = (u.role || '').toLowerCase();
    if (userRole !== 'student') return false;
    
    if (yearFilter !== 'All' && u.year !== yearFilter) return false;
    if (labFilter !== 'All Labs') {
      const hasLab = attendance.some(a => a.studentId === u.studentId && a.lab === labFilter);
      if (!hasLab) return false;
    }
    if (studentIdSearch && !String(u.studentId || '').toLowerCase().includes(studentIdSearch.toLowerCase())) return false;
    return true;
  });

  const filteredStaff = users.filter(u => (u.role || '').toLowerCase() === 'staff');

  const studentsByYear = yearOrder.reduce((acc, year) => {
    acc[year] = filteredStudents.filter(s => {
      const studentYear = s.year;
      
      // Direct match first
      if (studentYear === year) return true;
      
      // Flexible matching for different year formats
      if (year === '2nd Year' && (studentYear === '2' || studentYear === 2 || studentYear === '2nd' || studentYear === 'second')) return true;
      if (year === '3rd Year' && (studentYear === '3' || studentYear === 3 || studentYear === '3rd' || studentYear === 'third')) return true;
      if (year === '4th Year' && (studentYear === '4' || studentYear === 4 || studentYear === '4th' || studentYear === 'fourth')) return true;
      
      return false;
    });
    return acc;
  }, {});

  // Group staff by department
  const staffByDept = staff.reduce((acc, s) => {
    const deptKey = s.department || "Unassigned Dept";
    if (!acc[deptKey]) acc[deptKey] = [];
    acc[deptKey].push(s);
    return acc;
  }, {});

  // Calculate statistics
  const totalStudents = filteredStudents.length;
  const totalStaff = filteredStaff.length;
  const avgAttendance = attendance.length > 0 
    ? Math.round(attendance.reduce((sum, a) => sum + a.percentage, 0) / attendance.length)
    : 0;

  // Pie chart data
  const pieData = yearOrder.map(year => {
    const yearStudents = studentsByYear[year] || [];
    const yearAttendance = yearStudents.length > 0
      ? yearStudents.reduce((sum, student) => {
          const studentAttendance = attendance.filter(a => a.studentId === student.studentId);
          const avgAtt = studentAttendance.length > 0
            ? studentAttendance.reduce((s, a) => s + a.percentage, 0) / studentAttendance.length
            : 0;
          return sum + avgAtt;
        }, 0) / yearStudents.length
      : 0;
    
    return {
      name: year,
      value: Math.round(yearAttendance) || 0,
      students: yearStudents.length
    };
  }).filter(item => item.students > 0);

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

  // Backend functions
  async function createUser(e, role) {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const payload = Object.fromEntries(form.entries());
    const base = {
      name: payload.name,
      email: payload.email,
      username: payload.username,
      password: payload.password,
      role: role.toUpperCase()
    };
    if (role.toUpperCase() === 'STUDENT') {
      base.year = normalizeYear(payload.year);
      base.studentId = payload.studentId;
      base.labs = (payload.labs || '').split(',').map(s => s.trim()).filter(Boolean);
    }
    if (role.toUpperCase() === 'STAFF') {
      base.assignedLabs = (payload.assignedLabs || '').split(',').map(s => s.trim()).filter(Boolean);
      base.department = currentUser?.department || base.department;
    }
    
    try {
      const out = await api.createUser(base, getToken());
      await loadAllUsers();
      e.currentTarget.reset();
      alert('User created');
    } catch (err) {
      alert(err?.error || err?.message || 'Failed to create user');
    }
  }

  const createUserBackend = async (userData) => {
    try {
      const res = await api.createUser(userData, getToken());
      await loadAllUsers();
      return res;
    } catch (err) {
      console.error('createUserBackend error', err);
      throw err;
    }
  };

  async function removeUser(id) {
    if (!window.confirm('Delete this user?')) return;
    try {
      await api.deleteUser(id, getToken());
      await loadAllUsers();
    } catch (e) {
      alert(e?.error || 'Failed to delete');
      throw e;
    }
  }

  async function setPassword(id) {
    const pwd = prompt('New password for user? (min 6 chars)');
    if (!pwd) return;
    try {
      await api.setUserPassword(id, pwd, getToken());
      alert('Password updated');
    } catch (e) { alert(e?.error || 'Failed to set password'); }
  }

  const handleGenerateTempPassword = async (userId) => {
    const password = 'temp' + Math.random().toString(36).substr(2, 6);
    try {
      await api.setUserPassword(userId, password, getToken());
      setTempPassword(password);
      showNotification('success', 'Temporary password set for user');
    } catch (err) {
      showNotification('error', err?.error || 'Failed to set temporary password');
    }
  };
  
  async function assignStudentLabs(user) {
    const val = prompt('Comma-separated labs for student', (user.labs || []).join(', '));
    if (val == null) return;
    const labs = val.split(',').map(s => s.trim()).filter(Boolean);
    try {
      await api.assignStudentLabs(user.id || user.studentId, labs, getToken());
      setUsers(prev => prev.map(u => (u.id === user.id ? { ...u, labs } : u)));
    } catch(e) { alert(e?.error || 'Failed to assign labs'); }
  }

  async function saveSubjects(year) {
    const list = (yearSubjects[year] || []).map(s => s.trim()).filter(Boolean);
    try {
      await api.setYearSubjects(year, list, getToken());
      alert('Saved');
    } catch (e) { alert(e?.error || 'Failed to save'); }
  }

  const handleViewAttendance = (student) => {
    setSelectedStudent(student);
  };

  const handleAddUser = (password) => {
    setTempPassword(password);
  };

  const handleChangePassword = (newPassword) => {
    if (!currentUser || !newPassword) return;
    setUsers(users.map(u => u.id === currentUser.id ? { ...u, password: newPassword, temporaryPassword: false } : u));
    setShowChangePassword(false);
    alert('Password updated successfully.');
  };

  const handleAssignLabs = (staff) => {
    setShowLabAssignModal(staff);
    setSelectedStaffLabs(staff.assignedLabs || []);
  };

  const handleLabToggle = (labName) => {
    setSelectedStaffLabs(prev => {
      if (prev.includes(labName)) {
        return prev.filter(lab => lab !== labName);
      } else {
        return [...prev, labName];
      }
    });
  };

 // REPLACE the existing handleSaveLabAssignment function
const handleSaveLabAssignment = async () => {
  if (!showLabAssignModal) return;
  
  setLoading(true);
  try {
    const token = getToken();
    
    // Get lab IDs from selected lab names
    const labIds = allLabs
      .filter(lab => selectedStaffLabs.includes(lab.name))
      .map(lab => lab.id);
    
    console.log(`ðŸ”§ Assigning staff ${showLabAssignModal.id} to labs:`, {
      staffId: showLabAssignModal.id,
      labIds: labIds,
      labNames: selectedStaffLabs
    });
    
    // Call API to assign labs
    await api.assignStaffToLabs(showLabAssignModal.id, labIds, token);
    
    // CRITICAL FIX: Reload both users and labs data
    await Promise.all([
      loadAllUsers(),
      loadAllLabs()
    ]);
    
    showNotification('success', `Lab assignments updated successfully for ${showLabAssignModal.name}`);
    
    // Close modal and reset state
    setShowLabAssignModal(null);
    setSelectedStaffLabs([]);
    
  } catch (error) {
    console.error('âŒ Lab assignment error:', error);
    showNotification('error', error.error || 'Failed to assign labs');
  } finally {
    setLoading(false);
  }
};

  // Modal Components
  const AddUserModal = ({ type, onClose, onAdd }) => {
    const [formData, setFormData] = useState({
      name: '', email: '', year: '2nd Year', studentId: '', assignedLabs: []
    });
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleSubmit = async () => {
      if (!formData.name || !formData.email) {
        alert('Please fill in all required fields');
        return;
      }

      setIsSubmitting(true);

      const userData = {
        ...formData,
        username: formData.username || (formData.email ? formData.email.split('@')[0] : `user${Date.now()}`),
        password: formData.password || ('temp' + Math.random().toString(36).substr(2,6)),
        role: type === 'student' ? 'STUDENT' : 'STAFF',
        studentId: type === 'student' ? (formData.studentId || `STU${Date.now()}`) : undefined,
        year: type === 'student' ? normalizeYear(formData.year) : undefined,
        labs: type === 'student' ? formData.labs || [] : undefined,
        assignedLabs: type === 'staff' ? formData.assignedLabs || [] : undefined,
        department: type === 'staff' ? (currentUser?.department || formData.department) : undefined
      };

      try {
        await createUserBackend(userData);
        setFormData({ name: '', email: '', year: '2nd Year', studentId: '', assignedLabs: [] });
        await new Promise(resolve => setTimeout(resolve, 500));
        await loadAllUsers(); 
        onAdd(userData.password);
        onClose();
        showNotification('success', `${userData.name} added successfully`);
      } catch (err) {
        const msg = err?.error || err?.message || 'Create user failed';
        alert(msg);
      } finally {
        setIsSubmitting(false);
      }
    };

    return (
      <div className="modal-overlay">
        <div className="modal">
          <h2 className="modal-header">Add New {type === 'student' ? 'Student' : 'Staff'}</h2>
          <div>
            <div className="form-group">
              <label className="form-label">Full Name</label>
              <input
                type="text"
                className="form-input"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                placeholder="Enter full name"
              />
            </div>
            
            <div className="form-group">
              <label className="form-label">Email</label>
              <input
                type="email"
                className="form-input"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                placeholder="Enter email address"
              />
            </div>
            
            {type === 'student' && (
              <>
                <div className="form-group">
                  <label className="form-label">Student ID (Optional)</label>
                  <input
                    type="text"
                    className="form-input"
                    value={formData.studentId}
                    onChange={(e) => setFormData({...formData, studentId: e.target.value})}
                    placeholder="Auto-generated if empty"
                  />
                </div>
                
                <div className="form-group">
                  <label className="form-label">Year</label>
                  <select
                    className="form-input"
                    value={formData.year}
                    onChange={(e) => setFormData({...formData, year: e.target.value})}
                    required
                  >
                    {yearOrder.map(year => (
                      <option key={year} value={year}>{year}</option>
                    ))}
                  </select>
                </div>
              </>
            )}
            
            {type === 'staff' && (
              <div className="form-group">
                <label className="form-label">Assigned Labs (Optional)</label>
                <select
                  multiple
                  className="form-input"
                  style={{ height: '120px' }}
                  value={formData.assignedLabs}
                  onChange={(e) => {
                    const selected = Array.from(e.target.selectedOptions, option => option.value);
                    setFormData({...formData, assignedLabs: selected});
                  }}
                >
                  {labNames.map(lab => (
                    <option key={lab} value={lab}>{lab}</option>
                  ))}
                </select>
                <small style={{ fontSize: '12px', color: '#666' }}>
                  Hold Ctrl/Cmd to select multiple labs. You can assign labs later.
                </small>
              </div>
            )}
            
            <div className="modal-actions">
              <button className="btn btn-secondary" onClick={onClose} disabled={isSubmitting}>
                Cancel
              </button>
              <button onClick={handleSubmit} className="btn btn-primary" disabled={isSubmitting}>
                {isSubmitting ? 'Creating...' : `Add ${type === 'student' ? 'Student' : 'Staff'}`}
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const TempPasswordModal = ({ password, onClose }) => (
    <div className="modal-overlay">
      <div className="modal">
        <div className="temp-password-display">
          <h2 className="modal-header">Temporary Password Generated</h2>
          <p>The user has been created successfully. Please share this temporary password:</p>
          
          <div className="temp-password-box">
            <div className="temp-password-value">{password}</div>
          </div>
          
          <div className="temp-password-note">
            <strong>Important:</strong> The user must login with this password and will be prompted to set a new password on their first login.
          </div>
          
          <div className="modal-actions">
            <button className="btn btn-primary" onClick={onClose}>
              Got it!
            </button>
          </div>
        </div>
      </div>
    </div>
  );
// ADD this NEW component before LabAssignmentModal
const AddLabModal = ({ onClose, onLabAdded }) => {
  const [labName, setLabName] = useState('');
  const [labYear, setLabYear] = useState('2nd Year');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleCreateLab = async (e) => {
    e.preventDefault();
    if (!labName.trim()) return;

    setIsSubmitting(true);
    try {
      const token = getToken();
      const newLab = await api.createLab({
        name: labName.trim(),
        year: labYear
      }, token);

      // Refresh labs data
      await loadAllLabs();
      
      showNotification('success', `Lab "${labName}" created successfully!`);
      onLabAdded(newLab);
      onClose();
    } catch (error) {
      console.error('Create lab error:', error);
      showNotification('error', error.error || 'Failed to create lab');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="modal-overlay">
      <div className="modal" style={{ maxWidth: '400px' }}>
        <div className="modal-content">
          <h2 className="modal-header">
            <FaPlus style={{ marginRight: '10px' }} />
            Add New Lab Subject
          </h2>
          
          <form onSubmit={handleCreateLab}>
            <div style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold' }}>
                Lab Name
              </label>
              <input
                type="text"
                value={labName}
                onChange={(e) => setLabName(e.target.value)}
                placeholder="Enter lab name (e.g., Chemistry Lab)"
                style={{
                  width: '100%',
                  padding: '10px',
                  border: '1px solid #ddd',
                  borderRadius: '4px',
                  fontSize: '14px'
                }}
                required
              />
            </div>

            <div style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold' }}>
                Year
              </label>
              <select
                value={labYear}
                onChange={(e) => setLabYear(e.target.value)}
                style={{
                  width: '100%',
                  padding: '10px',
                  border: '1px solid #ddd',
                  borderRadius: '4px',
                  fontSize: '14px'
                }}
              >
                <option value="2nd Year">2nd Year</option>
                <option value="3rd Year">3rd Year</option>
                <option value="4th Year">4th Year</option>
              </select>
            </div>

            <div className="modal-actions">
              <button
                type="button"
                className="btn btn-secondary"
                onClick={onClose}
                disabled={isSubmitting}
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn btn-primary"
                disabled={isSubmitting || !labName.trim()}
              >
                {isSubmitting ? 'Creating...' : 'Create Lab'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};


// REPLACE the existing LabAssignmentModal component
const LabAssignmentModal = ({ staff, onClose }) => (
  <div className="modal-overlay">
    <div className="modal" style={{ maxWidth: '500px' }}>
      <div className="lab-assignment-modal">
        <h2 className="modal-header">Assign Labs to {staff.name}</h2>
        <p style={{ color: '#666', marginBottom: '20px' }}>
          Select the lab subjects that {staff.name} will be responsible for managing.
        </p>

        {/* NEW: Add New Lab Button */}
        <div style={{ marginBottom: '15px', textAlign: 'right' }}>
          <button 
            className="btn btn-success"
            onClick={() => setShowAddLabModal(true)}
            style={{ 
              fontSize: '12px', 
              padding: '6px 12px',
              background: '#16a34a',
              border: 'none',
              color: 'white',
              borderRadius: '4px',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              marginLeft: 'auto'
            }}
          >
            <FaPlus style={{ fontSize: '10px' }} />
            Add New Lab
          </button>
        </div>
        
        {/* ENHANCED: Scrollable Lab Selection */}
        <div style={{
          maxHeight: '300px',
          overflowY: 'auto',
          border: '1px solid #ddd',
          borderRadius: '6px',
          padding: '10px',
          marginBottom: '20px'
        }}>
          <div className="lab-selection-grid">
            {labNames.length > 0 ? labNames.map(lab => (
              <div key={lab} className="lab-selection-item" style={{ marginBottom: '8px' }}>
                <label className="lab-checkbox" style={{
                  display: 'flex',
                  alignItems: 'center',
                  cursor: 'pointer',
                  padding: '8px',
                  border: '1px solid #e5e7eb',
                  borderRadius: '4px',
                  transition: 'background 0.15s ease'
                }}>
                  <input
                    type="checkbox"
                    checked={selectedStaffLabs.includes(lab)}
                    onChange={() => handleLabToggle(lab)}
                    style={{ marginRight: '10px' }}
                  />
                  <span className="checkmark">
                    {selectedStaffLabs.includes(lab) ? <FaCheck style={{ color: '#16a34a' }} /> : ''}
                  </span>
                  <span className="lab-name" style={{ marginLeft: '8px' }}>{lab}</span>
                </label>
              </div>
            )) : (
              <div style={{ padding: '20px', textAlign: 'center', color: '#666' }}>
                <FaBook size={32} style={{ opacity: 0.3, marginBottom: '10px' }} />
                <p>No labs available. Create a new lab to get started.</p>
                <button 
                  className="btn btn-primary"
                  onClick={() => setShowAddLabModal(true)}
                  style={{ marginTop: '10px' }}
                >
                  <FaPlus /> Create New Lab
                </button>
              </div>
            )}
          </div>
        </div>
        
        <div className="assignment-summary" style={{
          background: '#f8f9fa',
          padding: '15px',
          borderRadius: '4px',
          marginBottom: '20px'
        }}>
          <h4>Assignment Summary:</h4>
          <p>
            <strong>{selectedStaffLabs.length}</strong> lab{selectedStaffLabs.length !== 1 ? 's' : ''} selected
            {selectedStaffLabs.length > 0 && (
              <span style={{ color: '#16a34a', marginLeft: '10px' }}>
                âœ“ {selectedStaffLabs.join(', ')}
              </span>
            )}
          </p>
          <div style={{ fontSize: '12px', color: '#666', marginTop: '8px' }}>
            The lab count will be updated immediately after assignment.
          </div>
        </div>
        
        <div className="modal-actions">
          <button className="btn btn-secondary" onClick={onClose} disabled={loading}>
            Cancel
          </button>
          <button 
            className="btn btn-primary" 
            onClick={handleSaveLabAssignment}
            disabled={loading || selectedStaffLabs.length === 0}
          >
            {loading ? 'Saving...' : `Save Assignment (${selectedStaffLabs.length} labs)`}
          </button>
        </div>
      </div>
    </div>
  </div>
);

{/* ADD this modal after the existing modals */}
{showAddLabModal && (
  <AddLabModal
    onClose={() => setShowAddLabModal(false)}
    onLabAdded={(labName) => {
      console.log('Lab added:', labName);
    }}
  />
)}

  return (
    <div style={dashboardContainerStyles}>
      {/* Header */}
      <div style={dashboardHeaderStyles}>
        <div style={dashboardNavStyles}>
          <h1 style={dashboardTitleStyles}>HOD Dashboard</h1>
          <div style={profileAreaStyles}>
            <button style={profileButtonStyles} onClick={() => setShowProfileMenu(v => !v)} aria-label="Profile menu">
              <FaUser />
            </button>
            {showProfileMenu && (
              <div style={profileDropdownStyles}>
                <div style={profileInfoRowStyles}><strong>{currentUser?.name}</strong></div>
                <div style={profileInfoRowStyles}>{currentUser?.email}</div>
                <div style={profileDividerStyles} />
                <button style={profileItemStyles} onClick={() => { setShowChangePassword(true); setShowProfileMenu(false); }}>Change Password</button>
                <button style={profileItemStyles} onClick={() => setShowProfileMenu(false)}>View Profile</button>
                <button style={{...profileItemStyles, color: '#dc3545'}} onClick={handleLogout}><FaSignOutAlt /> Logout</button>
              </div>
            )}
          </div>
        </div>
      </div>

      <div style={dashboardContentStyles}>
        {/* Sidebar */}
        <aside style={sidebarStyles}>
          <button style={{
            ...sidebarItemStyles,
            ...(activeSection === 'overview' ? sidebarItemActiveStyles : {})
          }} onClick={() => setActiveSection('overview')}>
            <FaChartPie /> Overview
          </button>
          <button style={{
            ...sidebarItemStyles,
            ...(activeSection === 'students' ? sidebarItemActiveStyles : {})
          }} onClick={() => setActiveSection('students')}>
            <FaUsers /> Students
          </button>
          <button style={{
            ...sidebarItemStyles,
            ...(activeSection === 'staff' ? sidebarItemActiveStyles : {})
          }} onClick={() => setActiveSection('staff')}>
            <FaUsers /> Staff
          </button>
          <button style={{
            ...sidebarItemStyles,
            ...(activeSection === 'subjects' ? sidebarItemActiveStyles : {})
          }} onClick={() => setActiveSection('subjects')}>
            <FaBook /> Lab Subjects
          </button>
          <button style={{
            ...sidebarItemStyles,
            ...(activeSection === 'analytics' ? sidebarItemActiveStyles : {})
          }} onClick={() => setActiveSection('analytics')}>
            <FaChartPie /> Analytics
          </button>
        </aside>

        <main style={dashboardMainStyles}>
          {/* Notification */}
          {notification.message && (
            <div style={{
              padding: '10px 15px',
              margin: '0 0 20px 0',
              borderRadius: '6px',
              backgroundColor: notification.type === 'success' ? '#d4edda' : '#f8d7da',
              color: notification.type === 'success' ? '#155724' : '#721c24',
              border: `1px solid ${notification.type === 'success' ? '#c3e6cb' : '#f5c6cb'}`,
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              fontSize: '14px'
            }}>
              {notification.type === 'success' ? <FaCheckCircle /> : <FaExclamationTriangle />}
              {notification.message}
            </div>
          )}

          {/* Controls Bar */}
          {activeSection !== 'staff' && activeSection !== 'subjects' && activeSection !== 'overview' && (
          <div style={controlsBarStyles}>
            <div style={filterGroupStyles}>
              <label style={filterLabelStyles}>
                <FaFilter /> Year Filter
              </label>
              <select
                style={filterSelectStyles}
                value={yearFilter}
                onChange={(e) => setYearFilter(e.target.value)}
              >
                <option value="All">All Years</option>
                {yearOrder.map(year => (
                  <option key={year} value={year}>{year}</option>
                ))}
              </select>
            </div>
            
            <div style={filterGroupStyles}>
              <label style={filterLabelStyles}>Lab Filter</label>
              <select
                style={filterSelectStyles}
                value={labFilter}
                onChange={(e) => setLabFilter(e.target.value)}
              >
                <option value="All Labs">All Labs</option>
                {labNames.map(lab => (
                  <option key={lab} value={lab}>{lab}</option>
                ))}
              </select>
            </div>

            {activeSection === 'students' && (
              <div style={filterGroupStyles}>
                <label style={filterLabelStyles}>Search by Student ID</label>
                <input
                  type="text"
                  style={formInputStyles}
                  placeholder="e.g., STU001"
                  value={studentIdSearch}
                  onChange={(e) => setStudentIdSearch(e.target.value)}
                />
              </div>
            )}
          </div>
          )}

     

{/* Overview Section - FIXED VERSION */}
{activeSection === 'overview' && (
  <>
    {/* Summary Cards - FIXED */}
    <div style={summaryCardsStyles}>
      <div style={summaryCardStyles}>
        <div style={summaryCardIconStyles}>
          <FaUsers />
        </div>
        <div style={summaryCardContentStyles}>
          {/* FIXED: Use multiple fallbacks for student count */}
          <div style={summaryCardValueStyles}>
            {summary.studentsCount ?? 
             users.filter(u => u.role === 'student' || u.role === 'STUDENT').length ?? 
             students.length ?? 
             0}
          </div>
          <div style={summaryCardTitleStyles}>Total Students</div>
        </div>
      </div>
      <div style={summaryCardStyles}>
        <div style={{...summaryCardIconStyles, backgroundColor: '#f0f9ff', color: '#0284c7'}}>
          <FaUsers />
        </div>
        <div style={summaryCardContentStyles}>
          {/* FIXED: Use multiple fallbacks for staff count */}
          <div style={summaryCardValueStyles}>
            {summary.staffCount ?? 
             users.filter(u => u.role === 'staff' || u.role === 'STAFF').length ?? 
             staff.length ?? 
             0}
          </div>
          <div style={summaryCardTitleStyles}>Total Staff</div>
        </div>
      </div>
      <div style={summaryCardStyles}>
        <div style={{...summaryCardIconStyles, backgroundColor: '#f0fdf4', color: '#16a34a'}}>
          <FaChartPie />
        </div>
        <div style={summaryCardContentStyles}>
          <div style={summaryCardValueStyles}>{summary.avgAttendance ?? avgAttendance ?? 0}%</div>
          <div style={summaryCardTitleStyles}>Avg Attendance</div>
        </div>
      </div>
      <div style={summaryCardStyles}>
        <div style={{...summaryCardIconStyles, backgroundColor: '#fef3c7', color: '#d97706'}}>
          <FaCog />
        </div>
        <div style={summaryCardContentStyles}>
          <div style={summaryCardValueStyles}>
            {summary.totalLabAssignments ?? 
             staff.reduce((sum, s) => sum + (s.assignedLabs?.length || 0), 0) ?? 
             0}
          </div>
          <div style={summaryCardTitleStyles}>Lab Assignments</div>
        </div>
      </div>
    </div>

    {/* Students by Year - FIXED */}
    <div style={sectionStyles}>
      <div style={sectionHeaderStyles}>
        <h2 style={sectionTitleStyles}>
          <FaGraduationCap /> Students by Year
        </h2>
        {/* FIXED: Add debug info */}
        <div style={{fontSize: '12px', color: '#666'}}>
          Total: {summary.studentsCount ?? users.filter(u => u.role === 'student' || u.role === 'STUDENT').length ?? 0}
        </div>
      </div>
      <div style={studentsByYearGridStyles}>
        {yearOrder.map((year) => {
          // FIXED: Enhanced year count with debugging
          const yearCount = users.filter(user => {
            const userRole = (user.role || '').toLowerCase();
            const isStudent = userRole === 'student';
            
            let matchesYear = false;
            if (year === '2nd Year') {
              matchesYear = user.year === '2nd Year' || user.year === '2nd' || user.year === '2' || user.year === 2;
            } else if (year === '3rd Year') {
              matchesYear = user.year === '3rd Year' || user.year === '3rd' || user.year === '3' || user.year === 3;
            } else if (year === '4th Year') {
              matchesYear = user.year === '4th Year' || user.year === '4th' || user.year === '4' || user.year === 4;
            } else {
              matchesYear = user.year === year;
            }
            
            return isStudent && matchesYear;
          }).length;
          
          return (
            <div key={year} style={yearOverviewCardStyles}>
              <div style={yearCardHeaderStyles}>
                <div style={yearTitleStyles}>{year}</div>
                <div style={yearIconStyles}>
                  <FaGraduationCap />
                </div>
              </div>
              <div style={yearCardContentStyles}>
                <div style={studentCountDisplayStyles}>
                  <span style={countNumberStyles}>{yearCount}</span>
                  <span style={countLabelStyles}>students</span>
                </div>
                <div style={subjectCountDisplayStyles}>
                  <span style={subjectCountStyles}>{labSubjects[year]?.length || 0}</span>
                  <span style={subjectLabelStyles}>lab subjects</span>
                </div>
              </div>
              <div style={yearCardFooterStyles}>
                <button
                  style={viewDetailsBtnStyles}
                  onClick={() => setActiveSection('students')}
                >
                  View Details →
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>

  
              {/* Quick Actions */}
              <div style={sectionStyles}>
                <div style={sectionHeaderStyles}>
                  <h2 style={sectionTitleStyles}>
                    <FaCog /> Quick Actions
                  </h2>
                </div>
                <div style={quickActionsStyles}>
                  <button 
                    style={quickActionBtnStyles}
                    onClick={() => setActiveSection('students')}
                  >
                    <div style={quickActionIconStyles}>
                      <FaPlus />
                    </div>
                    <span style={quickActionTextStyles}>Add Student</span>
                  </button>
                  <button 
                    style={quickActionBtnStyles}
                    onClick={() => setActiveSection('staff')}
                  >
                    <div style={{...quickActionIconStyles, backgroundColor: '#f0f9ff', color: '#0284c7'}}>
                      <FaPlus />
                    </div>
                    <span style={quickActionTextStyles}>Add Staff</span>
                  </button>
                  <button 
                    style={quickActionBtnStyles}
                    onClick={() => setActiveSection('subjects')}
                  >
                    <div style={{...quickActionIconStyles, backgroundColor: '#f0fdf4', color: '#16a34a'}}>
                      <FaBook />
                    </div>
                    <span style={quickActionTextStyles}>Lab Subjects</span>
                  </button>
                  <button 
                    style={quickActionBtnStyles}
                    onClick={() => setActiveSection('analytics')}
                  >
                    <div style={{...quickActionIconStyles, backgroundColor: '#fef3c7', color: '#d97706'}}>
                      <FaChartPie />
                    </div>
                    <span style={quickActionTextStyles}>Analytics</span>
                  </button>
                </div>
              </div>
            </>
          )}

          {/* Students Section */}
          {activeSection === 'students' && (
          <>
            <div style={summaryCardsStyles}>
              <div style={summaryCardStyles}>
                <div style={summaryCardIconStyles}>
                  <FaUsers />
                </div>
                <div style={summaryCardContentStyles}>
                  <div style={summaryCardValueStyles}>{totalStudents}</div>
                  <div style={summaryCardTitleStyles}>Total Students</div>
                </div>
              </div>
              <div style={summaryCardStyles}>
                <div style={{...summaryCardIconStyles, backgroundColor: '#f0fdf4', color: '#16a34a'}}>
                  <FaChartPie />
                </div>
                <div style={summaryCardContentStyles}>
                  <div style={summaryCardValueStyles}>{avgAttendance}%</div>
                  <div style={summaryCardTitleStyles}>Avg Attendance</div>
                </div>
              </div>
            </div>

            <div style={sectionStyles}>
              <div style={sectionHeaderStyles}>
                <h2 style={sectionTitleStyles}>
                  <FaUsers /> Students Management
                </h2>
                <button 
                  style={{...btnStyles, ...btnPrimaryStyles}}
                  onClick={() => setShowAddModal('student')}
                >
                  <FaPlus /> Add Student
                </button>
              </div>
              
              {yearOrder.map(year => {
                const yearStudents = studentsByYear[year];
                return (
                  <div key={year} style={dropdownSectionStyles}>
                    <div 
                      style={dropdownHeaderStyles}
                      onClick={() => toggleDropdown(`students-${year}`)}
                    >
                      <span>{year} ({yearStudents.length} students)</span>
                      <span style={{
                        ...chevronStyles,
                        transform: openDropdowns[`students-${year}`] ? 'rotate(90deg)' : 'rotate(0deg)'
                      }}>
                        <FaChevronRight />
                      </span>
                    </div>

                    {openDropdowns[`students-${year}`] && (
                      <div style={dropdownContentStyles}>
                        {yearStudents.length === 0 ? (
                          <p style={{ padding: '10px', color: '#666' }}>
                            No students in this year
                          </p>
                        ) : (
                          <div style={tableContainerStyles}>
                            <table style={tableStyles}>
                              <thead>
                                <tr>
                                  <th style={tableHeaderStyles}>ID</th>
                                  <th style={tableHeaderStyles}>Name</th>
                                  <th style={tableHeaderStyles}>Email</th>
                                  <th style={tableHeaderStyles}>Attendance %</th>
                                  <th style={tableHeaderStyles}>Actions</th>
                                </tr>
                              </thead>
                              <tbody>
                                {yearStudents.map(student => {
                                  const studentAttendance = attendance.filter(a => a.studentId === student.studentId);
                                  const avgAttendance = studentAttendance.length > 0
                                    ? Math.round(studentAttendance.reduce((sum, a) => sum + a.percentage, 0) / studentAttendance.length)
                                    : 0;

                                  return (
                                    <tr key={student.id} style={tableRowStyles}>
                                      <td style={tableCellStyles}>{student.studentId}</td>
                                      <td style={tableCellStyles}>{student.name}</td>
                                      <td style={tableCellStyles}>{student.email}</td>
                                      <td style={tableCellStyles}>
                                        <span style={{
                                          ...attendancePercentageStyles,
                                          color: avgAttendance >= 85 ? '#16a34a' : avgAttendance >= 75 ? '#d97706' : '#dc2626'
                                        }}>
                                          {avgAttendance}%
                                        </span>
                                      </td>
                                      <td style={tableCellStyles}>
                                        <div style={actionButtonsStyles}>
                                          <button 
                                            style={{...actionBtnStyles, ...actionBtnPrimaryStyles}}
                                            onClick={() => handleGenerateTempPassword(student.id)}
                                            title="Generate Temporary Password"
                                          >
                                            <FaKey />
                                          </button>
                                          <button 
                                            style={{...actionBtnStyles, ...actionBtnSecondaryStyles}}
                                            onClick={() => handleViewAttendance(student)}
                                            title="View Attendance"
                                          >
                                            <FaEye />
                                          </button>
                                          <button 
                                            style={{...actionBtnStyles, ...actionBtnSuccessStyles}}
                                            onClick={() => exportCSV(studentAttendance, `${student.studentId}_attendance.csv`)}
                                            title="Export CSV"
                                          >
                                            <FaDownload />
                                          </button>
                                          <button 
                                            style={{...actionBtnStyles, ...actionBtnDangerStyles}}
                                            onClick={async () => {
                                              if (window.confirm(`Are you sure you want to delete ${student.name}?`)) {
                                                try {
                                                  await removeUser(student.id);
                                                  await loadAllUsers();
                                                  showNotification('success', `${student.name} deleted`);
                                                } catch (err) {
                                                  showNotification('error', err?.error || 'Delete failed');
                                                }
                                              }
                                            }}
                                            title="Delete Student"
                                          >
                                            <FaTrash />
                                          </button>
                                        </div>
                                      </td>
                                    </tr>
                                  );
                                })}
                              </tbody>
                            </table>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </>
          )}

          {/* Staff Section */}
          {activeSection === 'staff' && (
            <>
              <div style={summaryCardsStyles}>
                <div style={summaryCardStyles}>
                  <div style={{...summaryCardIconStyles, backgroundColor: '#f0f9ff', color: '#0284c7'}}>
                    <FaUsers />
                  </div>
                  <div style={summaryCardContentStyles}>
                    <div style={summaryCardValueStyles}>{totalStaff}</div>
                    <div style={summaryCardTitleStyles}>Total Staff</div>
                  </div>
                </div>
                <div style={summaryCardStyles}>
                  <div style={{...summaryCardIconStyles, backgroundColor: '#fef3c7', color: '#d97706'}}>
                    <FaCog />
                  </div>
                  <div style={summaryCardContentStyles}>
                    <div style={summaryCardValueStyles}>{filteredStaff.reduce((sum, s) => sum + (s.assignedLabs?.length || 0), 0)}</div>
                    <div style={summaryCardTitleStyles}>Lab Assignments</div>
                  </div>
                </div>
              </div>

              <div style={sectionStyles}>
                <div style={sectionHeaderStyles}>
                  <h2 style={sectionTitleStyles}>
                    <FaUsers /> Staff Management
                  </h2>
                  <button 
                    style={{...btnStyles, ...btnPrimaryStyles}}
                    onClick={() => setShowAddModal('staff')}
                  >
                    <FaPlus /> Add Staff
                  </button>
                </div>

                <div style={tableContainerStyles}>
                  <table style={tableStyles}>
                    <thead>
                      <tr>
                        <th style={tableHeaderStyles}>Name</th>
                        <th style={tableHeaderStyles}>Email</th>
                        <th style={tableHeaderStyles}>Assigned Labs</th>
                        <th style={tableHeaderStyles}>Lab Count</th>
                        <th style={tableHeaderStyles}>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredStaff.length === 0 ? (
                        <tr>
                          <td colSpan="5" style={{ textAlign: 'center', padding: '15px', color: '#666' }}>
                            No staff members found
                          </td>
                        </tr>
                      ) : (
                        Object.keys(staffByDept).map(dept => {
                          const deptStaff = staffByDept[dept];
                          return (
                            <React.Fragment key={dept}>
                              <tr>
                                <td colSpan="5" style={{ background: '#f3f4f6', fontWeight: 'bold', padding: '10px' }}>
                                  {dept} ({deptStaff.length} staff)
                                </td>
                              </tr>
                              {deptStaff.map(staff => (
                                <tr key={staff.id} style={tableRowStyles}>
                                  <td style={tableCellStyles}>{staff.name}</td>
                                  <td style={tableCellStyles}>{staff.email}</td>
                                  <td style={tableCellStyles}>
                                    <div>
                                      {staff.assignedLabs && staff.assignedLabs.length > 0 ? (
                                        <div>
                                          {staff.assignedLabs.map((lab, index) => (
                                            <span key={lab} style={labTagStyles}>
                                              {lab}
                                              {index < staff.assignedLabs.length - 1 && ', '}
                                            </span>
                                          ))}
                                        </div>
                                      ) : (
                                        <span style={{ color: '#999', fontStyle: 'italic' }}>No labs assigned</span>
                                      )}
                                    </div>
                                  </td>
                                  <td style={tableCellStyles}>
                                    <span style={{
                                      ...labCountStyles,
                                      backgroundColor: (staff.assignedLabs?.length || 0) > 0 ? '#3b82f6' : '#6b7280',
                                      color: 'white'
                                    }}>
                                      {staff.assignedLabs?.length || 0}
                                    </span>
                                  </td>
                                  <td style={tableCellStyles}>
                                    <div style={actionButtonsStyles}>
                                      <button 
                                        style={{...actionBtnStyles, ...actionBtnInfoStyles}}
                                        onClick={() => handleAssignLabs(staff)}
                                        title="Assign Labs"
                                      >
                                        <FaCog /> Assign
                                      </button>
                                      <button 
                                        style={{...actionBtnStyles, ...actionBtnPrimaryStyles}}
                                        onClick={() => handleGenerateTempPassword(staff.id)}
                                        title="Generate Temporary Password"
                                      >
                                        <FaKey />
                                      </button>
                                      <button 
                                        style={{...actionBtnStyles, ...actionBtnDangerStyles}}
                                        onClick={async () => {
                                          if (window.confirm(`Are you sure you want to delete ${staff.name}?`)) {
                                            try {
                                              await removeUser(staff.id);
                                              await loadAllUsers();
                                              showNotification('success', `${staff.name} deleted`);
                                            } catch (err) {
                                              showNotification('error', err?.error || 'Delete failed');
                                            }
                                          }
                                        }}
                                        title="Delete Staff"
                                      >
                                        <FaTrash />
                                      </button>
                                    </div>
                                  </td>
                                </tr>
                              ))}
                            </React.Fragment>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}

          {/* Lab Subjects Management Section */}
          {activeSection === 'subjects' && (
            <div className="section">
              <div className="section-header">
                <h2 className="section-title">
                  <FaBook /> Lab Subject Management
                </h2>
                <div className="manager-controls">
                  <button 
                    className="btn btn-primary"
                    onClick={applySubjectsToStudents}
                    disabled={labSubjects[selectedYear]?.length === 0}
                  >
                    <FaCheckCircle /> Apply to All {selectedYear} Students
                  </button>
                </div>
              </div>

              <div className="year-selector" style={{ 
                marginBottom: '20px',
                background: '#f8f9fa',
                padding: '15px',
                borderRadius: '8px',
                border: '1px solid #dee2e6'
              }}>
                <label className="filter-label">
                  <FaGraduationCap /> Select Year to Manage:
                </label>
                <select 
                  className="filter-select" 
                  value={selectedYear}
                  onChange={(e) => {
                    setSelectedYear(e.target.value);
                    setShowAddForm(false);
                    setEditingSubject(null);
                  }}
                  style={{ minWidth: '200px' }}
                >
                  {yearOrder.map(year => (
                    <option key={year} value={year}>
                      {year} ({getStudentCount(year)} students)
                    </option>
                  ))}
                </select>
              </div>

              <div className="subjects-container" style={{
                background: 'white',
                padding: '20px',
                borderRadius: '8px',
                border: '1px solid #dee2e6'
              }}>
                <div className="subjects-header" style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  marginBottom: '15px',
                  paddingBottom: '10px',
                  borderBottom: '2px solid #dee2e6'
                }}>
                  <h3 style={{ margin: '0', display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <FaUsers /> {selectedYear} Lab Subjects ({labSubjects[selectedYear]?.length || 0} subjects)
                  </h3>
                  <button 
                    className="btn-premium"
                    onClick={() => setShowAddForm(true)}
                    disabled={showAddForm}
                    style={{
                      background: '#3b82f6',
                      border: 'none',
                      color: 'white',
                      padding: '8px 16px',
                      borderRadius: '6px',
                      fontSize: '14px',
                      fontWeight: '500',
                      cursor: 'pointer',
                      transition: 'all 0.3s ease',
                      boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '6px',
                      minWidth: 'auto',
                      width: 'auto'
                    }}
                  >
                    <FaPlus style={{ fontSize: '12px' }} /> Add Subject
                  </button>
                </div>

                {showAddForm && (
                  <div className="add-subject-form" style={{
                    padding: '15px',
                    background: '#f8f9fa',
                    border: '1px solid #dee2e6',
                    borderRadius: '4px',
                    margin: '10px 0'
                  }}>
                    <div className="form-group">
                      <label className="form-label">New Subject Name:</label>
                      <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                        <input
                          type="text"
                          className="form-input"
                          placeholder="Enter lab subject name (e.g., Advanced Physics Lab)"
                          value={newSubject}
                          onChange={(e) => setNewSubject(e.target.value)}
                          onKeyPress={(e) => e.key === 'Enter' && handleAddSubject()}
                          style={{ flex: 1 }}
                          autoFocus
                        />
                        <button 
                          className="btn btn-primary"
                          onClick={handleAddSubject}
                        >
                          <FaSave /> Save
                        </button>
                        <button 
                          className="btn btn-secondary"
                          onClick={handleCancelAdd}
                        >
                          <FaTimes /> Cancel
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                <div className="subjects-list">
                  {(labSubjects[selectedYear]?.length || 0) > 0 ? (
                    <div className="table-container">
                      <table className="table">
                        <thead>
                          <tr>
                            <th>#</th>
                            <th>Subject Name</th>
                            <th>Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {(labSubjects[selectedYear] || []).map((subject, index) => (
                            <tr key={subject}>
                              <td>{index + 1}</td>
                              <td>
                                {editingSubject === subject ? (
                                  <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                                    <input
                                      type="text"
                                      className="form-input"
                                      value={editingValue}
                                      onChange={(e) => setEditingValue(e.target.value)}
                                      onKeyPress={(e) => e.key === 'Enter' && handleSaveEdit()}
                                      style={{ flex: 1 }}
                                      autoFocus
                                    />
                                    <button 
                                      className="action-btn save-btn"
                                      onClick={handleSaveEdit}
                                      title="Save Changes"
                                      style={{
                                        background: '#28a745',
                                        color: 'white',
                                        padding: '6px 12px',
                                        border: 'none',
                                        borderRadius: '4px',
                                        cursor: 'pointer'
                                      }}
                                    >
                                      <FaSave />
                                    </button>
                                    <button 
                                      className="action-btn cancel-btn"
                                      onClick={handleCancelEdit}
                                      title="Cancel Edit"
                                      style={{
                                        background: '#6c757d',
                                        color: 'white',
                                        padding: '6px 12px',
                                        border: 'none',
                                        borderRadius: '4px',
                                        cursor: 'pointer'
                                      }}
                                    >
                                      <FaTimes />
                                    </button>
                                  </div>
                                ) : (
                                  <span style={{ fontWeight: '500' }}>{subject}</span>
                                )}
                              </td>
                              <td>
                                {editingSubject !== subject && (
                                  <div className="action-buttons">
                                    <button 
                                      className="action-btn edit-btn"
                                      onClick={() => handleEditSubject(subject)}
                                      title="Edit Subject"
                                      style={{
                                        background: '#007bff',
                                        color: 'white',
                                        padding: '6px 12px',
                                        border: 'none',
                                        borderRadius: '4px',
                                        cursor: 'pointer',
                                        marginRight: '8px'
                                      }}
                                    >
                                      <FaEdit /> Edit
                                    </button>
                                    <button 
                                      className="action-btn delete-btn"
                                      onClick={() => handleRemoveSubject(subject)}
                                      title="Remove Subject"
                                    >
                                      <FaTrash /> Remove
                                    </button>
                                  </div>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div style={{ 
                      padding: '40px', 
                      textAlign: 'center', 
                      color: '#666',
                      background: '#f8f9fa',
                      border: '1px solid #dee2e6',
                      borderRadius: '4px'
                    }}>
                      <FaBook size={32} style={{ opacity: 0.3, marginBottom: '15px' }} />
                      <p>No lab subjects assigned to {selectedYear} yet.</p>
                      <p>Click "Add New Subject" to start assigning lab subjects.</p>
                    </div>
                  )}
                </div>

                <div className="impact-info" style={{
                  marginTop: '20px',
                  padding: '15px',
                  background: '#e3f2fd',
                  border: '1px solid #bbdefb',
                  borderRadius: '4px'
                }}>
                  <h4 style={{ margin: '0 0 10px 0', color: '#1976d2' }}>
                    <FaUsers /> Impact Information
                  </h4>
                  <p style={{ margin: '0', color: '#1976d2' }}>
                    Changes to {selectedYear} subjects will automatically update lab assignments for <strong>{getStudentCount(selectedYear)} students</strong> in this year group.
                  </p>
                  {getStudentCount(selectedYear) === 0 && (
                    <p style={{ margin: '5px 0 0 0', color: '#f57c00', fontStyle: 'italic' }}>
                      No students found in {selectedYear}. Subjects will be applied when students are added to this year.
                    </p>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Selected Student Attendance Details */}
          {selectedStudent && (
            <div style={sectionStyles}>
              <div style={sectionHeaderStyles}>
                <h2 style={sectionTitleStyles}>
                  Attendance Details - {selectedStudent.name}
                </h2>
                <div style={{display: 'flex', gap: '10px'}}>
                  <button 
                    style={{...btnStyles, ...btnSuccessStyles}}
                    onClick={() => {
                      const studentAttendance = attendance.filter(a => a.studentId === selectedStudent.studentId);
                      exportCSV(studentAttendance, `${selectedStudent.studentId}_detailed_attendance.csv`);
                    }}
                  >
                    <FaDownload /> Export CSV
                  </button>
                  <button 
                    style={{...btnStyles, ...btnSecondaryStyles}}
                    onClick={() => setSelectedStudent(null)}
                  >
                    Close
                  </button>
                </div>
              </div>
              <div style={tableContainerStyles}>
                <table style={tableStyles}>
                  <thead>
                    <tr>
                      <th style={tableHeaderStyles}>Date</th>
                      <th style={tableHeaderStyles}>Subject/Lab</th>
                      <th style={tableHeaderStyles}>Status</th>
                      <th style={tableHeaderStyles}>Percentage</th>
                    </tr>
                  </thead>
                  <tbody>
                    {attendance
                      .filter(a => a.studentId === selectedStudent.studentId)
                      .map(record => (
                        <tr key={record.id} style={tableRowStyles}>
                          <td style={tableCellStyles}>{record.date}</td>
                          <td style={tableCellStyles}>{record.lab}</td>
                          <td style={tableCellStyles}>
                            <span style={{
                              ...attendancePercentageStyles,
                              color: record.status === 'present' ? '#16a34a' : '#dc2626'
                            }}>
                              {record.status.toUpperCase()}
                            </span>
                          </td>
                          <td style={tableCellStyles}>{record.percentage}%</td>
                        </tr>
                      ))
                    }
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Analytics Chart */}
          {activeSection === 'analytics' && (
          <div style={chartContainerStyles}>
            <h2 style={chartTitleStyles}>
              <FaChartPie /> Year-wise Attendance Distribution
            </h2>
            <ResponsiveContainer width="100%" height={400}>
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({name, value, students}) => `${name}: ${value}% (${students} students)`}
                  outerRadius={120}
                  fill="#8884d8"
                  dataKey="value"
                  onClick={(data, index) => setDrilldownYear(pieData[index]?.name || null)}
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value, name, props) => [
                  `${value}%`, 
                  `${props.payload.name} (${props.payload.students} students)`
                ]} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
          )}
          
          {activeSection === 'analytics' && drilldownYear && (
            <div style={sectionStyles}>
              <div style={sectionHeaderStyles}>
                <h2 style={sectionTitleStyles}>{drilldownYear} - Students Detail</h2>
                <button style={{...btnStyles, ...btnSecondaryStyles}} onClick={() => setDrilldownYear(null)}>Close</button>
              </div>
              {(studentsByYear[drilldownYear] || []).map(student => (
                <div key={student.id} style={{...tableContainerStyles, marginBottom: '16px'}}>
                  <h3 style={{ margin: '8px 0' }}>{student.name} ({student.studentId})</h3>
                  <table style={tableStyles}>
                    <thead>
                      <tr>
                        <th style={tableHeaderStyles}>Date</th>
                        <th style={tableHeaderStyles}>Subject/Lab</th>
                        <th style={tableHeaderStyles}>Status</th>
                        <th style={tableHeaderStyles}>Percentage</th>
                      </tr>
                    </thead>
                    <tbody>
                      {attendance
                        .filter(a => a.studentId === student.studentId && (labFilter === 'All Labs' || a.lab === labFilter))
                        .map(record => (
                          <tr key={record.id} style={tableRowStyles}>
                            <td style={tableCellStyles}>{record.date}</td>
                            <td style={tableCellStyles}>{record.lab}</td>
                            <td style={tableCellStyles}>
                              <span style={{
                                ...attendancePercentageStyles,
                                color: record.status === 'present' ? '#16a34a' : '#dc2626'
                              }}>
                                {record.status.toUpperCase()}
                              </span>
                            </td>
                            <td style={tableCellStyles}>{record.percentage}%</td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              ))}
            </div>
          )}

        </main>
      </div>

      {/* Modals */}
      {showAddModal && (
        <AddUserModal
          type={showAddModal}
          onClose={() => setShowAddModal(null)}
          onAdd={handleAddUser}
        />
      )}

      {tempPassword && (
        <TempPasswordModal
          password={tempPassword}
          onClose={() => setTempPassword(null)}
        />
      )}

      {showLabAssignModal && (
        <LabAssignmentModal
          staff={showLabAssignModal}
          onClose={() => {
            setShowLabAssignModal(null);
            setSelectedStaffLabs([]);
          }}
        />
      )}

      {showChangePassword && (
        <div className="modal-overlay">
          <div className="modal">
            <h2 className="modal-header">Change Password</h2>
            <ChangePasswordForm onCancel={() => setShowChangePassword(false)} onSave={handleChangePassword} />
          </div>
        </div>
      )}
    </div>
  );
};

const ChangePasswordForm = ({ onCancel, onSave }) => {
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const canSave = password && password.length >= 6 && password === confirm;
  return (
    <div>
      <div className="form-group">
        <label className="form-label">New Password</label>
        <input className="form-input" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Enter new password" />
      </div>
      <div className="form-group">
        <label className="form-label">Confirm Password</label>
        <input className="form-input" type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} placeholder="Re-enter password" />
      </div>
      <div className="modal-actions">
        <button className="btn btn-secondary" onClick={onCancel}>Cancel</button>
        <button className="btn btn-primary" disabled={!canSave} onClick={() => onSave(password)}>Save Password</button>
      </div>
    </div>
  );
};

// Styles
const dashboardContainerStyles = {
  background: '#f8fafc',
  minHeight: '100vh',
  fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
  color: '#1e293b'
};

const dashboardHeaderStyles = {
  background: '#3b82f6',
  boxShadow: '0 1px 3px rgba(0, 0, 0, 0.12), 0 1px 2px rgba(0, 0, 0, 0.24)',
  padding: '16px 24px',
  borderBottom: '1px solid #e2e8f0'
};

const dashboardNavStyles = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center'
};

const dashboardTitleStyles = {
  color: 'white',
  fontSize: '20px',
  fontWeight: '600',
  margin: 0
};

const profileAreaStyles = {
  position: 'relative'
};

const profileButtonStyles = {
  background: 'rgba(255, 255, 255, 0.1)',
  border: '1px solid rgba(255, 255, 255, 0.2)',
  borderRadius: '50%',
  width: '36px',
  height: '36px',
  color: 'white',
  cursor: 'pointer',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  fontSize: '16px',
  transition: 'all 0.2s ease'
};

const profileDropdownStyles = {
  position: 'absolute',
  top: '45px',
  right: '0',
  background: 'white',
  borderRadius: '8px',
  boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
  minWidth: '200px',
  zIndex: 1000,
  overflow: 'hidden',
  border: '1px solid #e5e7eb'
};

const profileInfoRowStyles = {
  padding: '10px 16px',
  fontSize: '14px',
  color: '#374151',
  borderBottom: '1px solid #f3f4f6'
};

const profileDividerStyles = {
  height: '1px',
  background: '#e5e7eb',
  margin: '4px 0'
};

const profileItemStyles = {
  width: '100%',
  background: 'none',
  border: 'none',
  padding: '10px 16px',
  textAlign: 'left',
  cursor: 'pointer',
  fontSize: '14px',
  color: '#374151',
  display: 'flex',
  alignItems: 'center',
  gap: '8px',
  transition: 'background 0.15s ease'
};

const dashboardContentStyles = {
  display: 'flex',
  minHeight: 'calc(100vh - 73px)'
};

const sidebarStyles = {
  width: '220px',
  background: 'white',
  boxShadow: '1px 0 3px rgba(0, 0, 0, 0.1)',
  padding: '16px 0',
  borderRight: '1px solid #e5e7eb'
};

const sidebarItemStyles = {
  width: '100%',
  background: 'none',
  border: 'none',
  padding: '12px 20px',
  textAlign: 'left',
  cursor: 'pointer',
  fontSize: '14px',
  color: '#6b7280',
  display: 'flex',
  alignItems: 'center',
  gap: '12px',
  transition: 'all 0.15s ease',
  fontWeight: '500'
};

const sidebarItemActiveStyles = {
  background: '#3b82f6',
  color: 'white',
  borderRight: '3px solid #1d4ed8'
};

const dashboardMainStyles = {
  flex: 1,
  background: 'white',
  borderRadius: '0',
  padding: '24px',
  margin: '0',
  boxShadow: 'none',
  overflow: 'auto'
};

const controlsBarStyles = {
  display: 'flex',
  gap: '16px',
  marginBottom: '20px',
  padding: '16px',
  background: '#f8fafc',
  borderRadius: '8px',
  border: '1px solid #e5e7eb'
};

const filterGroupStyles = {
  display: 'flex',
  flexDirection: 'column',
  gap: '6px'
};

const filterLabelStyles = {
  fontSize: '13px',
  fontWeight: '500',
  color: '#374151',
  display: 'flex',
  alignItems: 'center',
  gap: '6px'
};

const filterSelectStyles = {
  padding: '6px 10px',
  border: '1px solid #d1d5db',
  borderRadius: '6px',
  fontSize: '13px',
  backgroundColor: 'white',
  minWidth: '140px'
};

const summaryCardsStyles = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
  gap: '16px',
  marginBottom: '24px'
};

const summaryCardStyles = {
  background: 'white',
  border: '1px solid #e5e7eb',
  borderRadius: '8px',
  padding: '20px',
  display: 'flex',
  alignItems: 'center',
  gap: '16px',
  transition: 'all 0.2s ease',
  boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)',
  cursor: 'default'
};

const summaryCardIconStyles = {
  width: '48px',
  height: '48px',
  borderRadius: '8px',
  backgroundColor: '#dbeafe',
  color: '#3b82f6',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  fontSize: '20px',
  flexShrink: 0
};

const summaryCardContentStyles = {
  display: 'flex',
  flexDirection: 'column',
  gap: '4px'
};

const summaryCardValueStyles = {
  fontSize: '28px',
  fontWeight: '700',
  color: '#1e293b',
  lineHeight: 1
};

const summaryCardTitleStyles = {
  fontSize: '13px',
  color: '#6b7280',
  fontWeight: '500',
  textTransform: 'uppercase',
  letterSpacing: '0.5px'
};

const studentsByYearGridStyles = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
  gap: '20px',
  marginBottom: '24px'
};

const yearOverviewCardStyles = {
  background: 'white',
  border: '1px solid #e5e7eb',
  borderRadius: '8px',
  padding: '20px',
  transition: 'all 0.2s ease',
  boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)',
  cursor: 'default'
};

const yearCardHeaderStyles = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginBottom: '16px'
};

const yearTitleStyles = {
  fontSize: '18px',
  fontWeight: '600',
  color: '#1e293b',
  margin: 0
};

const yearIconStyles = {
  width: '40px',
  height: '40px',
  borderRadius: '50%',
  background: '#3b82f6',
  color: 'white',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  fontSize: '16px'
};

const yearCardContentStyles = {
  marginBottom: '16px'
};

const studentCountDisplayStyles = {
  display: 'flex',
  alignItems: 'baseline',
  gap: '8px',
  marginBottom: '8px'
};

const countNumberStyles = {
  fontSize: '32px',
  fontWeight: '700',
  color: '#3b82f6',
  lineHeight: 1
};

const countLabelStyles = {
  fontSize: '14px',
  color: '#6b7280',
  fontWeight: '500'
};

const subjectCountDisplayStyles = {
  display: 'flex',
  alignItems: 'baseline',
  gap: '8px',
  paddingLeft: '12px',
  borderLeft: '3px solid #e5e7eb'
};

const subjectCountStyles = {
  fontSize: '20px',
  fontWeight: '600',
  color: '#374151'
};

const subjectLabelStyles = {
  fontSize: '12px',
  color: '#6b7280',
  fontWeight: '500'
};

const yearCardFooterStyles = {
  borderTop: '1px solid #e5e7eb',
  paddingTop: '16px'
};

const viewDetailsBtnStyles = {
  width: '100%',
  background: '#3b82f6',
  color: 'white',
  border: 'none',
  padding: '10px 16px',
  borderRadius: '6px',
  fontSize: '14px',
  fontWeight: '500',
  cursor: 'pointer',
  transition: 'background 0.2s ease'
};

const quickActionsStyles = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
  gap: '16px',
  marginBottom: '24px'
};

const quickActionBtnStyles = {
  background: 'white',
  border: '1px solid #e5e7eb',
  borderRadius: '8px',
  padding: '16px',
  display: 'flex',
  alignItems: 'center',
  gap: '12px',
  cursor: 'pointer',
  transition: 'all 0.2s ease',
  boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)'
};

const quickActionIconStyles = {
  width: '36px',
  height: '36px',
  borderRadius: '6px',
  backgroundColor: '#dbeafe',
  color: '#3b82f6',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  fontSize: '16px',
  flexShrink: 0
};

const quickActionTextStyles = {
  fontSize: '14px',
  fontWeight: '500',
  color: '#374151'
};

const sectionStyles = {
  marginBottom: '32px'
};

const sectionHeaderStyles = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginBottom: '16px',
  paddingBottom: '12px',
  borderBottom: '1px solid #e5e7eb'
};

const sectionTitleStyles = {
  fontSize: '20px',
  fontWeight: '600',
  color: '#1e293b',
  display: 'flex',
  alignItems: 'center',
  gap: '8px',
  margin: 0
};

const dropdownSectionStyles = {
  marginBottom: '16px',
  border: '1px solid #e5e7eb',
  borderRadius: '8px',
  overflow: 'hidden',
  boxShadow: '0 1px 3px rgba(0, 0, 0, 0.05)'
};

const dropdownHeaderStyles = {
  padding: '14px 16px',
  background: '#f8fafc',
  cursor: 'pointer',
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  fontWeight: '500',
  color: '#374151',
  transition: 'background 0.15s ease',
  fontSize: '14px'
};

const chevronStyles = {
  transition: 'transform 0.2s ease',
  fontSize: '12px'
};

const dropdownContentStyles = {
  padding: '16px'
};

const tableContainerStyles = {
  background: 'white',
  borderRadius: '8px',
  overflow: 'hidden',
  boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)',
  border: '1px solid #e5e7eb'
};

const tableStyles = {
  width: '100%',
  borderCollapse: 'collapse'
};

const tableHeaderStyles = {
  background: '#3b82f6',
  color: 'white',
  padding: '12px',
  textAlign: 'left',
  fontWeight: '500',
  fontSize: '13px',
  textTransform: 'uppercase',
  letterSpacing: '0.5px'
};

const tableRowStyles = {
  borderBottom: '1px solid #e5e7eb',
  transition: 'background 0.15s ease'
};

const tableCellStyles = {
  padding: '12px',
  fontSize: '13px',
  color: '#374151'
};

const attendancePercentageStyles = {
  fontWeight: '500',
  padding: '2px 6px',
  borderRadius: '4px',
  fontSize: '12px'
};

const actionButtonsStyles = {
  display: 'flex',
  gap: '6px',
  flexWrap: 'wrap'
};

const actionBtnStyles = {
  border: 'none',
  borderRadius: '4px',
  padding: '6px 10px',
  cursor: 'pointer',
  fontSize: '12px',
  display: 'flex',
  alignItems: 'center',
  gap: '4px',
  transition: 'all 0.15s ease',
  fontWeight: '500'
};

const actionBtnPrimaryStyles = {
  background: '#3b82f6',
  color: 'white'
};

const actionBtnSecondaryStyles = {
  background: '#6b7280',
  color: 'white'
};

const actionBtnSuccessStyles = {
  background: '#16a34a',
  color: 'white'
};

const actionBtnDangerStyles = {
  background: '#dc2626',
  color: 'white'
};

const actionBtnInfoStyles = {
  background: '#0284c7',
  color: 'white'
};

const labTagStyles = {
  display: 'inline-block',
  background: '#f3f4f6',
  color: '#374151',
  padding: '2px 6px',
  borderRadius: '4px',
  fontSize: '12px',
  fontWeight: '500'
};

const labCountStyles = {
  padding: '2px 8px',
  borderRadius: '10px',
  fontSize: '12px',
  fontWeight: '500'
};

const btnStyles = {
  border: 'none',
  borderRadius: '6px',
  padding: '10px 16px',
  cursor: 'pointer',
  fontSize: '14px',
  fontWeight: '500',
  display: 'flex',
  alignItems: 'center',
  gap: '6px',
  transition: 'all 0.2s ease'
};

const btnPrimaryStyles = {
  background: '#3b82f6',
  color: 'white'
};

const btnSecondaryStyles = {
  background: '#6b7280',
  color: 'white'
};

const btnSuccessStyles = {
  background: '#16a34a',
  color: 'white'
};

const chartContainerStyles = {
  background: 'white',
  borderRadius: '8px',
  padding: '20px',
  marginBottom: '24px',
  border: '1px solid #e5e7eb',
  boxShadow: '0 1px 3px rgba(0, 0, 0, 0.05)'
};

const chartTitleStyles = {
  fontSize: '18px',
  fontWeight: '600',
  color: '#1e293b',
  marginBottom: '16px',
  display: 'flex',
  alignItems: 'center',
  gap: '8px'
};

const formInputStyles = {
  padding: '8px 12px',
  border: '1px solid #d1d5db',
  borderRadius: '6px',
  fontSize: '13px',
  transition: 'border-color 0.15s ease',
  boxSizing: 'border-box',
  width: '100%'
};
export default HODDashboard;