// Enhanced Database Seeder - Production Ready
import 'dotenv/config';
import bcrypt from 'bcryptjs';
import { prisma } from '../config/prisma.js';

const seed = async () => {
  try {
    console.log('🌱 Starting comprehensive database seed...');

    // Create HOD user
    const hodPasswordHash = await bcrypt.hash('hod123', 10);
    const hod = await prisma.user.upsert({
      where: { username: 'hod1' },
      update: {},
      create: {
        username: 'hod1',
        email: 'hod@example.com',
        password: hodPasswordHash,
        name: 'Head of Department',
        role: 'HOD',
        department: 'Computer Science'
      }
    });

    // Create Staff users
    const staffPasswordHash = await bcrypt.hash('staff123', 10);
    
    const staff1 = await prisma.user.upsert({
      where: { username: 'staff1' },
      update: {},
      create: {
        username: 'staff1',
        email: 'staff1@example.com',
        password: staffPasswordHash,
        name: 'Dr. John Smith',
        role: 'STAFF',
        department: 'Computer Science'
      }
    });

    const staff2 = await prisma.user.upsert({
      where: { username: 'staff2' },
      update: {},
      create: {
        username: 'staff2',
        email: 'staff2@example.com',
        password: staffPasswordHash,
        name: 'Prof. Jane Doe',
        role: 'STAFF',
        department: 'Computer Science'
      }
    });

    console.log('✅ Created HOD and Staff users');

    // Create Labs with proper year mapping
    const labs = [
      { name: 'Physics Lab', year: '2' },
      { name: 'Chemistry Lab', year: '2' },
      { name: 'Big Data Analytics', year: '3' },
      { name: 'Machine Learning Lab', year: '3' },
      { name: 'AI Lab', year: '4' },
      { name: 'Robotics Lab', year: '4' },
      { name: 'Programming Lab', year: '2' },
      { name: 'Database Lab', year: '3' },
      { name: 'Network Security Lab', year: '4' },
      { name: 'Software Engineering Lab', year: '3' }
    ];

    const createdLabs = [];
    for (const lab of labs) {
      const createdLab = await prisma.lab.upsert({
        where: { name_year: { name: lab.name, year: lab.year } },
        update: {},
        create: lab
      });
      createdLabs.push(createdLab);
    }

    console.log('✅ Created Labs:', createdLabs.map(l => `${l.name} (Year ${l.year})`));

    // Assign labs to staff - This is the key part!
    const staffAssignments = [
      // Staff1 gets Physics Lab (2nd year) and Big Data Analytics (3rd year)
      { staffId: staff1.id, labId: createdLabs[0].id }, // Physics Lab
      { staffId: staff1.id, labId: createdLabs[2].id }, // Big Data Analytics
      { staffId: staff1.id, labId: createdLabs[6].id }, // Programming Lab
      
      // Staff2 gets Chemistry Lab (2nd year), ML Lab (3rd year), AI Lab (4th year)
      { staffId: staff2.id, labId: createdLabs[1].id }, // Chemistry Lab
      { staffId: staff2.id, labId: createdLabs[3].id }, // ML Lab
      { staffId: staff2.id, labId: createdLabs[4].id }, // AI Lab
      { staffId: staff2.id, labId: createdLabs[7].id }, // Database Lab
    ];

    for (const assignment of staffAssignments) {
      await prisma.staffLabAssignment.upsert({
        where: { staffId_labId: assignment },
        update: {},
        create: assignment
      });
    }

    console.log('✅ Assigned Labs to Staff');

    // Create Students with proper year values
    const studentPasswordHash = await bcrypt.hash('student123', 10);
    
    const students = [
      // 2nd Year Students - year stored as '2'
      { username: 'stu001', email: 'stu001@example.com', name: 'Alice Johnson', studentId: 'STU001', year: '2' },
      { username: 'stu002', email: 'stu002@example.com', name: 'Bob Wilson', studentId: 'STU002', year: '2' },
      { username: 'stu003', email: 'stu003@example.com', name: 'Charlie Brown', studentId: 'STU003', year: '2' },
      { username: 'stu004', email: 'stu004@example.com', name: 'Diana Prince', studentId: 'STU004', year: '2' },
      { username: 'stu005', email: 'stu005@example.com', name: 'Eve Adams', studentId: 'STU005', year: '2' },
      { username: 'stu006', email: 'stu006@example.com', name: 'Frank Davis', studentId: 'STU006', year: '2' },
      { username: 'stu007', email: 'stu007@example.com', name: 'Grace Wang', studentId: 'STU007', year: '2' },
      
      // 3rd Year Students - year stored as '3' 
      { username: 'stu008', email: 'stu008@example.com', name: 'Henry Miller', studentId: 'STU008', year: '3' },
      { username: 'stu009', email: 'stu009@example.com', name: 'Ivy Chen', studentId: 'STU009', year: '3' },
      { username: 'stu010', email: 'stu010@example.com', name: 'Jack Ryan', studentId: 'STU010', year: '3' },
      { username: 'stu011', email: 'stu011@example.com', name: 'Kate Lee', studentId: 'STU011', year: '3' },
      { username: 'stu012', email: 'stu012@example.com', name: 'Leo Torres', studentId: 'STU012', year: '3' },
      { username: 'stu013', email: 'stu013@example.com', name: 'Mia Rodriguez', studentId: 'STU013', year: '3' },
      
      // 4th Year Students - year stored as '4'
      { username: 'stu014', email: 'stu014@example.com', name: 'Noah Kim', studentId: 'STU014', year: '4' },
      { username: 'stu015', email: 'stu015@example.com', name: 'Olivia Thompson', studentId: 'STU015', year: '4' },
      { username: 'stu016', email: 'stu016@example.com', name: 'Paul Anderson', studentId: 'STU016', year: '4' },
      { username: 'stu017', email: 'stu017@example.com', name: 'Quinn Martinez', studentId: 'STU017', year: '4' },
    ];

    const createdStudents = [];
    for (const student of students) {
      const createdStudent = await prisma.user.upsert({
        where: { username: student.username },
        update: {},
        create: {
          ...student,
          password: studentPasswordHash,
          role: 'STUDENT',
          department: 'Computer Science'
        }
      });
      createdStudents.push(createdStudent);
    }

    console.log('✅ Created Students:', createdStudents.map(s => `${s.name} (${s.studentId}) - Year ${s.year}`));

    // Student Lab Assignments - This is crucial for staff to see students!
    const studentAssignments = [
      // 2nd year students assigned to Physics Lab (Staff1) and Chemistry Lab (Staff2)
      { studentId: createdStudents[0].id, labId: createdLabs[0].id }, // Alice to Physics Lab
      { studentId: createdStudents[1].id, labId: createdLabs[0].id }, // Bob to Physics Lab
      { studentId: createdStudents[2].id, labId: createdLabs[0].id }, // Charlie to Physics Lab
      { studentId: createdStudents[3].id, labId: createdLabs[1].id }, // Diana to Chemistry Lab
      { studentId: createdStudents[4].id, labId: createdLabs[1].id }, // Eve to Chemistry Lab
      { studentId: createdStudents[5].id, labId: createdLabs[6].id }, // Frank to Programming Lab
      { studentId: createdStudents[6].id, labId: createdLabs[6].id }, // Grace to Programming Lab
      
      // 3rd year students assigned to BDA Lab (Staff1) and ML Lab (Staff2)
      { studentId: createdStudents[7].id, labId: createdLabs[2].id }, // Henry to Big Data Analytics
      { studentId: createdStudents[8].id, labId: createdLabs[2].id }, // Ivy to Big Data Analytics
      { studentId: createdStudents[9].id, labId: createdLabs[2].id }, // Jack to Big Data Analytics
      { studentId: createdStudents[10].id, labId: createdLabs[3].id }, // Kate to ML Lab
      { studentId: createdStudents[11].id, labId: createdLabs[3].id }, // Leo to ML Lab
      { studentId: createdStudents[12].id, labId: createdLabs[7].id }, // Mia to Database Lab
      
      // 4th year students assigned to AI Lab (Staff2)
      { studentId: createdStudents[13].id, labId: createdLabs[4].id }, // Noah to AI Lab
      { studentId: createdStudents[14].id, labId: createdLabs[4].id }, // Olivia to AI Lab
      { studentId: createdStudents[15].id, labId: createdLabs[4].id }, // Paul to AI Lab
      { studentId: createdStudents[16].id, labId: createdLabs[4].id }, // Quinn to AI Lab
    ];

    for (const assignment of studentAssignments) {
      await prisma.studentLabAssignment.upsert({
        where: { studentId_labId: assignment },
        update: {},
        create: assignment
      });
    }

    console.log('✅ Assigned Students to Labs - THIS FIXES THE STAFF DASHBOARD!');

    // Create sample attendance records
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    const dayBefore = new Date(yesterday);
    dayBefore.setDate(dayBefore.getDate() - 1);

    const attendanceRecords = [
      // Physics Lab attendance (Staff1's lab)
      { studentId: createdStudents[0].id, labId: createdLabs[0].id, status: 'PRESENT', date: today },
      { studentId: createdStudents[1].id, labId: createdLabs[0].id, status: 'PRESENT', date: today },
      { studentId: createdStudents[2].id, labId: createdLabs[0].id, status: 'ABSENT', date: today },
      
      // Big Data Analytics attendance (Staff1's lab)
      { studentId: createdStudents[7].id, labId: createdLabs[2].id, status: 'PRESENT', date: yesterday },
      { studentId: createdStudents[8].id, labId: createdLabs[2].id, status: 'PRESENT', date: yesterday },
      { studentId: createdStudents[9].id, labId: createdLabs[2].id, status: 'PRESENT', date: yesterday },
      
      // Chemistry Lab attendance (Staff2's lab)
      { studentId: createdStudents[3].id, labId: createdLabs[1].id, status: 'PRESENT', date: dayBefore },
      { studentId: createdStudents[4].id, labId: createdLabs[1].id, status: 'PRESENT', date: dayBefore },
      
      // AI Lab attendance (Staff2's lab)
      { studentId: createdStudents[13].id, labId: createdLabs[4].id, status: 'PRESENT', date: today },
      { studentId: createdStudents[14].id, labId: createdLabs[4].id, status: 'ABSENT', date: today },
    ];

    for (const record of attendanceRecords) {
      await prisma.attendance.create({ data: record });
    }

    console.log('✅ Created Sample Attendance Records');

    // Create year subjects
    const yearSubjects = [
      {
        year: '2',
        subjects: ['Physics', 'Chemistry', 'Mathematics', 'Programming Fundamentals', 'Data Structures']
      },
      {
        year: '3',
        subjects: ['Algorithms', 'Database Systems', 'Big Data Analytics', 'Machine Learning', 'Software Engineering']
      },
      {
        year: '4',
        subjects: ['Artificial Intelligence', 'Robotics', 'Advanced Software Engineering', 'Project Management', 'Research Methodology']
      }
    ];

    for (const yearSubject of yearSubjects) {
      await prisma.yearSubjects.upsert({
        where: { year: yearSubject.year },
        update: { subjects: yearSubject.subjects },
        create: yearSubject
      });
    }

    console.log('✅ Created Year Subjects');

    // Log summary
    console.log('\n🎉 Database seeded successfully!');
    console.log('\n📊 Summary:');
    console.log(`- Created 1 HOD, 2 Staff, ${createdStudents.length} Students`);
    console.log(`- Created ${createdLabs.length} Labs`);
    console.log(`- Created ${studentAssignments.length} Student-Lab Assignments`);
    console.log(`- Created ${staffAssignments.length} Staff-Lab Assignments`);
    console.log(`- Created ${attendanceRecords.length} Attendance Records`);
    
    console.log('\n🔑 Login Credentials:');
    console.log('HOD: username=hod1, password=hod123');
    console.log('Staff1 (Dr. John Smith): username=staff1, password=staff123');
    console.log('Staff2 (Prof. Jane Doe): username=staff2, password=staff123');
    console.log('Students: username=stu001 to stu017, password=student123');
    
    console.log('\n📚 Staff Lab Assignments:');
    console.log('Staff1 (Dr. John Smith) handles:');
    console.log('  - Physics Lab (2nd year) - 3 students');
    console.log('  - Big Data Analytics (3rd year) - 3 students');
    console.log('  - Programming Lab (2nd year) - 2 students');
    console.log('Staff2 (Prof. Jane Doe) handles:');
    console.log('  - Chemistry Lab (2nd year) - 2 students');
    console.log('  - Machine Learning Lab (3rd year) - 2 students');
    console.log('  - AI Lab (4th year) - 4 students');
    console.log('  - Database Lab (3rd year) - 1 student');

    console.log('\n👥 Students by Year:');
    console.log('2nd Year: 7 students (STU001-STU007)');
    console.log('3rd Year: 6 students (STU008-STU013)');
    console.log('4th Year: 4 students (STU014-STU017)');

  } catch (error) {
    console.error('❌ Seed error:', error);
    throw error;
  } finally {
    await prisma.$disconnect();
  }
};

seed().catch((e) => {
  console.error(e);
  process.exit(1);
});