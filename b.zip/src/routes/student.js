// routes/student.js
import { Router } from 'express';
import { auth, requireRole } from '../middleware/auth.js';
import { 
  getStudentDashboard,
  getStudentAttendance,
  getStudentLabs,
  getStudentNotifications,
  markNotificationRead,
  getAttendanceStats,
  updateStudentProfile
} from '../controllers/studentController.js';

const router = Router();

// Require authentication for all student routes
router.use(auth(true));

// Require STUDENT role for all routes
router.use(requireRole('STUDENT'));

// Student dashboard - get student info and statistics
router.get('/dashboard', getStudentDashboard);

// Student attendance
router.get('/attendance', getStudentAttendance);

// Student labs - get assigned labs with instructor info
router.get('/labs', getStudentLabs);

// Student notifications
router.get('/notifications', getStudentNotifications);
router.put('/notifications/:id/read', markNotificationRead);

// Student analytics/stats for charts
router.get('/attendance-stats', getAttendanceStats);

// Student profile management
router.put('/profile', updateStudentProfile);

export default router;