// Enhanced Lab Routes
import { Router } from 'express';
import { auth, requireRole } from '../middleware/auth.js';
import {
  listLabs,
  createLab,
  assignStaffToLab,
  assignStudentsToLab,
  getYearSubjects,
  setYearSubjects,
  deleteLab
} from '../controllers/labController.js';

const router = Router();

// Public routes (with auth)
router.use(auth(true));

// Get all labs (available to all authenticated users)
router.get('/', listLabs);

// Get year subjects
router.get('/years/:year', getYearSubjects);

// HOD-only routes
router.use(requireRole('HOD'));

// Create new lab
router.post('/', createLab);

// Assign staff to labs
router.post('/assign-staff', assignStaffToLab);

// Assign students to lab
router.post('/assign-students', assignStudentsToLab);

// Update year subjects
router.put('/years/:year', setYearSubjects);

// Delete lab
router.delete('/:id', deleteLab);

export default router;