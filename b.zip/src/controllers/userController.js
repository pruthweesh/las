// userController-complete-fix.js - Ultimate Backend Fix
import bcrypt from 'bcryptjs';
import { prisma } from '../config/prisma.js';
import { createUserSchema, setPasswordSchema } from '../utils/validators.js';

export async function createUser(req, res) {
  try {
    console.log("🔵 CREATE USER - Request received:", { body: req.body, user: req.user });
    
    const body = createUserSchema.parse(req.body);
    
    // CONVERT ROLE TO UPPERCASE TO MATCH PRISMA ENUM
    body.role = body.role.toUpperCase();

    // Ensure role is not HOD here
    if (body.role === 'HOD') return res.status(400).json({ error: 'Use /auth/signup-hod to create HOD' });

    // Get HOD's department for auto-assignment
    const hodFromDb = await prisma.user.findUnique({
  where: { id: req.user.id },
  select: { department: true }
});
const hodDepartment = hodFromDb?.department;
if (!hodDepartment) {
  return res.status(400).json({ error: "HOD has no department assigned" });
}

    console.log("🔵 HOD Department for new user:", hodDepartment);
    
    let userData = {
      name: body.name,
      email: body.email,
      username: body.username,
      password: await bcrypt.hash(body.password, 10),
      role: body.role,
      department: hodDepartment // ALWAYS assign HOD's department to new users
    };

    if (body.role === 'STUDENT') {
      userData.studentId = body.studentId || `STU${Date.now()}`;
      userData.year = body.year || null;
    }

    console.log("🔵 Creating user with data:", { ...userData, password: '[HIDDEN]' });
    const user = await prisma.user.create({ data: userData });
    console.log("🔵 User created successfully:", { id: user.id, name: user.name, role: user.role });

    // Assign labs if provided
    if (body.role === 'STUDENT' && body.labs && body.labs.length) {
      for (const labName of body.labs) {
        const yearVal = user.year || '';
        let lab = await prisma.lab.findFirst({ where: { name: labName, year: yearVal } });
        if (!lab) {
          lab = await prisma.lab.create({ data: { name: labName, year: yearVal } });
        }
        await prisma.studentLabAssignment.create({ data: { studentId: user.id, labId: lab.id } });
      }
      console.log("🔵 Student labs assigned:", body.labs);
    }
    if (body.role === 'STAFF' && body.assignedLabs && body.assignedLabs.length) {
      for (const labName of body.assignedLabs) {
        let lab = await prisma.lab.findFirst({ where: { name: labName, year: '' } });
        if (!lab) {
          lab = await prisma.lab.create({ data: { name: labName, year: '' } });
        }
        await prisma.staffLabAssignment.create({ data: { staffId: user.id, labId: lab.id } });
      }
      console.log("🔵 Staff labs assigned:", body.assignedLabs);
    }

    res.status(201).json({ user: { ...user, password: undefined } });
  } catch (e) {
    console.error("❌ Create user error:", e);
    if (e.code === 'P2002') {
      return res.status(400).json({ error: 'Username or email already exists' });
    }
    if (e.errors) return res.status(400).json({ error: e.errors.map(x => x.message).join(', ') });
    return res.status(500).json({ error: e.message });
  }
}

export async function listUsers(req, res) {
  try {
    console.log("🟢 LIST USERS - Request received");
    console.log("🟢 Query params:", req.query);
    console.log("🟢 Current user (HOD):", { 
      id: req.user?.id, 
      name: req.user?.name, 
      role: req.user?.role, 
      department: req.user?.department 
    });
    
    const { role, year, department } = req.query;
    let where = {};
    
    // Apply query filters
    if (role) {
      where.role = role.toUpperCase();
      console.log("🟢 Filtering by role:", role.toUpperCase());
    }
    if (year) {
      where.year = year;
      console.log("🟢 Filtering by year:", year);
    }
    if (department) {
      where.department = department;
      console.log("🟢 Filtering by department:", department);
    }
    
    // CRITICAL FIX: Enhanced department filtering for HODs
    if (req.user?.role === 'HOD') {
      const hodUser = await prisma.user.findUnique({ 
  where: { id: req.user.id },
  select: { department: true }
});
const hodDepartment = hodUser?.department;
      console.log("🟢 HOD department filtering. HOD dept:", hodDepartment);
      
      if (hodDepartment && hodDepartment.trim()) {
        // Show users from HOD's department OR users with null/empty departments
        const departmentFilter = {
          OR: [
            { department: hodDepartment },
            { department: null },
            { department: '' },
            { department: { equals: null } }
          ]
        };
        
        // Merge with existing where clause
        if (where.OR) {
          where = { AND: [where, departmentFilter] };
        } else {
          where = { ...where, ...departmentFilter };
        }
        
        console.log("🟢 Applied department filter for HOD");
      } else {
        console.log("🟡 HOD has no department, showing all users");
      }
    }
    
    console.log("🟢 Final WHERE clause:", JSON.stringify(where, null, 2));
    
    // Execute database query with enhanced logging
    const users = await prisma.user.findMany({
      where,
      select: { 
        id: true, 
        username: true, 
        email: true, 
        name: true, 
        role: true, 
        year: true, 
        studentId: true, 
        department: true 
      },
      include: {
        staffLabs: {
          include: {
            lab: {
              select: { id: true, name: true, year: true }
            }
          }
        }
      }
    });
    
    console.log("🟢 Raw database results:", users.length, "users found");
    
    // Process staff lab assignments
    const processedUsers = users.map(user => {
      if (user.role === 'STAFF' && user.staffLabs) {
        return {
          ...user,
          assignedLabs: user.staffLabs.map(sl => sl.lab.name)
        };
      }
      return user;
    });

    // Enhanced logging
    const students = processedUsers.filter(u => u.role === 'STUDENT');
    const staff = processedUsers.filter(u => u.role === 'STAFF');
    
    console.log("🟢 FINAL RESULTS:");
    console.log(`  - Total users: ${processedUsers.length}`);
    console.log(`  - Students: ${students.length}`);
    console.log(`  - Staff: ${staff.length}`);
    
    // Log department distribution
    const deptCounts = {};
    processedUsers.forEach(u => {
      const dept = u.department || 'NULL';
      deptCounts[dept] = (deptCounts[dept] || 0) + 1;
    });
    console.log("🟢 Department distribution:", deptCounts);
    
    // Log individual users for debugging
    if (processedUsers.length <= 10) {
      console.log("🟢 Individual users:");
      processedUsers.forEach(u => {
        console.log(`  - ${u.name} (${u.role}) - Dept: "${u.department}" - Year: "${u.year}"`);
      });
    }

    res.json({ users: processedUsers });
  } catch (e) {
    console.error("❌ List users error:", e);
    console.error("❌ Stack trace:", e.stack);
    return res.status(500).json({ error: e.message });
  }
}
// src/controllers/userController.js
export async function getHodDashboard(req, res) {
  try {
    console.log("🔵 HOD Dashboard - Starting...");
    
    // Ensure we fetch the HOD's department from DB - don't rely on token-only data
    const hodId = req.user?.id;
    const hod = await prisma.user.findUnique({ where: { id: hodId }, select: { department: true } });

    if (!hod) return res.status(403).json({ error: "Access denied" });
    const hodDepartment = (hod.department || '').toString().trim();
    console.log("🔵 HOD Department:", `"${hodDepartment}"`);
    
    if (!hodDepartment) {
      return res.status(400).json({ error: "HOD has no department assigned" });
    }

    // FIXED: Use the same flexible department filtering as listUsers function
    const departmentFilter = {
      OR: [
        { department: hodDepartment },
        { department: null },
        { department: '' },
        { department: { equals: null } }
      ]
    };

    // Students with flexible department matching
    const students = await prisma.user.findMany({
      where: { 
        role: 'STUDENT',
        ...departmentFilter
      },
      select: { id: true, name: true, email: true, year: true, role: true, department: true }
    });
    
    // Staff with flexible department matching  
    const staff = await prisma.user.findMany({
      where: { 
        role: 'STAFF',
        ...departmentFilter  
      },
      select: { id: true, name: true, email: true, year: true, role: true, department: true }
    });

    console.log("🔵 Students found:", students.length);
    console.log("🔵 Staff found:", staff.length);

    // Attendance with flexible filtering
    const attendanceRecords = await prisma.attendance.findMany({
      where: {
        student: departmentFilter
      }
    });

    let avgAttendance = 0;
    if (attendanceRecords.length > 0) {
      const present = attendanceRecords.filter(r => r.status === 'PRESENT').length;
      avgAttendance = Math.round((present / attendanceRecords.length) * 100);
    }

    const response = {
      studentsCount: students.length,
      staffCount: staff.length,
      students,
      staff,
      avgAttendance,
      totalRecords: attendanceRecords.length
    };

    console.log("🔵 Final counts - Students:", response.studentsCount, "Staff:", response.staffCount);
    return res.json(response);
    
  } catch (err) {
    console.error("❌ getHodDashboard error:", err);
    console.error("❌ Stack trace:", err.stack);
    return res.status(500).json({ error: "Internal Server Error", details: err.message });
  }
}



export async function deleteUser(req, res) {
  try {
    const id = Number(req.params.id);
    console.log("🔴 DELETE USER - ID:", id);
    
    await prisma.user.delete({ where: { id } });
    console.log("🔴 User deleted successfully");
    
    res.json({ message: 'Deleted' });
  } catch (e) {
    console.error("❌ Delete user error:", e);
    return res.status(500).json({ error: e.message });
  }
}

export async function setUserPassword(req, res) {
  try {
    const id = Number(req.params.id);
    const parsed = setPasswordSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'Invalid password' });
    
    console.log("🟡 SET PASSWORD - User ID:", id);
    
    const hash = await bcrypt.hash(parsed.data.newPassword, 10);
    await prisma.user.update({ where: { id }, data: { password: hash } });
    
    console.log("🟡 Password updated successfully");
    res.json({ message: 'Password updated' });
  } catch (e) {
    console.error("❌ Set password error:", e);
    if (e.errors) return res.status(400).json({ error: e.errors.map(x => x.message).join(', ') });
    return res.status(500).json({ error: e.message });
  }
}

export async function assignStudentLabs(req, res) {
  try {
    const id = Number(req.params.id);
    const { labs = [] } = req.body;
    
    console.log("🟠 ASSIGN STUDENT LABS - Student ID:", id, "Labs:", labs);
    
    // Reset and set
    await prisma.studentLabAssignment.deleteMany({ where: { studentId: id } });
    for (const labName of labs) {
      let lab = await prisma.lab.findFirst({ where: { name: labName, year: '' } });
      if (!lab) {
        lab = await prisma.lab.create({ data: { name: labName, year: '' } });
      }
      await prisma.studentLabAssignment.create({ data: { studentId: id, labId: lab.id } });
    }
    
    console.log("🟠 Labs assigned successfully");
    res.json({ message: 'Labs assigned' });
  } catch (e) {
    console.error("❌ Assign labs error:", e);
    return res.status(500).json({ error: e.message });
  }
}

// DEBUG ENDPOINT - Get all users without filtering
export async function debugListAllUsers(req, res) {
  try {
    console.log("🔍 DEBUG - Getting ALL users from database");
    
    const allUsers = await prisma.user.findMany({
      select: { 
        id: true, 
        username: true, 
        email: true, 
        name: true, 
        role: true, 
        year: true, 
        studentId: true, 
        department: true 
      }
    });
    
    console.log("🔍 DEBUG - Total users in database:", allUsers.length);
    allUsers.forEach(u => {
      console.log(`🔍   - ${u.name} (${u.role}) - Dept: "${u.department}" - Year: "${u.year}"`);
    });
    
    res.json({ 
      message: 'Debug data retrieved',
      totalUsers: allUsers.length,
      users: allUsers,
      breakdown: {
        students: allUsers.filter(u => u.role === 'STUDENT').length,
        staff: allUsers.filter(u => u.role === 'STAFF').length,
        hods: allUsers.filter(u => u.role === 'HOD').length
      }
    });
  } catch (e) {
    console.error("❌ Debug endpoint error:", e);
    return res.status(500).json({ error: e.message });
  }
}

// Assign user to HOD's department (only their own department)
export async function assignUserDepartment(req, res) {
  try {
    const userId = Number(req.params.id);
    const hodDepartment = req.user?.department;
    
    console.log("🟢 ASSIGN USER DEPARTMENT - User ID:", userId, "HOD Department:", hodDepartment);
    
    // Validate HOD has a department
    if (!hodDepartment) {
      return res.status(400).json({ error: 'HOD must have a department assigned' });
    }
    
    // Check if user exists and get current info
    const existingUser = await prisma.user.findUnique({ where: { id: userId } });
    if (!existingUser) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    // HOD can only assign users to their own department
    const updateData = { department: hodDepartment };
    
    await prisma.user.update({
      where: { id: userId },
      data: updateData
    });
    
    console.log(`🟢 User ${existingUser.name} assigned to department: ${hodDepartment}`);
    
    res.json({ 
      message: 'User department updated successfully',
      user: {
        id: userId,
        name: existingUser.name,
        department: hodDepartment
      }
    });
  } catch (e) {
    console.error("❌ Assign user department error:", e);
    return res.status(500).json({ error: e.message });
  }
}

// Fix department assignments - assign HOD's department to users with missing departments
export async function fixDepartmentAssignments(req, res) {
  try {
    const hodDepartment = req.user?.department;
    
    console.log("🔧 FIX DEPARTMENT ASSIGNMENTS - HOD Department:", hodDepartment);
    
    // Validate HOD has a department
    if (!hodDepartment) {
      return res.status(400).json({ error: 'HOD must have a department assigned' });
    }
    const emptyDeptFilter = {
  OR: [
    { department: null },
    { department: '' },
    { department: undefined },
    { department: 'NULL' },
    { department: 'null' },
    { department: 'None' },
    { department: 'default' },
    { department: 'Default Department' }
  ]
};
    // Find users without department or with empty department
    const usersWithoutDepartment = await prisma.user.findMany({
      where: emptyDeptFilter,
      select: { id: true, name: true, role: true, department: true }
    });
    
    console.log("🔧 Found users without department:", usersWithoutDepartment.length);
    
    if (usersWithoutDepartment.length === 0) {
      return res.json({ 
        message: 'No users found without department assignments',
        fixed: 0,
        users: []
      });
    }
    
    // Update all users without department to HOD's department
    const updateResult = await prisma.user.updateMany({
      where: {
        OR: [
          { department: null },
          { department: '' },
          { department: undefined }
        ],
        role: {
          in: ['STAFF', 'STUDENT']
        }
      },
      data: { department: hodDepartment }
    });
    
    console.log(`🔧 Fixed ${updateResult.count} users' department assignments`);
    
    res.json({
      message: `Successfully fixed department assignments for ${updateResult.count} users`,
      fixed: updateResult.count,
      assignedDepartment: hodDepartment,
      users: usersWithoutDepartment.map(u => ({
        id: u.id,
        name: u.name,
        role: u.role,
        previousDepartment: u.department,
        newDepartment: hodDepartment
      }))
    });
  } catch (e) {
    console.error("❌ Fix department assignments error:", e);
    return res.status(500).json({ error: e.message });
  }
}

// Diagnostic function to check department data and identify filtering issues  
export async function diagnosticDepartmentData(req, res) {
  try {
    console.log("🔍 DIAGNOSTIC - Checking department data");
    
    // Get current HOD info
    const hodUser = req.user;
    console.log("🔍 Current HOD:", {
      id: hodUser.id,
      name: hodUser.name,
      department: hodUser.department,
      role: hodUser.role
    });
    
    // Get ALL users from database
    const allUsers = await prisma.user.findMany({
      select: { 
        id: true, 
        name: true, 
        role: true, 
        department: true,
        year: true 
      }
    });
    
    console.log("🔍 Total users in database:", allUsers.length);
    
    // Analyze department distribution
    const departmentStats = {};
    const roleStats = { STUDENT: 0, STAFF: 0, HOD: 0 };
    
    allUsers.forEach(user => {
      // Count by role
      roleStats[user.role]++;
      
      // Count by department
      const dept = user.department || 'NULL/EMPTY';
      if (!departmentStats[dept]) {
        departmentStats[dept] = { total: 0, students: 0, staff: 0, hods: 0 };
      }
      departmentStats[dept].total++;
      departmentStats[dept][user.role.toLowerCase() + 's']++;
    });
    
    console.log("🔍 Role distribution:", roleStats);
    console.log("🔍 Department distribution:", departmentStats);
    
    // Check department matching
    const hodDepartment = hodUser.department;
    const usersInHodDepartment = allUsers.filter(u => 
      u.department === hodDepartment || 
      (!u.department && !hodDepartment) ||
      (u.department === '' && hodDepartment === '') ||
      (!u.department || u.department === '')
    );
    
    console.log(`🔍 Users that match HOD department "${hodDepartment}":`, usersInHodDepartment.length);
    
    // Show specific examples
    const examples = {
      studentsInHodDept: usersInHodDepartment.filter(u => u.role === 'STUDENT').slice(0, 5),
      staffInHodDept: usersInHodDepartment.filter(u => u.role === 'STAFF').slice(0, 5),
      allStudents: allUsers.filter(u => u.role === 'STUDENT').slice(0, 5),
      allStaff: allUsers.filter(u => u.role === 'STAFF').slice(0, 5)
    };
    
    res.json({
      success: true,
      diagnosticInfo: {
        hodInfo: {
          id: hodUser.id,
          name: hodUser.name,
          department: hodUser.department,
          role: hodUser.role
        },
        databaseStats: {
          totalUsers: allUsers.length,
          roleDistribution: roleStats,
          departmentDistribution: departmentStats
        },
        filtering: {
          hodDepartment: hodDepartment,
          usersMatchingHodDepartment: usersInHodDepartment.length,
          studentsInHodDepartment: usersInHodDepartment.filter(u => u.role === 'STUDENT').length,
          staffInHodDepartment: usersInHodDepartment.filter(u => u.role === 'STAFF').length
        },
        examples: examples,
        solution: departmentStats['NULL/EMPTY']?.total > 0 ? 
          "Users have NULL/EMPTY departments. Use /users/fix-departments to assign them to your department." :
          Object.keys(departmentStats).length > 1 ? 
          "Multiple departments found. Check if department names match exactly." :
          "Department filtering working correctly."
      }
    });
    
  } catch (e) {
    console.error("❌ Diagnostic error:", e);
    return res.status(500).json({ error: e.message });
  }
}