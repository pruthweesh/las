import { prisma } from '../config/prisma.js';
import { createAttendanceSchema } from '../utils/validators.js';

export async function createAttendance(req, res) {
  try {
    const parsed = createAttendanceSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'Invalid payload' });
    const data = parsed.data;

    const lab = await prisma.lab.upsert({
      where: { name_year: { name: data.lab, year: '' } },
      update: {},
      create: { name: data.lab, year: '' }
    });

    const date = data.date ? new Date(data.date) : new Date();
    
    // ✅ FIXED: Eliminate N+1 query - fetch all students at once
    const studentIds = data.records.map(r => r.studentId);
    const students = await prisma.user.findMany({
      where: { 
        studentId: { in: studentIds },
        role: 'STUDENT' 
      },
      select: { id: true, studentId: true }
    });
    
    // Create a lookup map for O(1) access
    const studentMap = new Map(students.map(s => [s.studentId, s.id]));
    
    // ✅ FIXED: Bulk create attendance records
    const attendanceData = data.records
      .filter(r => studentMap.has(r.studentId)) // Only valid students
      .map(r => ({
        studentId: studentMap.get(r.studentId),
        labId: lab.id,
        date,
        status: r.status
      }));
    
    if (attendanceData.length === 0) {
      return res.status(400).json({ error: 'No valid students found' });
    }
    
    // ✅ FIXED: Single database operation instead of loop
    const created = await prisma.attendance.createMany({
      data: attendanceData,
      skipDuplicates: true // Prevents duplicate entries
    });
    
    res.status(201).json({ 
      created: created.count,
      processed: data.records.length,
      valid: attendanceData.length,
      message: `Successfully created ${created.count} attendance records`
    });
    
  } catch (e) {
    console.error('❌ Attendance creation error:', e);
    return res.status(500).json({ error: e.message });
  }
}

export async function getStudentAttendance(req, res) {
  try {
    const { studentId } = req.params;
    
    // ✅ OPTIMIZED: Single query with joins instead of separate queries
    const student = await prisma.user.findFirst({ 
      where: { studentId, role: 'STUDENT' },
      include: {
        attendance: {
          include: { lab: true },
          orderBy: { date: 'desc' }
        }
      }
    });
    
    if (!student) return res.status(404).json({ error: 'Student not found' });
    
    const mapped = student.attendance.map(r => ({
      id: r.id,
      date: r.date,
      lab: r.lab.name,
      status: r.status
    }));
    
    res.json({ attendance: mapped });
  } catch (e) {
    console.error('❌ Get student attendance error:', e);
    return res.status(500).json({ error: e.message });
  }
}

export async function getSummary(req, res) {
  try {
    let attendance = [];

    if (req.user?.role === 'HOD') {
      // ✅ OPTIMIZED: Single query with proper joins
      const hod = await prisma.user.findUnique({ 
        where: { id: req.user.id }, 
        select: { department: true } 
      });
      
      const dept = hod?.department || null;
      if (!dept) return res.status(400).json({ error: "HOD has no department" });

      attendance = await prisma.attendance.findMany({
        where: {
          student: { department: dept }
        },
        include: { 
          student: { 
            select: { id: true, name: true, year: true, department: true }
          }
        }
      });
    } else {
      attendance = await prisma.attendance.findMany({ 
        include: { 
          student: { 
            select: { id: true, name: true, year: true, department: true }
          }
        }
      });
    }

    // ✅ OPTIMIZED: Single-pass aggregation
    const byYear = attendance.reduce((acc, rec) => {
      const studentYear = rec.student?.year || 'Unknown';
      if (!acc[studentYear]) acc[studentYear] = { total: 0, present: 0 };
      acc[studentYear].total += 1;
      if (rec.status === 'PRESENT') acc[studentYear].present += 1;
      return acc;
    }, {});
    
    return res.json({ byYear });
  } catch (e) {
    console.error("❌ getSummary error:", e);
    return res.status(500).json({ error: e.message });
  }
}