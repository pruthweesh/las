// Enhanced Lab Controller for HOD Lab Management
import { prisma } from '../config/prisma.js';

// Get all labs with student counts
export async function listLabs(req, res) {
  try {
    console.log('📚 Loading all labs with student counts...');
    
    const labs = await prisma.lab.findMany({
      include: {
        students: {
          include: {
            student: {
              select: { name: true, year: true }
            }
          }
        },
        staff: {
          include: {
            staff: {
              select: { name: true }
            }
          }
        }
      },
      orderBy: [
        { year: 'asc' },
        { name: 'asc' }
      ]
    });

    const formattedLabs = labs.map(lab => ({
      id: lab.id,
      name: lab.name,
      year: lab.year,
      student_count: lab.students.length,
      staff_count: lab.staff.length,
      students: lab.students.map(s => ({
        name: s.student.name,
        year: s.student.year
      })),
      staff: lab.staff.map(s => s.staff.name),
      created_at: lab.createdAt || new Date().toISOString()
    }));

    console.log(`✅ Found ${formattedLabs.length} labs`);
    res.json(formattedLabs);
    
  } catch (error) {
    console.error('❌ List labs error:', error);
    res.status(500).json({ error: error.message });
  }
}

// Create new lab (for HOD)
export async function createLab(req, res) {
  try {
    const { name, year } = req.body;
    
    console.log(`📚 Creating new lab: ${name} (Year ${year})`);
    
    if (!name || !year) {
      return res.status(400).json({ error: 'Lab name and year are required' });
    }

    // Check if lab already exists
    const existing = await prisma.lab.findUnique({
      where: { name_year: { name, year: year.toString() } }
    });

    if (existing) {
      return res.status(409).json({ error: 'Lab already exists for this year' });
    }

    const lab = await prisma.lab.create({
      data: {
        name: name.trim(),
        year: year.toString()
      }
    });

    console.log(`✅ Created lab: ${lab.name} (ID: ${lab.id})`);
    
    res.status(201).json({
      id: lab.id,
      name: lab.name,
      year: lab.year,
      student_count: 0,
      staff_count: 0,
      message: 'Lab created successfully'
    });
    
  } catch (error) {
    console.error('❌ Create lab error:', error);
    res.status(500).json({ error: error.message });
  }
}

// Assign staff to lab (enhanced)
export async function assignStaffToLab(req, res) {
  try {
    const { staffId, labIds } = req.body;
    
    console.log(`👥 Assigning staff ${staffId} to labs:`, labIds);
    
    if (!staffId || !Array.isArray(labIds) || labIds.length === 0) {
      return res.status(400).json({ error: 'Staff ID and lab IDs are required' });
    }

    // Verify staff exists and is STAFF role
    const staff = await prisma.user.findUnique({
      where: { id: parseInt(staffId), role: 'STAFF' }
    });

    if (!staff) {
      return res.status(404).json({ error: 'Staff member not found' });
    }

    // Remove existing assignments for this staff
    await prisma.staffLabAssignment.deleteMany({
      where: { staffId: parseInt(staffId) }
    });

    // Create new assignments
    const assignments = labIds.map(labId => ({
      staffId: parseInt(staffId),
      labId: parseInt(labId)
    }));

    await prisma.staffLabAssignment.createMany({
      data: assignments
    });

    // Get updated lab information
    const updatedLabs = await prisma.lab.findMany({
      where: { id: { in: labIds.map(id => parseInt(id)) } },
      include: {
        students: true,
        staff: {
          include: {
            staff: { select: { name: true } }
          }
        }
      }
    });

    console.log(`✅ Assigned ${assignments.length} labs to staff ${staff.name}`);
    
    res.json({
      message: `Successfully assigned ${assignments.length} labs to ${staff.name}`,
      staff_name: staff.name,
      assigned_labs: updatedLabs.map(lab => ({
        id: lab.id,
        name: lab.name,
        year: lab.year,
        student_count: lab.students.length
      }))
    });
    
  } catch (error) {
    console.error('❌ Assign staff to lab error:', error);
    res.status(500).json({ error: error.message });
  }
}

// Assign students to lab (for bulk assignments)
export async function assignStudentsToLab(req, res) {
  try {
    const { labId, studentIds } = req.body;
    
    console.log(`👥 Assigning ${studentIds?.length || 0} students to lab ${labId}`);
    
    if (!labId || !Array.isArray(studentIds) || studentIds.length === 0) {
      return res.status(400).json({ error: 'Lab ID and student IDs are required' });
    }

    // Verify lab exists
    const lab = await prisma.lab.findUnique({ where: { id: parseInt(labId) } });
    if (!lab) {
      return res.status(404).json({ error: 'Lab not found' });
    }

    // Verify students exist and are STUDENT role
    const students = await prisma.user.findMany({
      where: { 
        id: { in: studentIds.map(id => parseInt(id)) },
        role: 'STUDENT'
      }
    });

    if (students.length !== studentIds.length) {
      return res.status(400).json({ error: 'Some students not found or invalid' });
    }

    // Create assignments (using upsert to avoid duplicates)
    const assignments = [];
    for (const studentId of studentIds) {
      const assignment = await prisma.studentLabAssignment.upsert({
        where: { 
          studentId_labId: { 
            studentId: parseInt(studentId), 
            labId: parseInt(labId) 
          }
        },
        update: {},
        create: {
          studentId: parseInt(studentId),
          labId: parseInt(labId)
        }
      });
      assignments.push(assignment);
    }

    console.log(`✅ Assigned ${assignments.length} students to ${lab.name}`);
    
    res.json({
      message: `Successfully assigned ${assignments.length} students to ${lab.name}`,
      lab_name: lab.name,
      lab_year: lab.year,
      assigned_students: students.map(s => ({
        id: s.id,
        name: s.name,
        student_id: s.studentId
      }))
    });
    
  } catch (error) {
    console.error('❌ Assign students to lab error:', error);
    res.status(500).json({ error: error.message });
  }
}

// Get year subjects (existing functionality)
export async function getYearSubjects(req, res) {
  try {
    const { year } = req.params;
    
    const yearSubjects = await prisma.yearSubjects.findUnique({
      where: { year: year.toString() }
    });

    if (!yearSubjects) {
      return res.json({ year, subjects: [] });
    }

    res.json({
      year: yearSubjects.year,
      subjects: yearSubjects.subjects
    });
    
  } catch (error) {
    console.error('❌ Get year subjects error:', error);
    res.status(500).json({ error: error.message });
  }
}

// Set year subjects (existing functionality)
export async function setYearSubjects(req, res) {
  try {
    const { year } = req.params;
    const { subjects } = req.body;
    
    if (!Array.isArray(subjects)) {
      return res.status(400).json({ error: 'Subjects must be an array' });
    }

    const yearSubjects = await prisma.yearSubjects.upsert({
      where: { year: year.toString() },
      update: { subjects },
      create: { year: year.toString(), subjects }
    });

    res.json({
      year: yearSubjects.year,
      subjects: yearSubjects.subjects,
      message: 'Year subjects updated successfully'
    });
    
  } catch (error) {
    console.error('❌ Set year subjects error:', error);
    res.status(500).json({ error: error.message });
  }
}

// Delete lab (for HOD)
export async function deleteLab(req, res) {
  try {
    const { id } = req.params;
    
    console.log(`🗑️ Deleting lab ${id}`);
    
    // Check if lab has assignments
    const assignments = await prisma.studentLabAssignment.count({
      where: { labId: parseInt(id) }
    });

    if (assignments > 0) {
      return res.status(400).json({ 
        error: `Cannot delete lab with ${assignments} student assignments. Remove students first.` 
      });
    }

    // Remove staff assignments first
    await prisma.staffLabAssignment.deleteMany({
      where: { labId: parseInt(id) }
    });

    // Delete lab
    await prisma.lab.delete({
      where: { id: parseInt(id) }
    });

    console.log(`✅ Deleted lab ${id}`);
    res.json({ message: 'Lab deleted successfully' });
    
  } catch (error) {
    console.error('❌ Delete lab error:', error);
    res.status(500).json({ error: error.message });
  }
}