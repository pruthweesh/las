
# LAS Backend (No Temporary Passwords)

Backend API for your Lab Attendance System that matches your frontend's roles and flows, **with HOD-only signup** and **no temporary password** requirement.

## Highlights
- Node.js + Express + Prisma (MySQL)
- JWT auth; role-based access (HOD / STAFF / STUDENT)
- HOD-only signup: 
  - If no HOD exists yet, the first HOD can self-register via `/auth/signup-hod` (open bootstrap).
  - After at least one HOD exists, creating another HOD requires a HOD's token.
- HOD can create Staff/Students **with direct passwords** (no temp-password or forced reset).
- Endpoints for users, labs/subjects-by-year, and attendance (bulk from scan session).

## Quick Start

1. **Create DB** (MySQL): create a database, e.g. `las_db`.
2. **Configure**: copy `.env.example` to `.env` and set `DATABASE_URL`, `JWT_SECRET`.
3. **Install deps**:
   ```bash
   npm install
   npx prisma generate
   npx prisma migrate dev --name init
   ```
4. **Run**:
   ```bash
   npm run dev
   ```
   Server on `http://localhost:4000`

### Environment
```
DATABASE_URL=mysql://USER:PASSWORD@HOST:3306/las_db
JWT_SECRET=replace-me
JWT_EXPIRES_IN=7d
CORS_ORIGIN=http://localhost:3000
```

## API (condensed)

### Auth
- `POST /auth/signup-hod` — body: `{ "name": "...", "email": "...", "username": "...", "password": "..." }`  
  - Allowed **open** only if no HOD exists. Otherwise, require `Authorization: Bearer <hod-token>`.
- `POST /auth/login` — body: `{ "username": "...", "password": "...", "role": "HOD"|"STAFF"|"STUDENT" }` → `{ "token": "...", "user": { ... } }`
- `POST /auth/change-password` — (self) `{ "currentPassword": "...", "newPassword": "..." }`

### Users (HOD only; requires `Authorization`)
- `POST /users` — create STAFF/STUDENT with **direct** password.  
  Body (student):
  ```json
  { "name":"...", "email":"...", "username":"...", "password":"...", "role":"STUDENT", "year":"3rd Year", "studentId":"STU001", "labs":["Physics Lab"] }
  ```
  Body (staff):
  ```json
  { "name":"...", "email":"...", "username":"...", "password":"...", "role":"STAFF", "assignedLabs":["Physics Lab","Chemistry Lab"] }
  ```
- `GET /users?role=STUDENT&year=3rd Year`
- `DELETE /users/:id`
- `PATCH /users/:id/password` — set a user's password (HOD override)
- `PUT /users/students/:id/labs` — assign labs to a student

### Labs / Subjects
- `GET /labs?year=2nd Year`
- `GET /labs/years/:year` — get subject list for a year
- `PUT /labs/years/:year` — set subject list (body: `{ "subjects": ["Physics Lab","Chemistry Lab"] }`)

### Attendance
- `POST /attendance` (HOD or STAFF)  
  Body:  
  ```json
  {
    "date": "2025-01-15T09:30:00.000Z",
    "lab": "Physics Lab",
    "records": [
      { "studentId":"STU001", "status":"PRESENT" },
      { "studentId":"STU002", "status":"DUPLICATE" }
    ]
  }
  ```
- `GET /attendance/student/:studentId`
- `GET /attendance/summary` (HOD)

## Wiring to your React frontend

Your current frontend keeps data **in memory** in `App.js`. Replace those with API calls:

- `handleLogin` → `POST /auth/login`
- `handleSignup` (HOD only) → `POST /auth/signup-hod`
- `addUser` (HOD adds staff/student) → `POST /users` (provide a password directly)
- `deleteUser` → `DELETE /users/:id`
- `updateUserPassword` → `PATCH /users/:id/password`
- Attendance scanning finalization → `POST /attendance` (bulk records)

Also remove/rename UI that says "Generate Temporary Password" to "Set/Reset Password" (since backend does not use temporary passwords).

## Notes
- Percentages are computed client-side like your demo. If you want server-side percentage aggregation per student/year, extend `/attendance/summary` accordingly.
- Prisma schema includes `YearSubjects` to store per-year subject lists your HOD sets in the dashboard.

---

Built on: 2025-09-02T12:44:46.162065
